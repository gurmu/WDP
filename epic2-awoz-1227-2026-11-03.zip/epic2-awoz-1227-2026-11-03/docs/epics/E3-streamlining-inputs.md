# E3 Task 3.1 — what Data Governance must supply

**AWOZ-1227 / INC17 milestone 1227 · Epic 1227-E3 · AC3 · written 2026-11-02**

**Owner of this document:** AI/ML Ops. **Owner of everything it asks
for:** Data Governance.

---

## Why this exists

CONOPS §3.3's streamlining proposal is the part of AC3 that changes how
the platform is used day to day:

> pre-approved templates per data tier and direction; one review and
> approval triggers automated issuance; only out-of-template requests
> follow the full process.

That proposal only works if four things exist that this prototype
**cannot** produce: the agreements themselves, the tier definitions, the
approver roles, and the review-time targets. AC3 does not ask us to
write them. It asks us to make the platform able to enforce them the
moment they arrive.

So this is a list of **dated asks**, not a list of gaps. Each entry says
what we need, why the platform needs it specifically, what we are doing
in the meantime, and what it costs if the answer comes late. An empty
cell in an ARB package is a problem; a dated ask with a named owner is a
plan.

**One of these asks is not a request for information. It is a warning
about what the agreement must not promise.** See Input 5.

---

## Input 1 — The DSA templates

**What we need:** the pre-approved agreement text, one per tier per
direction.

**Why the platform needs it:** the platform does not store or interpret
the agreement. It stores a **reference** to it, on every artifact. For
the reference to be useful it must be stable and resolvable — an
identifier a reader can take to a document register and find the exact
text that governs the share in front of them. We need to know the
identifier's **format** before we plumb it, because it goes into a
comment field on every recipient, share, view and landed table, and
changing the format later means rewriting every object.

**Directions that need a template** (the CONOPS channel model gives four
that carry data):

| Direction | Channel | What flows |
|---|---|---|
| Egress to an outside organisation | E-1 | We publish; they consume |
| Egress to another Databricks account | E-2 | Same, different counterparty type |
| Ingress, pull | I-1 | We consume from a provider |
| Ingress, push | I-2 | A producer uploads to us |

Direction matters more than it looks: on egress we are the data owner
and the agreement constrains the consumer; on ingress **we** are the
constrained party, and the clauses that bind us (retention, permitted
use, deletion on termination) are the ones that have to become platform
behaviour rather than policy text.

**What we need from each template, minimally:** its identifier format,
its version/revision convention, and whether one identifier covers a
tier-plus-direction pair or a single counterparty.

**In the meantime:** the prototype carries a placeholder reference in the
real field, in the real format we expect, so that the plumbing is
exercised and the substitution is a value change rather than a schema
change.

**Cost of a late answer:** low if the identifier format arrives early
even without the text. **High if the format changes after Epic 4 lands
tables**, because landed tables carry the reference as a tag and
retagging a populated landing zone is a migration, not an edit.

---

## Input 2 — The tier list and its definitions

**What we need:** the authoritative list of data tiers, their labels,
and the **test** by which a dataset is assigned to one.

**Why the platform needs it:** the tier is the key that selects every
other control. In the prototype a tier determines which view a consumer
gets, which retention applies, which revocation path is used, and
whether the recipient's address allow-list is mandatory. A tier label
with no test behind it means every assignment is an opinion, and the
first audit question is "who decided this table was Internal and on what
basis?"

**What specifically:**

- The label set. We are **not** proposing one — we have a placeholder
  shape only, and an invented tier list that later turns out to conflict
  with the organisation's existing classification would be worse than no
  list.
- For each tier, the **decision rule**: what property of a dataset puts
  it in that tier. Ideally something checkable (a column class, a source
  system, a marking) rather than a judgement.
- Whether tiers are **ordered** (so a control can be written as "tier
  Confidential or above") or **categorical** (so every control must be
  enumerated per tier). This changes the config structure, not just its
  values.
- Whether a dataset can carry **more than one** tier, for instance a
  table whose columns differ in sensitivity. The platform's answer today
  is one view per entitled purpose (see Input 4), which handles this
  cleanly, but only if we know it is a case that occurs.

**In the meantime:** the tier structure is built with two placeholder
tiers that exercise both ends of the range — one with the loosest
controls and one with the tightest — so that adding the real tiers is
data entry.

**Cost of a late answer:** moderate. The structure is cheap to populate
and expensive to reshape; the ordered-versus-categorical question is the
one that should be answered first, because it is structural.

---

## Input 3 — Approver roles and review-time targets

**What we need:** who approves an in-template request, who approves an
out-of-template request, and what review time each is expected to take.

**Why the platform needs it:** the streamlining proposal's entire value
is that an in-template request is approved once and then issued
automatically. That is only a saving if we know **which role's approval
counts** and can record it against the issuance. Without a named role
the platform records "approved" with no principal, which satisfies
nobody at audit.

**What specifically:** the role names, whether approval is single or
dual, whether the data owner and the governance approver are distinct
(the prototype assumes they are — see the note on hats below), and the
target turnaround for each path so the platform can report against it.

**A structural note worth confirming.** This prototype has been careful
to separate three roles that are easy to collapse: the **data owner**
who decides what may be shared, the **provider operator** who issues and
expires credentials, and the **credential custodian** who vaults them.
They were exercised under separate hats deliberately, and the evidence
records which hat performed which action. If the real governance model
collapses any two of these into one role, we should know, because the
separation is currently load-bearing in how the tests are written.

**In the meantime:** the governance inventory carries owner and approver
fields with placeholder values.

**Cost of a late answer:** low for the prototype, high for AC4. The
self-service portal in AC4 cannot be designed without knowing how many
approvals a request needs and who gives them.

---

## Input 4 — Confirmation that granular access is view-based

**What we need:** acknowledgement, not information. This is an input we
are supplying **to** Data Governance, and we need it accepted.

**What we found.** CONOPS §3.1, §2.3.1 and §3.4 all state that sensitive
columns are excluded by *"sharing a view, or applying column masks and
row filters"*. **The second half is not possible.** A table that is in an
OpenSharing share cannot carry column masks or row filters at all, and a
table carrying them cannot be added to such a share. The platform refuses
it explicitly and the two features are mutually exclusive by design, not
by tier or licence.

**What that means for the DSA.** The "handling and downstream use"
consideration cannot be enforced by masking columns on a shared table.
It is enforced by **sharing a view** that selects only the entitled
columns and, with a predicate, only the entitled rows — with the base
table never added to any share. Any DSA clause written on the assumption
that masks are available describes a control the platform will refuse to
create.

**What we need from Data Governance:** acceptance of this as the
pattern, so the agreement text and the technical control agree.

**Cost of a late answer:** this one has already been paid down. Had it
been found in the client workspace during the §5.3 verification session
it would have surfaced in front of stakeholders against a claim that
cannot be met as written. CONOPS v1.6 should strike the masks-and-filters
clause from all three sections.

---

## Input 5 — A decision about what the revocation clause may promise

**This is the ask that changes the agreement text, and it is the reason
this document is being written before the tier config rather than
after.**

**What we measured.** A DSA's revocation consideration is normally
written as something like *"access is withdrawn within N of notice"*.
Before writing N into a tier definition we tested whether the platform
can honour it, and the answer depends entirely on **which mechanism**
performs the withdrawal:

- **Narrowing a shared view's predicate** — the natural way to withdraw
  access to a subset of rows — **did not reach a live consumer within
  the ten minutes we watched.** The provider's own catalog reported the
  narrower definition immediately, every provider-side check agreed the
  reduction was in force, and the consumer kept reading the rows that
  had just been taken out of scope. Nineteen reads, the last at just
  under ten minutes.
- **Revoking the recipient's credential** takes effect immediately and
  is measured doing so.

Those are very different guarantees, and the difference is invisible
from the provider's side. **A narrowing that looks applied everywhere it
can be checked is still readable by the consumer**, which is a
disclosure rather than an inconvenience.

Two bounds, stated so nobody over-reads this: ten minutes is a **floor,
not a ceiling** — it says the change had not arrived, not that it never
arrives. A related measurement elsewhere in the programme saw a newly
shared object unreadable at under three minutes and readable some hours
later, so the mechanism is plausibly a cache with a long horizon rather
than a failure.

**What we need from Data Governance:** a decision on how the agreement
expresses revocation, given the above. Three shapes are available and
they are not equivalent:

1. **Express revocation in terms of the mechanism that is immediate** —
   credential revocation at the recipient level — and treat
   scope-narrowing as a *change*, not a revocation, with its own and
   longer stated window.
2. **State a window long enough to be true** for the slow path, once we
   have measured its actual ceiling rather than a floor.
3. **Require that narrowing be performed by credential revocation plus
   re-issue**, which converts a slow change into a fast one at the cost
   of interrupting the consumer.

The prototype can implement any of the three. It cannot implement a
clause that promises a fast withdrawal through the slow mechanism, and
that is the clause most likely to be written if nobody raises this.

**In the meantime:** we are measuring the full matrix — which mechanisms
revoke, and how fast each one actually propagates — so that whichever
shape is chosen is chosen against numbers. The tier config will not carry
a revocation control until that matrix exists, because a tier file that
names a control is making a promise.

**Cost of a late answer:** this is the highest-cost item in the
document. A revocation window written into an executed agreement that
the platform cannot meet is a compliance exposure, not a backlog item.

---

## Input 6 — The two referenced items not yet incorporated

ADVANASD-814427 and AWOZ-1361 are named in the epic as inputs whose
details have not been incorporated. We do not have their content. Until
we do, we cannot say whether they add considerations beyond the seven,
and the ARB package will have to record them as an unincorporated
reference rather than as a closed item.

**Owner:** Data Governance, with Binod.

---

## Where the seven considerations stand today

This is the honest summary of what the platform can enforce **now**,
before any of the above arrives. It is the other half of the ask: it
shows Data Governance that the plumbing is waiting rather than absent.

| DSA consideration | Platform control | State today |
|---|---|---|
| **Purpose limitation** | Share isolation — one share per entitled purpose, a recipient sees only its own | Enforceable now; measured |
| **Permitted consumers / providers** | Recipient list, plus an address allow-list for tighter tiers | Enforceable now; the allow-list is measured refusing a valid credential from an unlisted address, and measured reversing |
| **Handling / downstream use** | A view per entitled purpose; base table never shared | Enforceable now — **and only this way**, see Input 4 |
| **Retention** | Retention rule per tier, applied to landed copies | **Structure only.** Needs the tier list (Input 2). The enforcement point exists in the landing design |
| **Revocation** | Credential revocation; share/grant removal; view narrowing | **Split.** Credential revocation measured immediate; view narrowing measured not reaching a consumer within ten minutes. See Input 5 |
| **Audit** | DSA reference on every artifact; correlation id from edge to log | Reference plumbing being built in Task 3.2; the correlation handle exists and is measured reaching the caller |
| **Incident** | Revocation triggers plus the audit trail | Depends on Input 5 and on the audit table this tier does not expose |

---

## What we are asking for, in one table

| # | Ask | Owner | Needed by | Blocks |
|---|---|---|---|---|
| 1 | DSA identifier **format** (text can follow) | Data Governance | Before Epic 4 lands tables | Reference plumbing; retagging later is a migration |
| 2 | Tier labels + decision rule; ordered or categorical | Data Governance | Structural question first | Tier config, retention, every per-tier control |
| 3 | Approver roles and review-time targets | Data Governance | Before AC4 design | Self-service issuance |
| 4 | **Acceptance** that granular access is view-based | Data Governance + ARB | With the v1.6 revision | CONOPS §3.1, §2.3.1, §3.4 text |
| 5 | **Decision** on how revocation is expressed | Data Governance | Before the tier file names a control | The revocation clause in every template |
| 6 | ADVANASD-814427 and AWOZ-1361 content | Data Governance, Binod | Before AC3 sign-off | Whether the seven considerations are complete |

**None of these is a blocker on Epic 3's build work.** Every one of them
has a placeholder that exercises the real plumbing, so each answer lands
as a value change. Input 5 is the exception in one respect: it does not
block the build, but it does block the tier file from *claiming* a
revocation control, and we will not write that claim before the
measurement exists.

---

**What this document is not.** It is not the Data Sharing Agreement, and
Epic 3 does not deliver one. Data Governance owns the agreement; AI/ML
Ops owns the technical implementation of its clauses. This document is
the interface between those two sentences.
