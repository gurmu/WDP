# E2 — T04-11: Traffic Control and Serving Configuration (AC2)

| | |
|---|---|
| **Epic** | T04-11 |
| **Acceptance criterion** | AC2 — Traffic Control and Serving Configuration |
| **CONOPS sections** | 2.2, 2.3 (all), 2.3.4, 3.2, 5, 6 |
| **Stories** | 1: Serving design behind the front door · 2: Gravitee policies with Data Tooling · 3: Test results and ARB package |
| **Role** | Build — AI/ML Ops builds and tests it |
| **Target dates** | 10/8 – 10/29 · checkpoints **10/19** configuration tested with Data Tooling, **10/26** test results complete and OD-1 decided |
| **Depends on** | 1636 (Gravitee front door, relationship to Apigee unconfirmed), 1227-E1 (channel model and route table as CaC) |
| **Tests** | T-03, T-05, T-06, T-07, T-08, T-15, T-24 |
| **Decisions in play** | OD-1 (**gates 10/26**), OD-5, OD-8, OD-9 |
| **Risks in play** | R2, R5, R9, R10 |

> ## RECONCILED 2026-10-25 — read this before any task below
>
> This playbook was written **2026-10-18**. E1 then ran from 10/18 to 10/23
> and **built several of these tasks itself**, recording the borrow in the
> artifacts: `gravitee/generated/route-family.json` names its own epic as
> *"E2 Task 2.1, borrowed into E1 Task 1.6"*. Four tasks below are wholly or
> largely DONE, and one task's **exit criterion is now wrong** and
> contradicts a measured E1 finding.
>
> Each affected task carries a `RECONCILED` block under its heading. The
> original text is kept unaltered beneath it (B-19: a superseded claim is
> labelled in place, never deleted).
>
> **The authoritative remaining backlog for this epic is not this task
> list.** It is the two declared-incompleteness registers that E1's own
> generators emit, because those were written against what actually got
> built:
>
> - `gravitee/generated/route-family.json` -> `known_incomplete`: **RF-1 ... RF-6**
> - `iac/config/policy-classes.yaml` -> `known_incomplete`: **PC-1 ... PC-5**
>
> Work those. §E2.6 maps them onto the task numbering below.

> **The criterion, verbatim (CONOPS §3.2):** *exposure of Databricks
> endpoints through Gravitee with enforced rate limits, spike arrest and
> request schema validation to protect compute resources.*

---

## E2.0 What this epic actually has to produce

E1 owns the question of *who may see what*. E2 owns the question of
*what the edge does to a request on its way through* — and, critically,
the evidence that the edge trips **before** Databricks does. CONOPS
§2.3.3 states the design intent plainly: *"The Gravitee limit is set
below the Databricks-side limit on the same route so the edge trips
first."* AC2 is not satisfied by a rate limit existing. It is satisfied
by a rate limit demonstrably firing at the gateway while the Databricks
side never sees the burst.

Four deliverables:

1. **One** Gravitee V4 API, generated from the E1 route-table CaC file,
   with the correct upstream target — replacing the two half-correct
   APIs that exist today.
2. **Policy classes A–E** instantiated as reusable configuration, not
   copy-pasted per route, with the starting values from §2.3.3 and the
   tuned values recorded as the T-05 output.
3. **Six refusal and sanitization tests** (T-03, T-05, T-06, T-07, plus
   the edge halves of T-08 and T-24) each producing an evidence record.
4. **The §3.2 capability table, filled in** — seven gateway capabilities
   the design relies on, each currently marked "not yet confirmed for
   the Gravitee version in use", each with a fallback. Turning those
   seven rows from assumptions into observations against CE 4.12.23 is
   the single most useful thing this epic hands the ARB.

A note on the division with E1 and E5. T-03's *refusal* is enforced here
but the *allow-list content* comes from E1's `allow-lists.yaml`. The
correlation ID this epic injects is consumed by E5 (AC5, T-11); E2 owns
putting it on the request, E5 owns proving it ties the three logs
together. Do not re-litigate either boundary inside this epic.

---

## E2.1 Task list

Run them in order. Tasks 2.1 and 2.2 are prerequisites for everything
else and are also the overdue 10/19 checkpoint.

### Task 2.1 — Correct the B-1 diagnosis, then fix the real fault

> **RECONCILED — PARTLY DONE, AND THE EXIT CRITERION BELOW IS WRONG.**
>
> Done: B-1 is reclassified as an upstream target error in `docs/11` §11.7
> and `docs/10` §10.6. The consolidated definitions exist, generated.
>
> **Wrong:** *"a single consolidated V4 API"*, and the verify condition
> *"Management v2 `_search` returns exactly one API"*, cannot be satisfied
> and must not be attempted. E1 measured D-9 / B-42: the sharing endpoint
> hostname is **per recipient**, and the platform validates the host-to-token
> binding — `400 BAD_REQUEST: Request URL hostname ... does not match with
> the recipient id ...`. A route pinned to one host refuses every other
> recipient's token, correctly. Channel E-1 is a **route family**: one API
> per recipient, generated from `recipients.yaml`.
>
> Corrected verify: `_search` returns **one API per resolved recipient, plus
> F1, plus M1** — today five — every one generated, none hand-maintained, and
> both legacy APIs deleted. The deletion **ordering** is a landmine; see §E2.6.

**Blocker B-1 as written in §11.7 is wrong, and the wrong diagnosis is
more expensive than the fault.** §11.7 blames the 404 on the API
lifecycle never reaching `PUBLISHED` and on a duplicate API fighting
over deployment. Neither is the cause. Re-probed 2026-10-18 09:27 UTC:

```
# Both APIs, via management v2 (B-2 applies — v1 returns [ ]):
a45a3c30… "AWOZ-1227 OpenSharing Perimeter"              /delta-sharing/
          state=STARTED lifecycleState=CREATED deploymentState=DEPLOYED
          flows: perimeter-controls, storage-proxy-download
          target: https://dbc-0c6ebc56-563d.cloud.databricks.com/api/2.0/delta-sharing

97a9f494… "AWOZ-1227 OpenSharing - Metastore 48cda780"   /opensharing-demo/
          state=STARTED lifecycleState=CREATED deploymentState=DEPLOYED
          flows: (none)
          target: https://634cbc18-….opensharing.us-east-2.cloud.databricks.com
                  /api/2.0/opensharing/metastores/48cda780-…
```

Gateway log, both APIs: `ApiManagerImpl - API id[…] has been deployed`.
So the gateway picked up **both**. `lifecycleState: CREATED` governs
*portal publication*, not gateway serving — it is a red herring, and the
baseline doc should stop citing it.

The decisive evidence is the body of the 404:

```json
{"error_code":"ENDPOINT_NOT_FOUND",
 "message":"No API found for 'GET /delta-sharing/shares'",
 "details":[{"@type":"type.googleapis.com/google.rpc.RequestInfo", …}]}
```

That is a **Databricks** error, in Databricks' error envelope, with a
Databricks request id. The gateway proxied the call correctly; the
*upstream* rejected the path. Gravitee's own 404 looks different and is
logged by `NotFoundProcessor` — which does appear in the log, but only
for `/storage-proxy/` (that one is B-3, and it is real).

Meanwhile the "duplicate" API works end to end:

```
GET /opensharing-demo/shares                         → 200
  {"items":[{"name":"awoz1227_demo_share1ashu", …}]}
GET /opensharing-demo/shares/…/all-tables            → 200
  {"items":[{"name":"ashu","schema":"default", …,"accessModes":["url"]}]}
GET /opensharing-demo/shares  (no Authorization)     → 401
```

**The actual fault:** `https://<workspace>.cloud.databricks.com/api/2.0/delta-sharing`
is not the sharing endpoint on this tier. The endpoint in every
credential file is
`https://<uuid>.opensharing.<region>.cloud.databricks.com/api/2.0/opensharing/metastores/<metastore-id>`,
and §2.3.2 is explicit that the target must be *"the endpoint from the
credential file plus the same path"*. The original API was built against
an assumed URL instead of the issued one.

So the two APIs are each half right: one has the policy flows and the
wrong target, the other has the right target and no policy flows. The
fix is to converge them into one, not to pick a winner.

**Deliverable:** a corrected diagnosis written back into
`docs/11-environment-baseline.md` §11.7 (B-1 reclassified: upstream
target error, not a lifecycle or duplication fault, with the 404 body as
evidence); a single consolidated V4 API carrying the `/opensharing-demo`
target and the `perimeter-controls` flow; the redundant API deleted, not
left stopped.

**Verify:** `GET <edge>/shares` with the recipient token returns the
share list **and** the request appears in the Gravitee access log with
the ip-filtering policy evaluated. Management v2 `_search` returns
exactly one API.

**This is the 10/19 checkpoint.** It is already overdue; it is also an
afternoon's work, because the hard part — proving the gateway can proxy
the open protocol at all — is already done.

### Task 2.2 — Make the import idempotent

The duplicate API is itself a defect, independent of B-1. The 23:43
re-import created a second definition rather than updating the first,
which means `scripts/05_import_gravitee_api.py` is not idempotent.

This matters twice over. Here, because an epic whose whole job is
deny-by-default cannot have two definitions of what "default" is. And in
E6, because AC6's T-12 is *"redeploy from code onto a clean target"* —
an import that duplicates on second run fails T-12 by construction. Fix
it here, where it blocks, rather than discovering it in E6.

The correct shape, given B-2: search by **cross-ID or by name** through
`POST /management/v2/environments/DEFAULT/apis/_search`, then `PUT` the
existing id if found and `POST` only if not. Gravitee's cross-ID field
exists precisely for this; use it and set it from the CaC file so the
identity of the API lives in version control rather than in whichever
UUID the server happened to mint.

**Deliverable:** `scripts/05_import_gravitee_api.py` rewritten against
management v2, idempotent by cross-ID, with deploy-after-update; a
`--prune` mode that removes APIs carrying our cross-ID prefix but no
longer in the CaC file.

**Verify:** run the import three times; the API count stays at one and
the revision increments only when the definition actually changed.

### Task 2.3 — Generate the route table into the API definition

> **RECONCILED — DONE, except PC-2 and RF-5.**
>
> Built as `scripts/29_gen_gravitee_route_family.py` (sharing routes + F1) and
> `scripts/30_gen_gravitee_ai_route.py` (M1, M2, M3), emitting into
> `gravitee/generated/`. Do **not** write `scripts/gen_gravitee_api.py`: it
> would be a second generator over the same route table, which is the exact
> divergence this task warns against.
>
> **CLOSED 2026-10-27. Both residue items settled, and the Verify line's
> second half measured.**
>
> ~~Residue: **PC-2** — S10's path is a candidate expansion, not confirmed, so
> class C may be generated onto a selector that matches nothing and the
> catch-all refusal would read as enforcement. **RF-5** — `/iceberg` has no
> route at all and survives only on the catch-all, while the rewritten
> credential's `icebergEndpoint` points at it. Give it a route or an explicit
> deny; M3 is the precedent for naming a refusal rather than inheriting one.~~
>
> **PC-2** — settled by `scripts/33_probe_s10_path.py`:
> `S10_ABSENT_FROM_THE_SHARING_ENDPOINT`. The path does not exist, so class C
> is not generated onto it and route X's whitelist excludes it. Probe U3 then
> measured S10 refused *at the edge*, not forwarded to an upstream 404 — which
> is the distinction this item existed to protect.
>
> **RF-5** — settled as route **S11**, an explicit `/iceberg/*` deny, with
> M3 as the precedent. Probe U4 measured `/iceberg/v1/config` refused at the
> edge.
>
> **Verify: "an unlisted path returns the protocol error format and not a
> Gravitee 404."** The second half is measured; the first is not achievable.
> `scripts/36_probe_unlisted_paths.py` returned
> `PERIMETER_REFUSES_EVERY_UNLISTED_PATH_PROBED` — seven unlisted paths all
> refused by the edge in `resource-filtering`'s own voice, with `GET /shares`
> returning 200 immediately before and after. Not a Gravitee 404 anywhere.
> The protocol error format is **not achievable** (PC-4, measured): the
> refusal is a reasonless 403. This task closes with that stated as an
> accepted limit, not with it dropped.
>
> Three properties are now measured rather than assumed: Ant `*` does not
> cross `/` (U5), a different literal tail at a whitelisted depth is refused
> (U6), and the per-entry `methods` list constrains (U7, a 405). U7's 405
> rather than a 403 also confirms the **B-50** translation at the pattern
> level — a pattern that had not matched would have produced the 403.

E1 Task 1.3 produces `iac/config/route-table.yaml` holding S1–S10, F1,
M1–M3, A1 and X. This task turns that file into V4 flows rather than
hand-maintaining JSON.

Generate, do not transcribe. A route table that exists twice — once as
the CaC source and once as hand-edited JSON — will diverge, and the
divergence will be discovered by a reviewer rather than by a test.

Three design points worth settling before writing the generator.

Flow **selectors** must match on both method and path, because the
protocol distinguishes `GET .../tables/{table}/metadata` (class A) from
`POST .../tables/{table}/query` (class B) on paths that overlap. A
path-only selector silently puts the query route in class A and the
rate-limit evidence for T-05 becomes meaningless.

Route **X** needs to be a real flow, not an absence. §2.3.2 says *"Routes
not listed are denied"* and §3.2's capability table offers *"explicit
catch-all deny route"* as the fallback if deny-by-default is not native.
Build the explicit catch-all regardless — it is the only way the denial
emits the protocol error format (`errorCode`, `message`) that §2.3.2
requires, rather than Gravitee's own 404 shape.

Routes **M3** and **A1** are represented as explicit deny flows with a
comment naming why, not as omissions. §3.1.2's reason for M3 — legacy
managed MCP bypasses Unity AI Gateway grants, policies and guardrails,
and its calls do not appear in the tracing tables — belongs in the
generated artifact where an auditor will find it.

**Deliverable:** `scripts/gen_gravitee_api.py` emitting
`iac/gravitee/api-definition.json` from `route-table.yaml` +
`policy-classes.yaml`; the generated file committed so diffs are
reviewable.

**Verify:** every route id in the YAML appears as a flow; `S8` and `S7`
resolve to different classes; an unlisted path returns the protocol
error format and not a Gravitee 404.

### Task 2.4 — Policy classes A–E as shared configuration

> **RECONCILED — CONFIG DONE, ENFORCEMENT NOT.**
>
> `iac/config/policy-classes.yaml` exists, with the common set expressed once,
> and every policy id and configuration field name verified against **this**
> installation's own `plugins/policies/{id}/schema` endpoints on CE 4.12.23.
> The discrete Mongo and Elasticsearch properties are already in
> `docker-compose.yml`.
>
> Residue as of 2026-10-27: **PC-1** — `query-body.schema.json` still does
> not exist, so class B runs the permissive fallback and T-06 can only return
> `CANNOT_SEE`. This is the one remaining blocker on this task. Shared policy
> groups are declared in YAML but **not yet deployed as Gravitee objects**.
>
> ~~**PC-4** — the terminal-deny policy shape is unconfirmed, so route X emits
> **disabled**: unmatched paths fail closed by accident rather than by
> decision.~~ **Settled.** Route X emits **enabled** and is measured enforcing
> (`scripts/36`, 7/7). The shape is a *pair*, not one policy: no installed
> policy both refuses and emits a body, so `resource-filtering` enforces
> (fail-closed, measured) and the reason reaches the auditor through the
> generated artifact rather than the caller. `mock` can emit a body and fails
> **open**, which on a catch-all forwards every unlisted path (AI-9). The
> accepted limit is the reasonless 403.
>
> Also measured here, and previously unmeasured: the whitelist's per-entry
> `methods` list **constrains** (U7). That matters for this task, because
> §2.3.3's class split depends on `GET .../metadata` and `POST .../query`
> being distinguishable on overlapping paths.

§2.3.3 gives five classes and a set of common policies that apply to
every route. Express the common set once and the per-class deltas once.

Common, per §2.3.3: address allow-list per consumer, bearer presence and
format check, correlation ID added, internal headers removed,
metadata-only logging, deny by default.

Per class, the starting values — and they are starting values, which
§2.3 is explicit about: *"proposals to be tuned in the Section 5 tests;
they are not commitments."* Record them as config, and record the tuned
values as the T-05 output rather than editing history.

| Class | Routes | Rate limit | Spike arrest | Quota/day | Body and validation | Timeout |
|---|---|---|---|---|---|---|
| A | S1–S7 | 60/min | 5/s | 5,000 | no body; path pattern check | 30 s |
| B | S8, S9 | 20/min | 2/s | 1,000 | 16 KB max; JSON schema | 60 s |
| C | S10 | 20/min | 2/s | 1,000 | small body max | 30 s |
| D | F1 | 600/min | 20/s | 50,000 req | GET/HEAD only; range allowed | 300 s |
| E | M1, M2 | 30/min | 3/s | 2,000 | 1 MB JSON; schema per endpoint | 120 s |

Gravitee CE 4.12 has **shared policy groups**, and the gateway log shows
three already deployed in this environment. Use them for the common set
so that a change to header sanitization is one edit rather than fifteen.

Two implementation traps, both already paid for once.

The rate-limit and spike-arrest policies maintain counters in MongoDB
and **build their own connection URI** from discrete properties. Without
`gravitee_ds_mongodb_host`, `_port` and `_dbname` on the **gateway**
service, every request touching one of these policies hangs until
timeout — it does not error, it hangs, which is far harder to diagnose.
`docker-compose.yml` carries the fix; any clean-target rebuild under
T-12 must carry it too.

The per-consumer requirement in §2.3.3 ("Class settings are per
consumer") needs a rate-limit key. §3.2 lists *"rate-limit key from the
Authorization header"* as a needed capability with *"key by source
address"* as the fallback. §2.3.4 explains why this is delicate: the
reference clients send **only** the bearer token and cannot be made to
present a gateway API key. So key on a **hash** of the Authorization
header, never the token itself, and never log the key. If CE cannot
derive a key from a header, fall back to source address and record that
the fallback was taken.

**Deliverable:** `iac/config/policy-classes.yaml`; shared policy groups
for the common set; the Mongo requirement documented inline in the
compose file and in `iac/config/README`.

**Verify:** a class B route rejects a 17 KB body and a class A route on
an overlapping path still accepts a no-body GET; a request touching a
rate-limited route completes in milliseconds, not at timeout.

### Task 2.5 — T-03: valid token from an address not on the allow-list

> **RECONCILED — DONE.**
>
> T-03 passes against the current route family, re-run 2026-10-22 on the
> rotated credential: `REFUSED_AT_THE_EDGE_AND_REVERSIBLE`, 1 of 1, refusal
> attributed to a named policy and then reversed. Evidence is already at
> `evidence/t03-refusal.json`.
>
> Two corrections to this task's premises. The leftover
> `_secrets/t03-refusal-evidence.json` still exists and should be deleted —
> it holds no secret and the live record is now in `evidence/`. And
> `allow-lists.yaml` is **superseded, not missing**: E1 put the CIDRs
> per-recipient in `recipients.yaml` under `ip_access_list`, which is the
> right home because the list is recipient-scoped. No separate file is owed.

This one has already passed once, on 2026-10-17 15:40, and the evidence
survives in `_secrets/t03-refusal-evidence.json` — a 403 from the
`ip-filtering` policy with the message
`Your IP (172.21.0.1) ... not allowed`. Two things follow.

It must be **re-run and re-captured** after Task 2.1, because the API it
passed against is the one being retired. A test result against a
retired configuration is not evidence.

And the evidence file must **move out of `_secrets/`**. It contains no
secret; it is in there by accident, and it is the clearest demonstration
of AC2's enforcement that this project has produced. It belongs in
`evidence/` where the ARB package can reference it.

T-03 is also the test that makes R4 (stolen token) tolerable: the token
is valid and the request still fails. Pair it in the evidence record
with E1's T-02, which proves the same thing at the Databricks layer via
the recipient IP access list. Two independent layers, one claim — that
is §6's "layered enforcement" principle with evidence behind it.

**Deliverable:** `tests/t03_address_denied.py`;
`evidence/t03-refusal.json`; `_secrets/t03-refusal-evidence.json`
removed.

**Verify:** 403 from the gateway, logged, with the Databricks side
showing no corresponding request. The second half matters more than the
first — a refusal that still reached Databricks is not a perimeter.

### Task 2.6 — T-05: rate limit, spike arrest, and who trips first — EDGE HALF CLOSED 2026-10-30

> **CLOSED on two of three assertions.
> `THROTTLED_WITH_NO_RETRY_INDICATION`. The third — clause 2.5 itself —
> is DEFERRED to the client environment, named rather than quietly
> dropped.**
>
> **Assertion 2, the throttle response, recorded as observed.** Both
> limits trip, both clear, and neither 429 carries a retry indication:
>
> ```
> spike 429 body : 'Spike limit exceeded! You reached the limit of 1 requests per 200 ms.'
> rate  429 body : 'Rate limit exceeded! You reached the limit of 60 requests per 1 minutes'
> spike 429 hdrs : ['connection','content-length','content-type','x-gravitee-client-identifier']
> ```
>
> No `Retry-After`, no `X-RateLimit-*`. That is **R9 realised**, and
> §3.2's named fallback is exactly this — record the actual response —
> so the fallback is taken, not failed. The deliverable it creates is a
> v1.6 obligation: §2.3.4's reference clients need a backoff of their
> own, because the gateway will not tell them when to retry.
>
> **Assertion 3, distinguishable: YES, but only by body.** Same status,
> same (absent) retry headers, different body text. An operator reading
> status codes cannot tell a burst from a quota; an operator reading
> bodies can. Recorded because the ambiguity is one layer thinner than
> it looks.
>
> **Assertion 1, clause 2.5, NOT measured.** *"The edge trips before
> Databricks"* requires counting requests that reached the upstream,
> which means `system.access.audit` — a system table this workspace tier
> does not expose. The test says so in its own output and records
> `clause_2_5_not_measured` in the evidence file rather than inferring
> it from the 429s. **A 429 at the edge is consistent with the upstream
> never being called and does not demonstrate it**, and the distinction
> is the whole content of the clause. Deferred to the client
> environment, in the register, with the resource named.
>
> **Two findings fell out of the response bodies, both recorded where
> the design lives.** `5/s` is enforced as **1 per 200 ms** — the
> gateway smooths the window, so the first refusal landed at request 2
> of a 10-request burst rather than request 6 (recorded on the class A
> spike step as `enforced_shape_MEASURED_2026-10-30`, and as an
> environment finding in docs/11). And `x-gravitee-client-identifier`
> survives on refusals, because a request-phase interrupt skips the
> response chain — **B-55**, which is a hole in Task 2.8's claim found
> by a test that was not looking for it.
>
> **Measurement hazard, kept from last time.** T-01 once scored a
> spike-arrest 429 as a policy refusal. T-05 guards against the reverse
> by driving a 200 through the same route in phase 0 and again in
> phase 4 after recovery: without the phase 4 control a throttle that
> never clears would read as a pass, and that is an outage, not a
> throttle.
>
> **Tuning: deliberately not done.** §2.3.3's values are proposals and
> T-05 was expected to tune them. The measured shape makes the numbers
> the wrong thing to change first — a class whose limit is enforced as a
> 200 ms gate needs its *shape* described in v1.6 before its value is
> argued about, and changing a limit so a test reads better is B-47.
> Recorded as `tuned_values_still_open`.
>
> **Evidence:** `evidence/t05-report.json` [0600]. 1/1 checks passed.

### Task 2.6 (original text) — T-05: rate limit, spike arrest, and who trips first

The headline AC2 test. Burst above the configured limit per class and
record the throttle response.

Three assertions, in order of how much the ARB will care.

**The edge trips before Databricks.** Burst a class A route above 60/min
and confirm the Databricks side logged fewer requests than were sent.
This is the actual content of clause 2.5, *"to protect compute
resources"*, and it is the one assertion that cannot be satisfied by
reading configuration.

**The throttle response is recorded as observed.** §3.2 wants 429 with a
retry indication and names *"record the actual response"* as the
fallback; R9 is the risk that CE does not emit `Retry-After`. Capture
the status, headers and body verbatim. If it is a bare 429, say so — the
CONOPS has pre-accepted that outcome, and a fabricated `Retry-After`
would be worse than an honest gap.

**Spike arrest and rate limit are distinguishable.** Two bursts: one
fast and small (trips spike arrest at 5/s, passes the per-minute limit),
one slow and large (passes spike arrest, trips 60/min). If both produce
the same response with no way to tell them apart, that is a finding
worth recording, because operators will need to tell them apart.

Then tune. The §2.3.3 values are proposals; T-05's deliverable includes
the values the test actually supports, written back to
`policy-classes.yaml` with a note on what drove the change.

**Deliverable:** `tests/t05_rate_limit.py` covering classes A, B and D;
`evidence/t05-throttle.json` with verbatim responses; tuned values in
`policy-classes.yaml`.

**Verify:** throttling observed per class; Databricks-side request count
strictly less than the sent count; spike arrest and rate limit
separately attributable or the ambiguity recorded.

### Task 2.7 — T-06: schema validation, body limits, and the error format

Malformed and oversized bodies to the query route (S8, class B) must be
*rejected at the gateway* in the protocol error format.

The schema, from §2.3.3, allows exactly: `predicateHints`,
`jsonPredicateHints`, `limitHint`, `version`, `timestamp`,
`startingVersion`, `endingVersion`. Build it as a real JSON Schema file
in `iac/gravitee/schemas/` and reference it from the flow, so the schema
is reviewable on its own and reusable by E4's push-ingest validation.

Four cases, and the fourth is the one that is usually missed. Oversized
body (>16 KB) rejected. Malformed JSON rejected. Well-formed JSON with
an undeclared field rejected — which requires `additionalProperties:
false`, so set it deliberately and know that this is the choice that
makes the test meaningful. And a **valid** query body accepted, because
a schema that rejects everything passes the first three cases while
breaking the product.

The error format is as important as the rejection. §2.3.2 requires
denials in the protocol's shape (`errorCode`, `message`). Gravitee's
`json-validation` policy emits its own body by default; override it, or
chain a response transformation, so a reference client sees something it
can parse. Confirm what CE 4.12 actually lets you control here and
record it — this is one of the seven §3.2 capability rows.

**Deliverable:** `iac/gravitee/schemas/query-body.schema.json`;
`tests/t06_schema_validation.py` with all four cases;
`evidence/t06-validation.json`.

**Verify:** three rejections and one acceptance; every rejection body
parses as a protocol error with `errorCode` and `message`.

### Task 2.8 — T-07: header sanitization — CLOSED 2026-10-28, NARROWED 2026-10-30

> **CLOSED. `INTERNAL_HEADERS_REMOVED_AND_PASSTHROUGH_PRESERVED`, both
> halves measured. The original heading is kept below (B-19) --
> "currently failing" was true when this task was drafted, and the
> before/after record is the point.**
>
> **The leak half.** Three headers measured removed (`Server`,
> `server-timing`, `x-request-id`), zero leaks, nothing outside the
> allow-list. Three the config named could never be removed by a policy
> at all -- stamped after the response chain -- and were fixed at the
> gateway instead (**B-52**). A fourth,
> `x-gravitee-client-identifier`, had been captured leaking on
> 2026-10-18, written into this task's own narrative, and never added to
> `removeHeaders`; it was gone within minutes of being put on the list.
> That is the deny-list weakness this task warned about, found in this
> task's own text.
>
> **The half a leak test cannot see.** §2.3.2 requires
> `delta-sharing-capabilities` to pass THROUGH on S7, and this task
> reserved one deliberate exception for the correlation ID "that E5
> depends on". Both are asserted now: T-07 fails if the capability
> header is stripped, and fails if `X-Correlation-Id` is ABSENT
> (`CORRELATION_ID_ABSENT_AC5_HAS_NO_HANDLE`). The second assertion
> exists because suppressing the Gravitee ids removed AC5's only
> client-visible handle while T-07 passed its leak half in the same run.
> This task's instinct to reserve an exception was right, and the reason
> was sharper than it looked.
>
> **The allow-list exists** --
> `iac/config/response-header-allowlist.yaml`, closing **PC-5 / RF-4**
> -- derived from the measured before/after captures rather than
> guessed. It caught `delta-table-version`, a Delta Sharing protocol
> header on S7 named nowhere in the route table or the CONOPS; a
> stricter sanitizer would have stripped it. v1.6 should name it in
> §2.3.2 beside the capability header.
>
> **One limit stated rather than papered over.** The allow-list is
> enforced by the TEST, not the gateway. `transform-headers` can add and
> remove named headers and cannot express "keep only these", and no
> installed policy can -- `resource-filtering` filters paths, measured
> against 79 policy schemas. So a header a new upstream version starts
> sending reaches clients until the next test run. Closing that needs a
> component in front of the gateway that strips by allow-list: the
> corporate-side answer, out of scope here.
>
> **NARROWED 2026-10-30 — the closure above is true of SUCCESSES only
> (B-55).** T-05 recorded a 429 carrying
> `x-gravitee-client-identifier`, the fourth header this task put on the
> remove-list. Both observations stand: the list works, and the step
> that applies it is in the RESPONSE phase, so a request-phase policy
> that interrupts answers before it ever runs. Every refusal this
> perimeter raises itself — 400, 405, 409, 413, 415, 429, route X's 403
> — is unsanitized; refusals from the UPSTREAM traverse the chain
> normally and are sanitized, so the line falls on *who refused*, not on
> the status code.
>
> This was not a flaw in the test's reasoning but in its sample: every
> probe drove a successful read, so every response it measured had been
> through the response phase. The same shape as B-40 — a control that
> can only confirm the half it exercises. **Phase 3b** now probes
> refusals explicitly and the verdict
> `SANITIZED_ON_SUCCESS_BUT_NOT_ON_REFUSALS` exists so the test can no
> longer pass by looking only at 200s.
>
> Remedy is not a policy, by PC-4's argument run backwards: a
> response-phase step cannot remove a header after an interrupt any more
> than it could add one. Gateway setting (B-52 found one for the
> `X-Gravitee-*` pair) or a component in front — both client-side. The
> disclosure is a product name and an opaque id, so the severity is low
> and the correction is to the CLAIM, which read total and was not.
>
> **Evidence:** `evidence/t07-header-sanitization.json` (carrying the
> before/after captures this task asked for),
> `evidence/t07-report.json`.

### Task 2.8 (original text) — T-07: header sanitization — currently failing

§2.2 step 5 requires Gravitee to remove internal headers (naming
`X-Databricks-Org-Id`) and hostnames from the response. **The working
route does not do this today.** The 200 from `/opensharing-demo/shares`
on 2026-10-18 returned:

```
server: databricks
X-Gravitee-Client-Identifier: fbd57f01…
X-Gravitee-Transaction-Id: c382cd8f-…
X-Gravitee-Request-Id: c382cd8f-…
server-timing: request_id;dur=0;desc="0ea91778-…", client_protocol;…
x-request-id: 0ea91778-…
```

`server: databricks` names the upstream platform. `server-timing` and
`x-request-id` carry upstream request identifiers. The `X-Gravitee-*`
triplet discloses the gateway product and its internal transaction ids.
None of this is catastrophic on its own; all of it is exactly what
clause 2.4's sibling control in §2.2 exists to strip, and all of it
would be found by any competent reviewer in thirty seconds.

Build the strip list as an **allow-list of response headers**, not a
deny-list. A deny-list is a list of the leaks you have already thought
of; the next upstream version will add one you have not. Permit what the
protocol needs (`content-type`, `transfer-encoding`, caching headers,
and for F1 the range and content-length headers) and drop the rest.

Keep one deliberate exception: the correlation ID that E5 depends on.
That header is ours, is documented, and is the mechanism by which AC5's
trace works — so it is in the allow-list, named, with a comment pointing
at §3.5.

**Deliverable:** a `transform-headers` configuration in the common
shared policy group; `iac/config/response-header-allowlist.yaml`;
`tests/t07_header_sanitization.py`; `evidence/t07-headers.json` with
before and after captures.

**Verify:** no `server`, `server-timing`, `x-request-id`,
`X-Databricks-*` or `X-Gravitee-*` header survives; the correlation ID
does; a reference client still parses the response. Include the
**before** capture in the evidence — a sanitization control with no
record of what it removed is unauditable.

### Task 2.9 — T-08 and F1: the storage proxy, and resolving B-3

OD-1(b) is the decision that file downloads are proxied through the
gateway, and §3.2's checkpoint makes **OD-1 due 10/26**. T-08 is what
decides it: download through the proxy succeeds *and* a direct storage
read is refused — or the fallback (storage address limits plus
short-lived credentials) is recorded.

Start by resolving **B-3**, because the path contradiction will waste an
afternoon otherwise. `api-definition.json` declares `/storage-proxy` as
a flow selector *beneath* the `/delta-sharing` listener, making the real
edge path `/delta-sharing/storage-proxy`, while `.env` declares
`http://localhost:8082/storage-proxy`. The gateway log settles which one
is live: `No handler can be found for request /storage-proxy/, returning
NOT_FOUND (404)` — from `NotFoundProcessor`, a genuine Gravitee 404,
unlike B-1's proxied one. Give F1 **its own listener path** so the
OD-1(b) route is independent of the sharing listener's class A policies,
and keep `.env` as the source of truth.

The hard part is not the route, it is the rewrite. §2.3.2 route F1
requires: range requests must pass, the signed query string must be
forwarded unchanged, and URLs in responses must be rewritten to this
route. The last of those is the one §3.2 flags as unconfirmed. The
`all-tables` probe shows `accessModes: ["url"]`, which confirms this
tier vends pre-signed URLs — so there *are* URLs in the response body to
rewrite, and they are in newline-delimited JSON on S8, not in a single
JSON document. A response-body rewrite over NDJSON in CE 4.12 is the
genuine technical risk in this epic.

Sequence it so a failure is informative. Prove the forward path first
(can the gateway relay a signed request to storage, with range, without
breaking the signature?). Only then attempt the body rewrite. If the
forward works and the rewrite does not, OD-1 has a real answer —
proxying is feasible but needs a thin rewrite service — rather than an
undifferentiated "did not work".

**Deliverable:** F1 on its own listener with class D policies; `.env`
and `api-definition.json` reconciled; `tests/t08_storage_proxy.py`
covering proxied download, range request, and direct-storage refusal;
`evidence/t08-proxy.json`; a written OD-1 recommendation with the
observed basis.

**Verify:** a reference client completes a full table read end to end
through the edge with no direct storage reachability. If the rewrite is
infeasible, the evidence record states which half failed and the
fallback is written up rather than implied.

### Task 2.10 — T-15: class E and the serving routes (PROBE, narrowed 2026-10-18)

> **RECONCILED — DONE for T-15 and for this task's stated verify.**
>
> T-15 passes: `R12A_CONFIRMED_INJECTION_REPLACES_AND_IS_SCOPED`, 1 of 1.
> T-16 passes: `PERIMETER_CLOSED_M3_IS_THE_BACKSTOP_SUBJECT_ABSENT_UPSTREAM`
> — which is precisely the verify condition written below. The terminal
> allow-list that closes B-48 on the AI route is built and was proven both
> ways: three paths 403 with it on, all three 200 again with it off and
> nothing else changed.
>
> What survives is the valuable half. **Clause 2.5's precedence question is
> untested**: Gravitee and Unity Gateway can each refuse and each rate-limit,
> and nothing establishes which answers first, or whether the consumer sees
> one coherent error contract or two. **R12b** is unbuilt — injection without
> a long-lived secret; today the injected credential is a personal access
> token carrying a human operator's full entitlements (AI-3). And **M2 is
> still ungenerated** (AI-5), though its method question is closed:
> POST-only confirmed, no event stream on this tier.

M1 (model serving) and M2 (Unity Gateway MCP) carry class E limits, and
clause 2.5 requires serving endpoint scaling caps set **above** the
gateway limit so the edge trips first. The original text here said E1
Task 1.9 would probe "whether these assets exist on this tier at all;
the likely answer is no". **That is corrected: they exist.** Unity
Gateway is live with thirteen governed models, so this task has a real
upstream and clause 2.5 becomes testable rather than theoretical.

That makes clause 2.5 the interesting part of this task rather than a
box to tick. "Set the serving cap above the gateway limit so the edge
trips first" is a statement about **precedence between two gateways**,
and it is only meaningful if both can be observed refusing. Build the
class E flows and route definitions from the CaC file as before — they
must stay reviewable and T-12-redeployable — then run T-15 and assert
the Gravitee limit trips first. If the tier allows setting a Unity
Gateway limit as well, invert the pair and capture the error body both
ways: a consumer who trips the edge and a consumer who trips the
upstream should not receive two unrelated error contracts, and nothing
in §5.2 would catch it if they do. Coordinate with E1 Task 1.9 part 3,
which owns the same question from the AI/ML Ops side.

A quota refusal on invocation is still possible and still lands under
A8 — but it must be recorded as *quota*, not as *availability*. That
distinction is the difference between a bounded finding and a
write-off, and the ARB package states it on the page where class E
appears, not in an appendix.

**Deliverable:** class E flows for M1 and M2 and the explicit M3 deny;
`tests/t15_model_route.py` written, possibly `NOT_RUN`; the layering
rule in `policy-classes.yaml` as `databricks_side_limit_must_exceed`.

**Verify:** M3 from the edge returns the protocol error format and not a
proxied response — this half is provable today and closes part of OD-8.

### Task 2.11 — T-24: the edge half of push ingest — CLOSED 2026-10-29

> **CLOSED. `EDGE_REFUSALS_ENFORCED_WITH_CORRECT_STATUSES` -- six
> refusals at the edge, each with a distinct and correct status, both
> positive controls reaching the upstream in the same run.**
>
> | refusal | policy | status | measured |
> |---|---|---|---|
> | R-METHOD | `resource-filtering` methods | **405** | GET and DELETE |
> | R-PATH | `policy-request-validation` | **400** | plain, encoded, double-encoded traversal |
> | R-OVERSIZE | `request-content-limit` | **413** | boundary bracketed; unit `BYTES_CONFIRMED` |
> | R-CONTENT-TYPE | `policy-request-validation` | **415** | wrong type and absent type |
> | R-OVERWRITE | `policy-request-validation` | **409** | with `overwrite=false` passing in the same run |
> | R-DIRECT | none -- reachability | 401 | narrower than §2.4.5 asks; see below |
>
> **A class the CONOPS does not define.** §2.3.3 gives five classes
> because §2.3.2 gives I-2 no route, so class I and route I1 are both
> AHEAD OF DOCUMENT and labelled so. `channels.yaml` had recorded the
> absence rather than inventing an id and was right to; the invention is
> now explicit, carries `exposure_sanctioned_by` quoting §2.4.5 on
> uploads being accepted only in the test environment, and carries its
> `confinement`. **v1.6 must give I-2 a route id in §2.3.2 and define
> class I.**
>
> **An asymmetry v1.6 should state.** PC-4 records that the egress deny
> class CANNOT say why -- `resource-filtering` has no status field, so
> route X answers a reasonless 403. `policy-request-validation` has
> `status` REQUIRED with the full code enum, so INGRESS refusals each
> give a correct specific reason and egress ones cannot. §2.3.2's error
> contract is met on one side of the gateway and not the other.
>
> **What this does NOT establish, named rather than implied.** The
> upstream path comes from CONCATENATION -- the endpoint carries the
> volume base path and Gravitee appends the request tail -- which is
> B-48's mechanism, NOT §3.2's rewrite capability. §3.2's row stays
> half-open and **R12 stays live**. Credential injection has a working
> precedent on the AI route and is deliberately not built here: §2.4.5
> requires a token refresher that does not exist, and **B-54's
> sequencing constraint forbade building it before R-PATH was
> measured**. R-DIRECT is narrower than §2.4.5 asks -- there is no
> producer gateway credential, because the plan is KEY_LESS pending
> OD-9, and no workspace address restriction is configured -- so what is
> measured is that this host cannot write to the volume path
> unauthenticated or with a bogus token, reported under its own name.
> Content scanning is absent and unowned (OD-9), which is why the route
> stays in the test environment: these refusals check the SHAPE of a
> request and say nothing about what is inside a file whose shape is
> permitted.
>
> **Deliverables:** class I in `policy-classes.yaml`; route I1 and the
> `files_api` target in `route-table.yaml`; `iac/config/producers.yaml`
> (new, and checked by `scripts/22`); `build_push_api()` in
> `scripts/29`; `tests/t24_push_refusals.py`. **Evidence:**
> `evidence/t24-push-refusals.json`,
> `evidence/ingest-policy-probe.json`,
> `evidence/ingest-policy-schemas.json`.

### Task 2.11 (original text) — T-24: the edge half of push ingest

T-24 belongs to E4 (AC4, self-service publish) and I-2 is **proposed**
under OD-9, not baselined. E2 owns only the edge enforcement: oversize
refused, wrong content type refused, wrong path refused, overwrite
refused, `GET` on an upload route refused, and a direct Files API call
refused.

The refusals are buildable now, before any landing volume exists,
because five of the six are pure edge concerns. Build them against a
stub upstream and hand E4 a route that already denies correctly. The
sixth — the direct Files API call — is a reachability assertion and
needs no upstream at all.

§3.2 flags *"path rewrite and upstream credential injection"* as an
unconfirmed capability for exactly this route, with *"thin ingest or
proxy service in front of the Databricks API"* as the fallback. Test the
capability here and record the result; E4 should not discover it.

**Deliverable:** class I flows with the six refusals; the capability
result for path rewrite and credential injection recorded;
`tests/t24_push_refusals.py` (edge cases only, E4 owns the allowed
upload).

**Verify:** all six refusals occur at the edge, each with a distinct and
correct status.

### Task 2.12 — Fill in the §3.2 capability table, then build the package

§3.2's seven-row table is the most honest thing in the CONOPS: seven
capabilities the design depends on, each *"not yet confirmed for the
Gravitee version in use"*, each with a fallback. Replacing those seven
"not confirmed" cells with observations against **CE 4.12.23** is this
epic's main contribution to the ARB.

| Capability needed | Used for | Test | Observed on CE 4.12.23 | Fallback taken? |
|---|---|---|---|---|
| Validate the agency JWT | OIDC option (OD-5) | T-09 | *to fill* | |
| Rewrite file URLs; forward signed storage requests incl. range | F1 / OD-1(b) | T-08 | *to fill — Task 2.9* | |
| Rate-limit key from the Authorization header | Per-consumer limits | T-05 | **Accepted by the server and now measured ENFORCING -- on one key.** T-05 phase 2 paced 68 requests at 0.8s against a 60/minute class A step keyed on `{#request.headers['Authorization']}`; the first 429 landed at request **61**, exactly where configured, and a 65s wait cleared it (`evidence/t05-report.json`). That measures the key is READ and the window counts. It does **not** measure ISOLATION between keys: two credentials firing concurrently to show separate buckets was not run, because the other two recipient credentials were expired at test time (the 24h activation lifetime, B-43). So the per-consumer claim rests on the route shape -- one API per recipient (B-42/D-9) -- with the key as a second line that is proven present and unproven separating. Recorded in the evidence file as `per_consumer_finding`. | No |
| Return 429 with a retry indication | Throttle behaviour | T-05 | **429 observed on both limits; the retry indication is confirmed ABSENT.** Measured verbatim 2026-10-30: spike 429s and rate 429s both carry `['connection','content-length','content-type','x-gravitee-client-identifier']` and nothing else -- no `Retry-After`, no `X-RateLimit-*`. The two are DISTINGUISHABLE, but only by body text (*"Spike limit exceeded!..."* vs *"Rate limit exceeded!..."*); status and headers are identical. Both clear after their window and the route answers 200 before and after, so a 429 is attributable to a throttle rather than to a broken route. Two findings came out of the bodies themselves: `5/s` is enforced as **1 per 200 ms** (smoothed -- first refusal at request 2 of a 10-request burst, not request 6), and `x-gravitee-client-identifier` survives on refusals because a request-phase interrupt skips the response chain (**B-55**). This is R9 realised and §3.2's fallback is exactly what was done -- record the actual response -- so the fallback is TAKEN, not failed. v1.6 owes reference clients their own backoff. | Yes -- record-as-observed |
| Deny by default for unlisted routes | Route X | T-02, T-03, scripts/36 | **Explicit catch-all deny, built and measured.** `resource-filtering` whitelist derived from the forwarding flows' own selectors; 7/7 unlisted paths refused at the edge, controls 200 either side (`evidence/unlisted-path-probe.json`). Deny-by-default is **not** native — an unmatched flow is *forwarded*, which is B-48 — so §3.2's fallback was the only route. Limit: reasonless 403, not the protocol error format (PC-4). | |
| Path rewrite and upstream credential injection | Push ingest, AI routes | T-15, T-24, scripts/38 | **Split verdict -- the halves are not in the same state.** INJECTION: working and confirmed on the AI route. `scripts/05` sets `databricks_upstream_token` as an API property and re-reads it off the server to confirm (`PUT_AFTER_CREATE_DROPPED_THEM`), so the producer never holds the credential. REWRITE: **NOT demonstrated.** I1's correct upstream path comes from CONCATENATION of the endpoint's deep base path with the request tail -- B-48's mechanism, one target edit from being gone -- and scoring that as a rewrite would be a false capability claim. `dynamic-routing` is the candidate and its schema is measured (`rules[].pattern` regex plus `rules[].url`, both REQUIRED, both EL-capable), untested because it needs the landing volume to exist. **R12 stays live and §3.2's fallback -- a thin ingest service in front of the Databricks API -- is still on the table.** | Injection: no. Rewrite: undecided |
| Client certificate support in reference clients | §2.3.4 | T-09 | *to fill* | |

Two rows will likely stay open. JWT validation is downstream of OD-5,
which is Open (13.2), so the honest entry is "not applicable until OD-5
decides" rather than a result. Client certificate support (R10) is a
property of the *reference clients*, not of Gravitee — so it is tested
by attempting a client-cert handshake from `delta-sharing` and
`python-docx`-era tooling, and §2.3.4 already names the fallback:
the address allow-list plus the recipient IP list carry the binding.

Then assemble Story 3. The package needs: the consolidated route table
and its generator, the policy classes with starting *and* tuned values,
the six evidence records, the filled capability table, and the §6
principles AC2 supports — layered enforcement, tested-not-asserted, and
the compute-protection argument from clause 2.5.

Three things stated on the first page rather than discovered.
**OD-1 is decided by T-08 and due 10/26** — lead with the
recommendation. **T-07 was failing before this epic**, and the before/
after capture is the strongest single piece of evidence in the package;
present it as a found-and-fixed control, not as a clean sheet. And
**B-1 was misdiagnosed for a day** — the corrected diagnosis belongs in
the package's lessons section, because "we built against an assumed
endpoint URL instead of the issued one" is a mistake the production
build can avoid for free.

**Deliverable:** `docs/epics/E2-arb-package.md` with the capability
table filled, evidence references, and the OD-1 recommendation.

**Verify:** every AC2 clause (2.1–2.5) traces to evidence or to a named
gap; all seven capability rows carry an observation or a reason they
cannot yet have one.

---

## E2.2 IaC and CaC deliverables

> **RECONCILED — the paths in the table below are wrong.**
>
> Gravitee artifacts live at **`gravitee/`**, not `iac/gravitee/`.
> `iac/gravitee/` exists and is **empty**; delete it so nothing gets written
> there. What actually exists:
>
> | The table says | Reality |
> |---|---|
> | `iac/gravitee/api-definition.json` | `gravitee/generated/api-e1-<slug>.json` (one per recipient), `api-f1-storage-proxy.json`, `api-m1-ai-gateway.json`, with `gravitee/generated/route-family.json` as the manifest |
> | `iac/gravitee/schemas/query-body.schema.json` | **still missing — PC-1 / RF-2** |
> | `iac/gravitee/shared-policy-groups/` | common set declared in `iac/config/policy-classes.yaml`; **not deployed as Gravitee objects** |
> | `iac/config/response-header-allowlist.yaml` | not created; T-07's `removeHeaders` list lives in `policy-classes.yaml` and is **unverified — PC-5 / RF-4** |
> | `iac/config/gateway-env.yaml` | not created; the discrete Mongo and Elasticsearch properties are inline in `docker-compose.yml` |
> | `scripts/gen_gravitee_api.py` | superseded by `scripts/29_...` and `scripts/30_...` — **do not create it** |
>
> `gravitee/api-definition.json` is the retired original, carried forward
> rather than deleted (B-19). Its policy-id verification is what
> `policy-classes.yaml` inherited, which is why it is kept.

| Path | Contents |
|---|---|
| `iac/gravitee/api-definition.json` | **Generated** V4 definition — one API, correct target, all flows |
| `iac/gravitee/schemas/query-body.schema.json` | §2.3.3 body schema for S8/S9, `additionalProperties: false` |
| `iac/gravitee/shared-policy-groups/` | Common policy set: allow-list, bearer check, correlation ID, header strip, logging |
| `iac/config/policy-classes.yaml` | Classes A–E: starting values, tuned values, and what changed them |
| `iac/config/response-header-allowlist.yaml` | T-07 allow-list, correlation ID named as the exception |
| `iac/config/gateway-env.yaml` | The Elasticsearch and **MongoDB** discrete properties, with the reason inline |
| `scripts/gen_gravitee_api.py` | Route table + policy classes → API definition |
| `scripts/05_import_gravitee_api.py` | Rewritten: management v2, idempotent by cross-ID, deploy-after-update, `--prune` |

The generated definition is committed. Generated-and-committed gives
reviewable diffs and keeps T-12 honest; generated-and-gitignored means
the thing that actually ran is not in version control.

No secrets in any of these — upstream tokens are `.env` or vault
references per §3.6.

---

## E2.3 Tests owned or co-owned

| Test | Verdict | Owner epic | Note |
|---|---|---|---|
| T-01 | BUILD | **E1** | Needs this epic's Task 2.1 to land first |
| T-03 | BUILD | E2 | Passed 10/17; must be re-run post-consolidation |
| T-05 | BUILD | E2 | The headline AC2 test; needs the Mongo keys |
| T-06 | BUILD | E2 | Four cases, including the positive |
| T-07 | BUILD | E2 | **Currently failing**; before/after capture required |
| T-08 | PARTIAL | E2 | Direct-storage refusal not fully testable here |
| T-11 | — | **E5** | E2 injects the correlation ID; E5 proves the trace |
| T-15 | PROBE (narrowed 10/18) | E1 probe, E2 limits | Real upstream now exists; clause 2.5 precedence is testable, not theoretical |
| T-24 | PARTIAL | **E4** | E2 owns the six edge refusals |

---

## E2.4 Exit criteria

> **RECONCILED.** The first sentence below — *"Exactly one Gravitee API
> exists"* — is withdrawn; see Task 2.1. Read the paragraph with these
> substitutions, and treat §E2.6 as the operative checklist:
>
> - *"exactly one API"* -> **one API per resolved recipient, plus F1, plus M1**,
>   all generated from the CaC files, none hand-maintained, both legacy APIs
>   deleted.
> - *"B-1 is reclassified ... and B-3 is resolved"* -> **both already done.**
>   B-3 / D-4 is resolved in `route-table.yaml`: F1 has its own
>   `storage_proxy_listener` at `/storage-proxy`.
> - *"T-03, T-05, T-06 and T-07 pass with evidence records"* -> **T-03 already
>   passes.** T-05, T-06 and T-07 remain, and none of their test modules exist.
> - Add: **RF-1 ... RF-6 and PC-1 ... PC-5 are each closed, or carried forward
>   with a stated reason.** An epic that leaves its own generators' declared
>   gaps unaddressed has not finished.

The epic is done — for the prototype's purposes — when all of the
following hold:

Exactly one Gravitee API exists, generated from the E1 CaC files, with
the upstream target taken from the issued credential file rather than
assumed; running the import repeatedly does not change that count.
Blocker B-1 is reclassified in the baseline document with the proxied-
404 body as evidence, and B-3 is resolved by giving F1 its own listener.
Policy classes A–E exist as configuration, with the common set in a
shared policy group, and a request touching a rate-limited route returns
promptly rather than hanging. T-03, T-05, T-06 and T-07 pass with
evidence records, and T-07's record carries both the before and after
header captures. T-05 demonstrates the Databricks side receiving fewer
requests than were sent, and the tuned values are written back to
configuration. T-06 rejects three bad bodies and accepts one good one,
all four in the protocol error format where applicable. T-08 produces an
OD-1 recommendation grounded in what the gateway actually did, including
if what it did was fail the body rewrite. The six T-24 edge refusals
work against a stub. Class E flows and the M3 deny exist whether or not
an AI asset was found. All seven §3.2 capability rows carry an
observation or a stated reason they cannot.

---

## E2.5 What this epic cannot close

| Item | Needs | Reference |
|---|---|---|
| OD-5 sign-in method | Data Governance decision | 13.2; JWT-validation row stays open |
| 1636 front door and its relation to Apigee | Data Tooling | §3.2 records it unconfirmed |
| The 10/19 "tested with Data Tooling" checkpoint | A Data Tooling environment and a counterpart | §3.2; locally we can only self-test |
| T-08 direct-storage refusal | Storage-account network controls on the tenant | 12.2; PARTIAL verdict |
| ~~T-15 positive~~ | ~~A model serving endpoint on the tier~~ — **removed 10/18**; thirteen governed models are live, only invocation is unproven and that is ours to test | R11 downgraded; ask 9 re-scoped |
| Client certificate support (R10) | Reference client behaviour, then a decision | §2.3.4; fallback already named |
| Production-scale limit values | Real consumer traffic profiles | §2.3 — starting values only |

Each leaves the epic as a dated ask, not as an empty cell in the ARB
package.

---

## E2.6 Reconciliation appendix — added 2026-10-25

### E2.6.1 The import ordering, which is a landmine

**Delete the two legacy APIs BEFORE importing the route family.** This
reverses advice that stood in this repository until 2026-10-21; the
retraction is recorded in `gravitee/generated/route-family.json` under
`retired.retire_in_gravitee_by_retracted_because`.

A Gravitee context path is a **prefix**. The legacy API at
`/opensharing-demo/` therefore collides with every
`/opensharing-demo/<slug>` listener in the family: it does not merely
survive the import, it **blocks** it. On the 2026-10-21 run only the F1
storage proxy imported, because `/storage-proxy/` was the one path with
no collision.

The old advice — *"keep the old route as a working comparison until T-01
passes"* — was false on its own terms, and that is why it survived. That
API has **zero flows**, so no perimeter policies at all, and its upstream
is pinned to the sharing host of a credential that expired 2026-10-18. It
could not produce a successful read for any recipient and never could.
Worse: because it prefix-matches, it **answered** the family's paths by
forwarding them upstream with the recipient slug glued into the protocol
path, producing Databricks 404s that read like gateway refusals. That is
B-44, and the sentence recommending the old route is what kept the
blocking object alive long enough to cause it.

Order of operations:

1. Stop the API at `/opensharing-demo/`, close its plans, **delete** it.
2. Stop and delete the legacy `/delta-sharing/` API
   (`a45a3c30-1f35-4d86-9a3c-301f359d869d`). Its target is wrong in both
   host and path (B-42), and `route-table.yaml` already records its
   listener as RETIRED — so the live object and the configuration
   disagree until this is done.
3. Import the generated family.
4. Re-run T-01 **per recipient**, each against its own credential file.
   A single-endpoint T-01 passes or fails for reasons that have nothing
   to do with the gateway.

### E2.6.2 The actual backlog, from the generators' own registers

These were written by E1's generators against what was actually built,
which is why they supersede the task numbering above.

| id | What is incomplete | Lands in |
|---|---|---|
| **RF-1 / PC-4** | Route X, the deny catch-all, is emitted **disabled** — the terminal-deny policy shape is unconfirmed on this installation. Unmatched paths fail closed by accident, not by decision | Task 2.4. The same change carries B-48's estate half when the terminal allow-list reaches the sharing and storage APIs |
| **RF-2 / PC-1** | `query-body.schema.json` does not exist, so class B runs the permissive json-validation fallback | Task 2.7. T-06 can only return `CANNOT_SEE` until it is written. The allowed field list is already declared in `route-table.yaml` under S8, so this is mechanical |
| **RF-3 / PC-3** | F1 forwarding is disabled and the S8/S9 URL rewrite is `NOT_BUILT` — no verified ndjson-aware body-rewrite policy, no static storage target | Task 2.9. **This is what decides OD-1**, and OD-1 is the one decision with a dated checkpoint |
| **RF-4 / PC-5** | T-07's expanded `removeHeaders` list is a hypothesis: four header names were added after a measured leak and have never been re-tested | Task 2.8. The before/after capture is the strongest single evidence item in the AC2 package |
| **RF-5** | `GAP-ICEBERG` has no route, so `/iceberg` falls to the catch-all, while the rewritten credential's `icebergEndpoint` points straight at it | Task 2.3. Give it a route or an **explicit** deny |
| **RF-6** | One API per recipient makes recipient onboarding a gateway change | **Not E2's to fix.** It is an AC4 wording change for v1.6, or the self-service portal calls this generator. Raise it; do not absorb it |
| **PC-2** | S10's path is a candidate expansion, not confirmed | Task 2.3. Settle the path, then regenerate — a selector that matches nothing produces a catch-all refusal that reads like enforcement |

### E2.6.3 Still genuinely E2, and not covered above

- **T-05** — rate limit, spike arrest, and the Databricks side receiving
  strictly fewer requests than were sent. The headline AC2 test, and the
  one assertion that cannot be satisfied by reading configuration. Also
  the two bursts that make spike arrest and rate limit separately
  attributable.
- **T-24's six edge refusals** — buildable now against a stub, before any
  landing volume exists. Five are pure edge concerns and the sixth is a
  reachability assertion needing no upstream at all.
- **`scripts/05_import_gravitee_api.py`** — still not idempotent
  (Task 2.2). It also defaults the management URL to
  `http://localhost:8083` when the variable is missing, and prints local
  console and portal URLs on success. On a re-pointed environment that is
  a confident success message about the wrong gateway. Fix both in one
  pass, and make the missing-variable case fail rather than default.
- **The §3.2 capability table** — seven rows, each still "not yet
  confirmed for the Gravitee version in use". Replacing them with
  observations against CE 4.12.23 is this epic's main contribution to the
  ARB. Two rows will honestly stay open: JWT validation is downstream of
  OD-5, and client-certificate support is a property of the reference
  clients rather than of Gravitee.

### E2.6.4 Tests that exist, and tests that do not

Present: `t01`, `t02`, `t03`, `t04`, `t15`, `t16`, `t19`, `t20`, `t21`,
`e2_egress_d2d`, `b32c_change_propagation`, `run_verification_session`.

**To write in this epic: `t05`, `t06`, `t07`, `t08`, `t24`.**

Every one of them must carry a run in which the control was observed
**absent**. That is E1's single most transferable rule, it is the reason
both of E1's real findings exist, and a perimeter test that never observes
the perimeter absent is measuring the wrong thing.

### E2.6.5 What E2 must not re-do

Four things are already built and evidenced. Re-doing any of them costs
time and risks regressing a passing control:

- The route-table-to-API generation (`scripts/29`, `scripts/30`).
- `policy-classes.yaml` as configuration, with its policy ids verified
  against this installation's own schema endpoints.
- T-03, T-15 and T-16 — all passing, all with evidence records.
- B-1's reclassification and B-3 / D-4's resolution.

And one thing is not a gap at all: `allow-lists.yaml` was superseded by
per-recipient `ip_access_list` entries in `recipients.yaml`.
