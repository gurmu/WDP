# AC2 package — Epic 2 (T04-11), traffic control at the gateway

**AWOZ-1227 / INC17 milestone 1227 · Epic 2 · prepared 2026-10-29, revised 2026-10-30**
**Platform: Gravitee APIM CE 4.12.23, Databricks OpenSharing (US-East-2)**

Every figure in this package is traceable to a file under `evidence/`.
Where something is not measured, this document says so in the same
sentence rather than in a footnote. That is the one editorial rule here,
and it is the reason the package is shorter than it could be.

---

## 1. The three things worth reading first

**1. §3.2's capability table was the honest centre of the CONOPS, and
four of its seven rows now carry an observation against CE 4.12.23.**
That table listed seven capabilities the design depends on, each marked
"not yet confirmed for the Gravitee version in use", each with a
fallback. Replacing those cells with measurements was this epic's main
contribution. Three rows are answered, one is answered in part and says
which part, and three cannot be answered yet for reasons named in §4.
Three of those cells moved from one test, T-05: two on 2026-10-30 and
the rate-limit key row on 2026-11-02, when a fifth phase measured the
key separating rather than merely being read.

**2. T-07 was a found-and-fixed control, not a clean sheet, and the
before/after record is the strongest single piece of evidence here.**
When this epic opened, a 200 from the sharing route returned
`server: databricks`, `x-request-id`, `server-timing` and three
`X-Gravitee-*` headers to the caller. All six are now absent, measured,
with a positive control proving the sanitizer runs rather than the
upstream having stopped sending them. One of those headers had been
captured leaking on 2026-10-18, written into the epic's own task text,
and never added to the removal list — it was gone within minutes of
being put there. That is a deny-list failing exactly as the task
predicted, inside the task that predicted it.

**3. The route table did not enforce anything, and the gateway's
default is to FORWARD.** B-48. An unmatched flow in Gravitee is not
refused; it is passed upstream. The sharing routes only looked confined
because a stray path was appended to a deep endpoint base path and
missed — confinement by string concatenation, a property of how two
strings join rather than a decision, and one target edit from being
gone. This mechanism appeared **three times** in this epic, the third
time in a route built *after* B-48's closure was written, by the author
who wrote it. We present it as a structural property of this gateway
rather than as three mistakes: **anything not explicitly refused at a
Gravitee edge is forwarded, and a test that does not observe the
refusal is measuring the upstream.**

**4. Two of this epic's findings came out of reading a refusal body
instead of a status code.** T-05's 429s were expected to be routine.
Their bodies said `5/s` is enforced as **1 request per 200 ms** — the
gateway smooths the window, so a client sending five requests inside
100 ms has four refused while nominally within a 5/s limit — and their
*headers* carried `x-gravitee-client-identifier`, the header Task 2.8
had measured removed. Both are real: the remove-list works, and it sits
in the response phase, which a request-phase refusal never reaches
(**B-55**). Header sanitization therefore covers successes and not
refusals. The disclosure is small — a product name and an opaque id —
and the correction is to the *claim*, which read total. The method point
is the one worth carrying: **a test whose probes all succeed can only
ever confirm the half of a control that successes exercise.**

### The OD-1 recommendation

**OD-1 is not decided by this epic and we recommend deferring it rather
than deciding it on absent evidence.** OD-1 turns on T-08 — whether the
gateway can rewrite file URLs and forward signed storage requests
including range headers — and T-08 is not runnable here. F1's upstream
host exists only inside the pre-signed URL in an S8/S9 response body,
so there is no static target to configure; the listener and policy chain
are real and the forwarding step is not (`FORWARDING_DISABLED`,
`evidence/gravitee-route-family.json`). On Free Edition, storage is
Databricks-managed, so T-08's refusal half is not provable either.

What we can say: §2.3.2's documented fallback — storage address limits
plus short-lived credentials — is intact and needs no gateway capability
we have failed to find. **Recommendation: carry OD-1 to the client
environment and decide it on T-08 there, with option (b) as the working
assumption** because it is the only branch that does not depend on an
unproven rewrite. The decision is cheap to defer and expensive to get
wrong.

---

## 2. AC2 against the CONOPS's own requirement rows

**CORRECTED 2026-11-02, and the correction matters to anyone reading
this beside the document.** Earlier revisions of this package numbered
five "AC2 clauses 2.1 to 2.5" that were *our* decomposition of the work,
not the CONOPS's. The CONOPS already numbers five AC2 requirement rows
2.1 to 2.5, and they are different rows. Using the document's numbers
for our own decomposition is the worst of both worlds: a reader with
§3.2 open sees "2.1" here and reads a requirement that is not the one
being discussed.

So this section now leads with **the document's rows**, and our own
decomposition is renamed to **control areas A to E** and kept below,
because it is still the useful engineering view — it is simply not the
acceptance criterion.

### 2a. The CONOPS's AC2 requirement rows

Verbatim from the AC2 requirement table, with the tests the document
itself assigns:

| # | Requirement (milestone wording) | Tests the CONOPS assigns | State |
|---|---|---|---|
| **2.1** | exposure of Databricks endpoints through Gravitee | T-01, T-08, T-15 | **Evidenced in part.** T-01 passes where observable — every discovered protocol path returns through the edge with a body identical to the same path read directly, for two recipients. **T-08 is deferred** (no static upstream; §4.2) and **T-15 is partial** (injection confirmed, no live serving endpoint). One of T-01's recipients is unobservable from this host by design — see §4.10. So the row is carried by one of its three tests and partly by a second. |
| **2.2** | enforced rate limits | T-05 | **Evidenced, both halves.** First 429 at request **61** of a 60-per-minute window; the window clears and the route answers before and after. And the key *separates*: with one key's bucket full, a different authorization value is not throttled while the first is confirmed still throttled either side of the probe. |
| **2.3** | spike arrest | T-05 | **Evidenced, with a shape finding.** Trips as configured, and `5/s` is enforced as **1 per 200 ms** — the gateway smooths the window. First refusal at request 2 of a 10-request burst rather than request 6. |
| **2.4** | request schema validation | T-06 | **Evidenced.** Three rejections and two acceptances, each body sent direct and through the edge in the same run. |
| **2.5** | to protect compute resources | T-05, T-15 | **NOT evidenced.** The throttles are measured firing and clearing; nothing here demonstrates the edge tripping *before* Databricks, which is what this row asks. Needs the access audit table. §4.1. |

**The honest score on the document's numbering: two rows evidenced
outright (2.2, 2.4), one evidenced with a finding attached (2.3), one
evidenced in part (2.1), one not evidenced (2.5).** An earlier revision
of this package said "four of five clauses evidenced". On our own
numbering that was defensible; on the document's it overstates row 2.1,
because two of the three tests the CONOPS assigns to it could not run
here.

**Where T-07 sits.** No numbered requirement row names it. §3.2's prose
carries the obligation instead — *"credentials and response bodies are
never logged"* — and the AC map assigns T-07 to AC2. It is reported
under control area B below rather than against a row it does not have.

### 2b. Our control areas, renamed so they stop colliding

These are the five areas the engineering work was organised around.
They are **not** the acceptance criterion's rows and are no longer
numbered as though they were.

| Area | What it requires | State | Evidence or gap |
|---|---|---|---|
| **A** | The gateway is the only public surface; the caller never holds a Databricks credential | **Evidenced (egress), evidenced in part (ingress)** | Egress: every recipient reads through the edge with a body identical to the direct read — `evidence/t01-gateway-read.json`. The recipient *does* hold a Delta Sharing bearer token by construction of the protocol, which §1 already treats as the architectural principle; Gravitee does not validate it. Ingress: the producer holds nothing (KEY_LESS) but the upstream credential is **not injected** — see the gap in §4. |
| **B** | Internal headers and hostnames removed from the response | **Evidenced, found-and-fixed** | `evidence/t07-header-sanitization.json`, with before/after captures on `/shares` and S7. Six headers removed; three required a gateway setting no policy could reach (B-52). One accepted limit: the allow-list is enforced by the test, not the gateway — see §4. |
| **C** | Routes are explicit; routes not listed are denied | **Evidenced in both directions** | Permissive half: T-01 at 3/4, `GATEWAY_READ_FAITHFUL_WHERE_OBSERVABLE`. Refusing half: `evidence/unlisted-path-probe.json`, 7/7 unlisted paths refused at the edge with controls returning 200 either side. Deny-by-default is **not native**; §3.2's explicit catch-all fallback was the only route. |
| **D** | Request validation at the edge | **Evidenced** | Class B body schema: `evidence/t06-body-schema.json` — three rejections and two acceptances, each body sent direct and through the edge in the same run. Ingress: `evidence/t24-push-refusals.json` — six refusals, each with a distinct and correct status. |
| **E** | Throttling to protect compute resources | **Evidenced in part. The clause itself remains a named gap.** | **What is now measured** (`evidence/t05-report.json`, 2026-10-30): both limits trip where configured and both clear. Rate limit: first 429 at request **61** of a 60/minute window, keyed on the Authorization header. Spike arrest: first 429 at request **2** of a 10-request 0.2s burst, because `5/s` is enforced as 1 per 200 ms. The route answers 200 before the burst and again after a 65s wait, so a 429 is attributable to a throttle and not to a broken route. Neither 429 carries a retry indication. **What is still not measured is clause 2.5's actual content** — that the edge trips *before* Databricks — because demonstrating it requires counting requests that reached the upstream, which needs `system.access.audit`, a system table this tier does not expose. A 429 at the edge is consistent with the upstream never being called and does not demonstrate it. Recorded as `clause_2_5_not_measured` in the evidence file rather than inferred. Owner: client environment. |

**The summary, on both numberings.** On our control areas: four
evidenced, one — area E, throttling *to protect compute* — measured in
mechanism and unevidenced in claim. On the CONOPS's rows: 2.2 and 2.4
evidenced, 2.3 evidenced with the smoothing finding, 2.1 evidenced in
part because T-08 and T-15 could not run here, and 2.5 not evidenced.

Both numberings agree on the one that matters: the throttle demonstrably
fires and clears at the configured points, which is more than a
configuration listing, and less than the requirement asks, which is
compute *protection*. The gap between the two is one system table wide.
We would rather state it than let a 429 stand in for it.

---

## 3. §3.2's capability table, against CE 4.12.23

| Capability needed | Used for | Test | Observed on CE 4.12.23 | Fallback taken? |
|---|---|---|---|---|
| Validate the agency JWT | OIDC option (OD-5) | T-09 | **Not applicable until OD-5 decides.** OD-5 is Open (13.2) and the prototype builds the bearer-token branch. Reporting a JWT result would imply a decision nobody made. | n/a |
| Rewrite file URLs; forward signed storage requests incl. range | F1 / OD-1(b) | T-08 | **Cannot be measured here.** No static upstream — the host lives inside the pre-signed URL. Free Edition's storage is Databricks-managed, so the refusal half is unprovable too. | Documented fallback intact |
| **Rate-limit key from the Authorization header** | Per-consumer limits | T-05 | **Answered — measured enforcing AND separating.** Phase 2 trips at request **61** of a 60-per-minute window, which proves the key is read and the window counts. Phase 5 then fills that key's bucket and probes with a different authorization value: the probe is **not** throttled while the first key is confirmed throttled on both sides of it. So the bucket is per authorization value, not one per API. **Scope, stated not buried:** two *legitimate consumers* on one route cannot be tested here at all — the host/token binding refuses a foreign credential on another recipient's route (T-01b), so this family has no shared route and the question has no subject in this topology. The row's claim is about the key, and the key is answered. | No |
| **Return 429 with a retry indication** | Throttle behaviour | T-05 | **429 on both limits; the retry indication is confirmed ABSENT.** Captured verbatim: both throttles return `['connection','content-length','content-type','x-gravitee-client-identifier']` and nothing else — no `Retry-After`, no `X-RateLimit-*`. The two are distinguishable, but **only by body text** (*"Spike limit exceeded!…"* vs *"Rate limit exceeded!…"*); status and headers are identical, so an operator reading status codes cannot tell a burst from a quota. This is **R9 realised**, and §3.2's named fallback is precisely what was done — record the actual response — so the fallback is *taken*, not failed. Consequence for §2.3.4: the reference clients need a backoff of their own, because nothing tells them when to retry. | **Yes — record-as-observed** |
| **Deny by default for unlisted routes** | Route X | T-02, T-03, `scripts/36` | **Explicit catch-all deny, built and measured.** `resource-filtering` whitelist derived from the forwarding flows' own selectors; 7/7 unlisted paths refused, controls 200 either side. Deny-by-default is **not** native — an unmatched flow is forwarded (B-48). Limit: a reasonless 403, not the protocol error format (PC-4). | **Yes — fallback was the only route** |
| **Path rewrite and upstream credential injection** | Push ingest, AI routes | T-15, T-24, `scripts/38` | **Split verdict.** *Injection:* working, confirmed on the AI route — the token is set as an API property and re-read off the server, so the producer never holds it. *Rewrite:* **not demonstrated.** I1's correct upstream path comes from concatenation of a deep base path with the request tail — B-48's mechanism — and scoring that as a rewrite would be a false capability claim. `dynamic-routing` is the candidate, its schema is measured, and it is untested because it needs the landing volume to exist. | Injection: no. Rewrite: undecided, **R12 live** |
| Client certificate support in reference clients | §2.3.4 | T-09 | **Not a Gravitee property.** This is a property of the reference clients, and §2.3.4 already names the fallback: the address allow-list plus the recipient IP list carry the binding. | Fallback named |

**Seven rows: three answered, one answered in part, three with a stated
reason they cannot be answered yet.** The rate-limit key row moved from
*in part* to *answered* on 2026-11-02 when T-05 phase 5 measured the key
separating, not merely being read. No row is blank and no row claims
more than was measured. Two cells moved on 2026-10-30 — the 429 row from
*unknown* to *confirmed absent*, and the rate-limit key row from
*accepted* to *enforcing, on one key*. The same test narrowed a claim
elsewhere in this package; see §4.8.

---

## 4. Named gaps

Each of these is a thing the ARB should know is missing, with who owns
it. None is hidden in a table above.

1. **Requirement row 2.5 is unevidenced — the row, not the mechanism —
   and the ask has changed shape.** The throttles are measured firing
   and clearing at the configured points. What is missing is evidence
   that the edge trips *before* Databricks.

   **Measured 2026-11-03, and the result was not the one expected.**
   `system.access.audit` **is readable here** — a SQL warehouse exists
   and the table queries fine. But a read that demonstrably succeeded
   through the edge produced **no audit row in 105 seconds**. The table
   is readable and blind to this traffic: the action names may differ on
   this tier, Delta Sharing reads may not be audited at this tier, or
   the rows may land elsewhere.

   So the request to the client platform is **not** "enable the system
   catalog" — it already is. It is "an audit surface that records Delta
   Sharing reads, and the action names it records them under". Asking
   the first would have spent a cycle on a resource we already have.

   **Why the test refused instead of counting.** Had it gone straight to
   the burst, it would have reported *zero upstream requests against
   sixty-eight sent* — total compute protection, the strongest claim in
   this package, and entirely an artefact of a blind table. The positive
   control runs first for that reason and cost two minutes.

   **The alternative was tried and is also blocked.** The claim is about
   what the gateway *forwarded*, and a request interrupted in the
   request phase is never forwarded — so the gateway should be able to
   answer it. It cannot: its request documents carry eight fields, all
   entrypoint, with **no endpoint or upstream field at all**. The v4
   analytics here report what entered and what the client got, and are
   silent on what happened in between
   (`CANNOT_SEE_NO_UPSTREAM_MARKER_FIELD`, refused before counting).

   **Both routes to this row are therefore closed in this environment,
   for two different reasons**, and the ask is in two parts: an audit
   surface that records Delta Sharing reads, **or** gateway analytics
   that emit endpoint-level metrics. Either settles it.
2. **The response-header allow-list is enforced by CI, not the
   gateway.** `transform-headers` can add and remove named headers; it
   cannot express "keep only these", and no installed policy can
   (measured against 79 policy schemas). A header a new upstream version
   starts sending reaches clients until the next test run. Closing it
   needs a component in front of the gateway that strips by allow-list —
   the corporate-side answer. Owner: E6/architecture.
3. **The protocol error format is not achievable on the egress deny
   path.** `resource-filtering` has no message, body or status field and
   a response-phase carrier does not run after an interrupting policy
   (PC-4, measured). §2.3.2's "denied in the protocol error format" is
   met on **ingress** and not on **egress** — an asymmetry v1.6 should
   state rather than imply.
4. **Path rewrite is unproven; R12 is live.** See §3. Owner: E2/E4 in
   the client environment.
5. **Push ingest has no content scanning and no owner.** §2.4.5 calls it
   a platform security capability, not a gateway policy, and OD-9 leaves
   it unnamed. The route is confined to the test environment for that
   reason, and the six refusals passing does not widen it: they check the
   **shape** of a request and say nothing about what is inside a file
   whose shape is permitted. Owner: OD-9, unassigned.
6. **Recipient credentials expire 24h after they are CREATED, against a
   configured 7 days.** Measured on three recipients for three.
   **Corrected 2026-11-02:** this read "24h after activation" until
   three activation links written on 10-30 were first exchanged on
   11-02 and all three were refused — 404, activation nonce not found —
   with the token records showing expiry exactly 24h after creation and
   the links never consumed. The two readings were indistinguishable
   while every rotation was activated minutes later. The operational
   consequence is sharper than the old wording: a rotation not activated
   in the same session is a wasted token, not a pending activation. Every
   credential needs re-activating the morning of a demo, and AC4's
   self-service portal inherits a daily re-activation step nobody has
   costed. Owner: Data Governance / OD-3.
7. **Two route-table rows are ahead of §2.3.2, not one.** Both are
   labelled `ahead_of_document` and the static gate names both on every
   run:
   - **Class I and route I1 (push ingest).** §2.4.5 describes the
     channel and gives it no route id and no policy class. Both were
     invented deliberately and carry what sanctions their exposure.
   - **Route S11 (`/iceberg`), an explicit deny.** Found while repairing
     an unrelated bypass, which made the Iceberg endpoint rewrite to our
     edge and exposed a hole the bypass had been masking. It is denied
     because it is a **second data plane** handing out credentials for
     direct object-store reads — precisely the bypass OD-1(b) exists to
     close. §2.3.2 has no row for it.

   v1.6 owes **both** a row. An earlier revision of this package named
   only the first, which understated the ask.
8. **Header sanitization covers successes, not refusals (B-55).** The
   remove-list in §2 is a response-phase step, and a request-phase
   policy that interrupts answers before the response chain runs. So
   every refusal the *perimeter* raises — 400, 405, 409, 413, 415, 429,
   route X's 403 — goes out unsanitized, while refusals from the
   **upstream** (401, 403 from Databricks) traverse the chain and are
   sanitized. The line falls on *who refused*, not on the status code.
   Found by T-05 on 2026-10-30, in a 429 it was not examining for this.
   What leaks is a gateway product name and an opaque per-caller id — no
   credential, no path, no upstream hostname — so the severity is low
   and the correction is to the claim, which read total. **Not fixable
   by a policy**, by PC-4's argument reversed: a response-phase step can
   no more remove a header after an interrupt than add one. Candidates
   are a gateway setting (B-52 found one for the `X-Gravitee-*` pair) or
   a component in front of the gateway — the same component gap 2 needs.
   **Measured 2026-11-02, not inferred.** Phase 3b probed two refusal
   types on purpose: an unlisted path (403, route X) and a wrong method
   on a listed path (405). Both leak `x-gravitee-client-identifier`.
   Two different request-phase policies producing the same leak is what
   makes this a property of the phase model rather than a quirk of one
   policy. Verdict `SANITIZED_ON_SUCCESS_BUT_NOT_ON_REFUSALS`.

   **T-07 therefore now reports FAIL**, where it reported PASS while it
   measured only successes. The control did not regress; the test
   stopped overstating. Whether the residue — a product name and an
   opaque caller id, on perimeter refusals only — is **accepted** is a
   decision for the AC2 reviewer, not a defect to be fixed here, since
   no policy can close it. Until that decision, this package reports the
   test as failing rather than quietly restating its pass criterion.
   Owner: E6/architecture, with gap 2.
9. **Asset scope is tables and views only.** R3 and OD-2 say to keep
   ARB claims at tables if model and volume sharing over open sharing is
   unconfirmed, and it is unconfirmed. Everything measured here is
   tables and views. No claim in this package extends further, and the
   register now carries it as a named scope limit rather than leaving it
   to be inferred.
10. **One T-01 check is unobservable from this host by design, not by
   outage.** The `t02-iplist` recipient exists to be refused — its
   address allow-list excludes this host, which is the whole subject of
   T-03. Its credential cannot be activated from here for the same
   reason the test it serves passes. That makes its T-01 row a
   **permanent** CANNOT_SEE from this environment rather than a transient
   one, and the distinction is load-bearing: a transient unseen is
   fixed by re-running, a structural one never is. Treating the two
   alike would make any completeness gate on this evidence
   unsatisfiable. Recorded so the next reader does not spend a day
   chasing a credential that is working as designed.
11. **`spike-arrest` is unkeyed, and 2.3.3 says "per consumer".** One
   bucket per API, while `rate-limit` beside it is keyed per credential.
   The requirement holds today only because the route family is one API
   per recipient (B-42/D-9), which makes the *route shape* load-bearing
   for a policy requirement. Any later consolidation onto a shared route
   reintroduces one caller throttling another, silently. v1.6 should
   either key spike arrest or state that the route shape carries it.
   Owner: E2/v1.6.

---

## 5. What AC2 supports, in §6's terms

**Layered enforcement.** Three layers were measured refusing
independently: the gateway edge (route X, 7/7 unlisted paths), the
recipient IP access list (T-03, refused and reversible), and Databricks
itself (the host/token binding, where a credential on another
recipient's route is refused with an error naming both halves). The
`t02-iplist` recipient is refused by *both* allow-lists at once, and
they do not even compare the same address — Databricks sees this host's
public NAT address, the gateway sees its container address. That is
layering working and is also why one of T-01's four checks is
permanently `CANNOT_SEE`.

**Tested, not asserted.** The method that produced this package is
worth more to the production build than any individual result:

- **A refusal must be attributed, not assumed.** Databricks answers 403
  and so does `resource-filtering`; status alone identifies nothing.
  Every probe here attributes by the responder's own voice. This was
  learned by getting it wrong: one probe read 403 as "the edge refused"
  from the status, and T-01 scored a 429 from its own spike-arrest as a
  policy refusal.
- **A perimeter test that never observes the perimeter absent is
  measuring the wrong thing.** T-01 green proves the perimeter does not
  over-refuse. It would be equally green against a whitelist that
  admitted everything.
- **A header absent from a response is not evidence of redaction.** Five
  of the eight names on the removal list were never sent by the upstream
  at all; counting them would have credited the sanitizer with work
  nobody did.
- **A positive control in the same run, on the same path.** A
  conditional refusal and a silently omitted policy look identical from
  outside, so `overwrite=false` must succeed in the same run as
  `overwrite=true` is refused.
- **Three verdict states, not two.** `CANNOT_SEE` is a result. Collapsing
  it into pass or fail is how a credential expiry becomes a gateway
  finding.
- **A control is only measured on the responses the test provokes.**
  T-07's probes all drove successful reads, so it measured header
  sanitization on successes and reported green while refusals went out
  unsanitized (B-55). Nothing was wrong with its reasoning; its *sample*
  was one-sided. The generalisation is uncomfortable and worth stating:
  for any response-phase control, ask which responses never reach that
  phase, and probe those on purpose.
- **Read the refusal body, not just the status.** The two findings of
  2026-10-30 — a 5/s limit enforced as 1 per 200 ms, and an
  unsanitized header on refusals — were both sitting in a 429 that a
  status-code reading scored as "throttled, as configured".

**The compute-protection argument (clause 2.5).** We cannot make it on
evidence yet, and we are not going to make it on configuration. The
argument requires showing Databricks logged fewer requests than were
sent, which is T-05 in the client environment.

---

## 6. Lessons for the production build

Four, each costed.

**B-1 was misdiagnosed for a day.** The route was built against an
assumed endpoint URL — `https://<host>/api/2.0/delta-sharing` — instead
of the one inside the issued credential, which is a per-recipient
sharing host with a metastore path. Wrong host and wrong path. The
production build gets this for free: **resolve every upstream from the
issued credential, never from a template.** It also means one route
cannot front all recipients, because the platform validates the
host/token binding — which is why the route family is one API per
recipient (B-42 / D-9).

**B-50 cost a full generate-import-test cycle, then recurred the next
day in a different frame.** The terminal allow-list derived its patterns
correctly from the flows' own selectors — and wrote them in the wrong
pattern language, because Gravitee selector paths name parameters
(`:share`) while `resource-filtering` whitelists are Ant patterns where
`:share` is five literal characters. The next day the same author wrote
a pattern in the right language and the wrong *scope*, including a
context-path prefix the filter never sees. **A derivation is only as
sound as its claim about how the consumer reads what was derived, and
that claim has to be written down somewhere it can be checked.**

**A configuration value changed so a gate passes is a disabled gate.**
Twice avoided deliberately: an `exposed: false` that would have let a
live route past an invariant, and a local-test CIDR that would have made
an IP filter permissive. Both are recorded (B-47) rather than taken.

**The repository's own diagnoses outran its fixes.** B-52's cause was
correctly diagnosed and recorded — "it is the wrong layer" — with
`status: OPEN -- v1.6 input`, for days before anyone looked for the
setting. §2.3.3's "metadata-only logging" sat unimplemented with nothing
failing, because no test asked the gateway whether it reported (B-53).
**A finding recorded is not a finding fixed, and a requirement nothing
tests is a requirement nothing enforces.**

---

## 7. Evidence index

| File | What it establishes |
|---|---|
| `evidence/t01-gateway-read.json` | Faithful reads through the edge; the host/token binding |
| `evidence/unlisted-path-probe.json` | 7/7 unlisted paths refused; Ant `*` does not cross `/`; per-entry methods constrain |
| `evidence/t03-refusal.json` | IP refusal at the edge, armed and reversed |
| `evidence/t06-body-schema.json` | Class B body schema: three rejections, two acceptances |
| `evidence/t07-header-sanitization.json` | Header sanitization, with before/after captures — and, from phase 3b, its extent on refusals |
| `evidence/t05-report.json` | Both throttles verbatim: trip points, bodies, headers, recovery; and `clause_2_5_not_measured` |
| `evidence/t24-push-refusals.json` | Six ingress refusals with distinct correct statuses |
| `evidence/t11-trace-correlation.json` | Correlation id reaches the caller and finds the gateway log |
| `evidence/ingest-policy-probe.json`, `ingest-policy-schemas.json` | Which installed policies can express which refusal, from their own schemas |
| `evidence/deny-policy-probe.json`, `deny-pair-probe.json` | The deny shape: no installed policy both refuses and emits a body |
| `evidence/cac-config-check.json` | 398 static checks across the CaC set |
| `evidence/gravitee-route-family.json`, `gravitee-import.json` | What was generated and what the server kept |
| `docs/11-environment-baseline.md` §11.7 | The blocker register, B-1 to B-55, plus the `spike-arrest` smoothing finding |
| `docs/14-conops-v1.6-inputs.md` | Every v1.6 input the repository has recorded, generated from source |

**Reproducing it:** `scripts/22` (static), then `scripts/29` →
`scripts/05` (generate and deploy), then the tests. Input hashes are
recorded in `evidence/gravitee-route-family.json` so that T-12's
"redeploy from code to a clean target yields the same configuration" is
checkable rather than asserted.
