# CONOPS v1.6 inputs, collected from the repository

**GENERATED** by `scripts/39_collect_conops_v16_inputs.py` at 2026-11-03T15:07:49.029943Z. Do not edit: the next run overwrites it. To add an item, write it where the finding lives -- in the config row or the blocker entry it came from -- and mention v1.6 there.

96 item(s) across 14 section(s), from 20 file(s).

## How to read this

Each item is a place where the prototype measured something the baselined document does not say, or says differently. The text is quoted from its source and the locator points back at it; nothing here is a new claim. An item is an INPUT, not a decision -- several of them are alternatives that v1.6 has to choose between, and the ones that need a decision rather than an edit say so in their own words.

**What this search cannot find.** It matches the literal string `v1.6`. A finding whose author wrote "the next revision" instead is invisible here, so the convention is to write `v1.6` when a finding owes the document something. That convention is the only thing keeping this index complete.

## §2.3 gateway design

7 item(s).

- **`docs/11-environment-baseline.md`** — line 160
  > | T-04 | Must be re-specified against a shared view, not a shared table. | | CONOPS v1.6 | Section 3.1, 2.3.1 and 3.4 need the "or apply column masks and row filters" clause struck, with this error as the evidence. This is a document defect to raise, not a local workaround. |

- **`docs/13-decisions-and-risks.md`** — line 94
  > > expressed as a view, the base table is never added to a share, and > §3.1 / §2.3.1 / §3.4 are corrected in v1.6. Owner: AI/ML Ops with Data > Governance. Evidence: 11.4.

- **`docs/13-decisions-and-risks.md`** — line 194
  > | 1 | Decide OD-5 (sign-in method, token lifetime, rotation, overlap, revocation triggers, approver) | Data Governance | Gates the 10/23 T04-10 package; five sub-decisions in §3.1.1 | | 2 | Accept OD-11 and correct §3.1, §2.3.1 and §3.4 in v1.6 | AI/ML Ops + Data Governance | The current text promises granular access by a mechanism that does not exist (11.4) | | 3 | Confirm OD-4 and take the reference implementation | Data Eng | It is built and tested; confirmation is now cheap |

- **`docs/epics/E2-T04-11-traffic-control.md`** — line 1078
  > | **RF-5** | `GAP-ICEBERG` has no route, so `/iceberg` falls to the catch-all, while the rewritten credential's `icebergEndpoint` points straight at it | Task 2.3. Give it a route or an **explicit** deny | | **RF-6** | One API per recipient makes recipient onboarding a gateway change | **Not E2's to fix.** It is an AC4 wording change for v1.6, or the self-service portal calls this generator. Raise it; do not absorb it | | **PC-2** | S10's path is a candidate expansion, not confirmed | Task 2.3. Settle the path, then regenerate — a selector that matches n [...]

- **`docs/epics/E3-1227-E3-data-governance.md`** — line 149
  > **Deliverable:** acceptance of OD-11 in the integration section; a note that CONOPS v1.6 must strike the "or apply column masks and row filters" language from §3.1, §2.3.1 and §3.4.

- **`docs/epics/E3-streamlining-inputs.md`** — line 292
  > | 3 | Approver roles and review-time targets | Data Governance | Before AC4 design | Self-service issuance | | 4 | **Acceptance** that granular access is view-based | Data Governance + ARB | With the v1.6 revision | CONOPS §3.1, §2.3.1, §3.4 text | | 5 | **Decision** on how revocation is expressed | Data Governance | Before the tier file names a control | The revocation clause in every template |

- **`docs/epics/E7-T04-14-compliance-packaging.md`** — line 99
  > Finding D-1 (Task 7.5) forces a design choice the CONOPS never considered, because it assumed both options were available. The CONOPS §3.1 promises granular access by "a view, **or** column masks and row filters". The masks and filters option does not exist on OpenSharing tables. Therefore, **every entitlement scope — column and row — must be expressed as a view**, the base table is never added to a share, and §3.1 / §2.3.1 / §3.4 need correction in v1.6.

## §2.3.2 route table

19 item(s).

- **`iac/config/channels.yaml`** — channels[4].routes_resolved_2026-10-29
  > I1 added to route-table.yaml as an AHEAD-OF-DOCUMENT row. The gap recorded below was right and is kept (B-19): §2.3.2 still gives I-2 no id and v1.6 must supply one. What changed is that Task 2.11 needs the six refusals built, and they cannot be built without a route -- so the invention is now explicit, labelled, and carries `exposure_sanctioned_by` (§2.4.5 permits uploads in the test environment only) plus `confinement`. Recording the absence was correct while nothing needed the route; it stopped being enough once something did.

- **`iac/config/channels.yaml`** — channels[4].routes_gap
  > §2.3.2 gives I-2 no route id. The push route is specified in §2.4.5 prose only, so the route table cannot express its policy class or its exposure decision. v1.6 should give it an id in §2.3.2 like every other exposed path; until then this file records the absence rather than inventing one.

- **`iac/config/policy-classes.yaml`** — classes.I.distinct_statuses_are_achievable_here
  > Task 2.11's Verify line wants six refusals "each with a distinct and correct status". PC-4 records that the egress deny class CANNOT do this: resource-filtering has no status field and a response-phase carrier does not run after an interrupting policy, so route X answers with a reasonless 403. policy-request-validation is different: `status` is REQUIRED, defaults to '400', and its enum carries every HTTP code including 409 and 415 (measured). So the ingress refusals can say WHY and the egress ones cannot, and v1.6 should note the asymmetry rather than im [...]

- **`iac/config/response-header-allowlist.yaml`** — allowed.delta_sharing_protocol.follow_up
  > Add delta-table-version to route-table.yaml S6/S7 passthrough_headers so the route table states it too, and raise it for CONOPS v1.6 §2.3.2, which names only the capability header.

- **`iac/config/route-table.yaml`** — edge.sharing_listener.cost_of_the_suffix
  > §3.4.1's promise that reference clients "need only the endpoint changed" SURVIVES, because the slug is part of the endpoint the client is handed in its rewritten credential. The client never learns its slug from anywhere else and never composes it. What does not survive is §2.3.2's claim that the edge path equals the protocol path: it equals the listener prefix PLUS THE SLUG plus the protocol path. v1.6 has to say so.

- **`iac/config/route-table.yaml`** — policy_classes.class_I_is_ahead_of_document
  > §2.3.3 defines five classes, A-E, because §2.3.2 gives I-2 no route. Class I was added 2026-10-29 for E2 Task 2.11: the six push refusals could not be written without a class to hold them. scripts/22 keeps it OUT of its CONOPS_CLASSES map and asserts it separately, so the checker can still tell what §2.3.3 says from what this prototype added, and it fails if a documented route is ever assigned to it. v1.6 should define the class.

- **`iac/config/route-table.yaml`** — routes[9].conops_decision_required
  > §2.3.2 draws S10 as an S-class route on the sharing endpoint. It cannot be built that way. The only temporary-table-credentials endpoint that exists is POST /api/2.1/unity-catalog/temporary-table-credentials on the WORKSPACE host, with table_id in the body: Unity Catalog credential vending for external engines, not a sharing-protocol path. v1.6 must choose one of two, and they are not close in scope. (a) Reclassify S10 as an A1-class Databricks REST route on the workspace host, with its own policy class, body schema and upstream identity -- note this mak [...]

- **`iac/config/route-table.yaml`** — routes[10].ahead_of_document_because
  > §2.3.2 has no row for this path. The row is added here so route X stops covering it by accident rather than by decision, and flagged so E6's consistency check compares this file against the document it actually has. v1.6 must add the row; until it does, this flag is the disagreement declared rather than discovered. scripts/22 excludes ahead_of_document rows from the §2.3.2 id-set assertion and checks them separately, including that they are never exposed.

- **`iac/config/route-table.yaml`** — routes[13].protocol_path_corrected
  > §2.3.2 writes this segment as `{mcp-name}`, an opaque service slug. The server requires `mcp-services/{catalog}.{schema}.{leaf}` -- it says so in its own error message when given a malformed name (evidence/m2-mcp-methods.json, probe `malformed_name`). The segment therefore carries a Unity Catalog OBJECT IDENTITY, and the consequence is not cosmetic: M2's authorization scope is per-UC-object, so the allow-list question for this route is "which catalog.schema.leaf may be invoked", not "which service". Those are different allow-lists with different owners. [...]

- **`iac/config/route-table.yaml`** — routes[16].ahead_of_document_because
  > 2.3.2 gives I-2 no route id. The push route is specified in 2.4.5 PROSE only, so until v1.6 names it there is no documented id to use. channels.yaml recorded that absence rather than inventing one and was right to; THIS row is the invention, made deliberately and labelled, because Task 2.11 requires the six refusals built and they cannot be built without a route. v1.6 must give I-2 an id in 2.3.2 like every other exposed path, and should adopt or replace this one.

- **`iac/config/route-table.yaml`** — routes[17].error_format_limit
  > §2.3.2 asks for denial "in the protocol error format (errorCode, message)". NOT ACHIEVABLE on this platform, measured rather than assumed. resource-filtering has no message, body or status field, and a response-phase carrier does not run after an interrupting policy refuses -- the 403 carries the policy's own default string. Accepted as a limit; see policy-classes.yaml PC-4. v1.6 should state the limit rather than repeat the requirement.

- **`iac/config/route-table.yaml`** — gaps[0].resolution
  > Closed by adding row S11 as an explicit deny, flagged ahead_of_document because §2.3.2 still has no row. The decision recorded there: /iceberg is NOT exposed, because it is a second data plane handing out credentials for direct object-store reads -- the bypass OD-1(b) exists to close. v1.6 owes §2.3.2 the row.

- **`iac/config/route-table.yaml`** — gaps[0].conops_action
  > v1.6 §2.3.2 needs the row, in whichever of the two forms is chosen.

- **`iac/config/route-table.yaml`** — gaps[1].conops_action
  > v1.6 §2.3.2 should carry the push route with an id, a class and an exposure decision, like every other fronted path.

- **`docs/11-environment-baseline.md`** — line 2187
  > Carry forward to v1.6: §2.3.2's consumer guidance should state that a recipient must read the published schema to learn what it may filter on,

- **`docs/16-epic2-end-to-end.md`** — line 231
  > no route id and no policy class. We invented both, deliberately, and labelled them. **v1.6 owes §2.3.2 a row for each.**

- **`docs/epics/E2-T04-11-traffic-control.md`** — line 587
  > > header on S7 named nowhere in the route table or the CONOPS; a > stricter sanitizer would have stripped it. v1.6 should name it in > §2.3.2 beside the capability header.

- **`docs/epics/E2-T04-11-traffic-control.md`** — line 796
  > > uploads being accepted only in the test environment, and carries its > `confinement`. **v1.6 must give I-2 a route id in §2.3.2 and define > class I.**

- **`docs/epics/E2-arb-package.md`** — line 203
  > (PC-4, measured). §2.3.2's "denied in the protocol error format" is met on **ingress** and not on **egress** — an asymmetry v1.6 should state rather than imply.

## §2.3.3 policy classes

2 item(s).

- **`iac/config/policy-classes.yaml`** — classes.A.request[1].enforced_shape_conops_input
  > v1.6 2.3.3 should state the smoothing. A consumer who reads "5/s", builds a 5-request burst and is throttled will report it as a gateway defect, and the gateway will be behaving as configured.

- **`docs/epics/E2-arb-package.md`** — line 387
  > correctly diagnosed and recorded — "it is the wrong layer" — with `status: OPEN -- v1.6 input`, for days before anyone looked for the setting. §2.3.3's "metadata-only logging" sat unimplemented with nothing

## §2.3.4 reference clients

1 item(s).

- **`docs/epics/E2-T04-11-traffic-control.md`** — line 437
  > > so the fallback is taken, not failed. The deliverable it creates is a > v1.6 obligation: §2.3.4's reference clients need a backoff of their > own, because the gateway will not tell them when to retry.

## §2.4 ingress

2 item(s).

- **`docs/epics/E1-T04-10-perimeter-and-access.md`** — line 405
  > `tests/t19_ingress_d2d.py` runnable, gated on the Task 1.2 probes; `tests/e2_egress_d2d.py` as the proposed v1.6 test; the §2.4.1 role table (requester, approver, metastore admin, credential custodian,

- **`docs/epics/E1-closure-record.md`** — line 199
  > **What v1.6 owes this.** §2.4.1 needs a stated propagation expectation for entitlement **reductions** specifically, and §3.4.1 needs a

## §2.4.5 push ingest (I-2)

3 item(s).

- **`iac/config/policy-classes.yaml`** — classes.I.request[3].content_type_choice_is_ahead_of_document
  > 2.4.5 does not name an accepted content type; it says only that the Files API takes a PUT. application/octet-stream is the Files API's own upload type, so it is the defensible default -- but it IS a choice, and v1.6 should name the accepted set. If producers need JSON payloads (2.4.5 says "a file or a JSON payload") this pattern refuses them, which is a deliberate narrow start rather than an oversight.

- **`iac/config/producers.yaml`** — landing_target_rule_conops_input
  > v1.6 should state the separation in 2.4.5 and name the landing schema, since 2.4.5 currently says only "one landing volume only" without saying where it sits relative to the published data.

- **`docs/16-epic2-end-to-end.md`** — line 987
  > repairing something else; one is the push ingest route, which §2.4.5 describes as a channel without giving it a route or a class. v1.6 owes both a row.

## §3.1 AC1 perimeter

4 item(s).

- **`iac/config/recipients.yaml`** — share_isolation.consequence_for_v1_6
  > §3.1 needs splitting by channel. As written it is a single sentence that is true for D2O and false for D2D, which is the worst shape for a control statement: whoever implements the D2D half will read it, try it, and get an error naming an object they did not touch.

- **`docs/11-environment-baseline.md`** — line 1627
  > the control that catches it is a metastore-wide standing assertion, not a naming convention or a publish-time check. v1.6's §3.1 should require the standing form.

- **`docs/11-environment-baseline.md`** — line 3250
  > **v1.6 input.** 3.1 should state that response-header control applies to responses the upstream produced, not to perimeter refusals, and name the

- **`docs/12-test-matrix.md`** — line 284
  > list maps one-to-one, and the §3.1 access matrix has no row for whatever Genie is, which reinforces the v1.6 point that E-3's surface is wider than "model serving and MCP".

## §3.2 capability table

3 item(s).

- **`iac/config/route-table.yaml`** — routes[16].rewrite_vs_concatenation_v1_6
  > THE §3.2 ROW HAS TWO HALVES AND THEY ARE IN DIFFERENT STATES. §3.2's capability row reads "path rewrite and upstream credential injection" as one line, and v1.6 should split it, because one half is confirmed and the other is not. INJECTION: confirmed. The gateway holds the upstream credential as an API property and the consumer never sees it (T-15, R12A_CONFIRMED_INJECTION_REPLACES_AND_IS_SCOPED). REWRITE: NOT demonstrated. The upstream path above is reached by CONCATENATING the endpoint's base path with the request tail -- which is B-48's mechanism, and [...]

- **`docs/15-deferred-to-client-environment.md`** — line 365
  > ### P-6. Record the §3.2 rewrite row's two halves separately in v1.6's inputs — DONE 2026-11-03

- **`docs/epics/E2-T04-11-traffic-control.md`** — line 872
  > | Rate-limit key from the Authorization header | Per-consumer limits | T-05 | **Accepted by the server and now measured ENFORCING -- on one key.** T-05 phase 2 paced 68 requests at 0.8s against a 60/minute class A step keyed on `{#request.headers['Authorization']}`; the first 429 landed at request **61**, exactly where configured, and a 65s wait cleared it (`evidence/t05-report.json`). That measures the key is READ and the window counts. It does **not** measure ISOLATION between keys: two credentials firing concurrently to show separate buckets was not r [...]

## §3.4 reference clients / endpoints

2 item(s).

- **`docs/12-test-matrix.md`** — line 341
  > **For v1.6:** §3.4.1's step 4 wording drives this. A document that says "replaces *the endpoint*" produces exactly one rewritten field and

- **`docs/epics/E3-1227-E3-data-governance.md`** — line 161
  > - Task 3.4 landing and validation tests - Task 3.5 integration section (ready for CONOPS v1.6) - Task 3.6 OD-5 both-branches document

## §5.2 test plan

1 item(s).

- **`iac/config/channels.yaml`** — channels[1].tests_gap
  > CONOPS §5.2 defines NO test for E-2. The condition the document attached to testing it -- "if a test recipient exists" -- is now satisfied: the second account `glovashu` is a distinct metastore (`8875961b-...`) and a DATABRICKS-authentication recipient was created and deleted on this tier. The prototype therefore adds `tests/e2_egress_d2d.py`, which §5.2 should absorb in v1.6.

## §6.1 evidence rule

2 item(s).

- **`docs/11-environment-baseline.md`** — line 2163
  > PASS closes the question. Every negative assertion in this repository needs a same-path positive control, and v1.6's evidence rule (§6.1) should require the control's path to be *printed* next to the finding, which is

- **`docs/11-environment-baseline.md`** — line 2307
  > **Every test in this repository that asserts a refusal must name the refusing party**, and v1.6's evidence rule (§6.1) should require the responder attribution to be printed next to any non-2xx finding.

## §6.3 secret hygiene

1 item(s).

- **`docs/11-environment-baseline.md`** — line 2119
  > Carry forward to v1.6: this is a general property of layered scanning, which §6's secret-hygiene requirement will acquire the moment a second

## open decisions

2 item(s).

- **`docs/epics/E1-T04-10-perimeter-and-access.md`** — line 397
  > Reverse the T-19 roles (this workspace as provider, `glovashu` as recipient) and record the result as a proposed new test for v1.6, with the OD-6 claim examined directly: confirm that D2D has no gateway

- **`docs/epics/E3-1227-E3-data-governance.md`** — line 215
  > Data Governance has supplied (or the absence has been formally noted with a date) the DSA templates, the tier list, the approver roles and review time targets. The control mappings from §3.3 are implemented in code: shares, recipients and views carry DSA comments; the governance inventory is versioned and current; the token-policy config is filled for the bearer-token branch and templated for OIDC. T-10 passes with evidence of rotation and revocation. T-22 passes with good loads landing correctly and bad/empty loads quarantined. T-23 passes against the l [...]

## cross-cutting (the finding names no single section)

47 item(s).

- **`iac/config/policy-classes.yaml`** — classes.I.request[2].production_value_is_open
  > A real cap belongs with T-05's tuned values and the landing volume's own limits, neither of which exists yet. v1.6 should state a number.

- **`iac/config/recipients.yaml`** — known_incomplete[4].consequence
  > AC1's direct-call refusal rests on an infrastructure assumption the CONOPS never states: that the gateway egresses from an address the recipient allow-list can name, and that no consumer can reach the sharing endpoint from an address on it. On a single-host deployment that assumption is false, and a T-02 reporting a pass without separating the two halves would carry it silently into v1.6.

- **`iac/config/route-table.yaml`** — routes[10].conops_ref
  > none yet -- v1.6 candidate; see gaps.GAP-ICEBERG

- **`iac/config/route-table.yaml`** — routes[13].prototype_status_trap
  > The malformed-name probe returns HTTP 200 carrying a JSON-RPC ERROR. Any health check on this route that asserts on the HTTP status code will report a broken or unauthorized MCP service as healthy. A monitor for M2 must assert on the JSON-RPC body, not on the status line. This generalises beyond M2 and belongs in v1.6.

- **`docs/10-implementation-manual.md`** — line 67
  > reality disagrees with the CONOPS — and it already has twice — we record the disagreement as a document defect for v1.6 rather than quietly working around it.

- **`docs/10-implementation-manual.md`** — line 254
  > These go into v1.6 as document defects. They are not local idiosyncrasies.

- **`docs/10-implementation-manual.md`** — line 327
  > The recommendation for v1.6 is the third, implemented as the first: say that E-1 is a route family rather than a route, and generate the family

- **`docs/10-implementation-manual.md`** — line 382
  > v1.6 has to say which of three things is intended, and none of them is free:

- **`docs/10-implementation-manual.md`** — line 408
  > One scope caveat belongs in the v1.6 text with the finding, because without it the finding will be over-read. This is an observation about

- **`docs/10-implementation-manual.md`** — line 444
  > per-use-case recipients, build it, and receive an error naming an object they never touched. v1.6 needs the rule split by channel, with the D2D row saying plainly that isolation lives on shares there and that the

- **`docs/10-implementation-manual.md`** — line 529
  > Remediation for v1.6, which is small: promote the confirming call into the D2O column as a **required gate**, worded so the operator stops

- **`docs/11-environment-baseline.md`** — line 1111
  > **Then the part that matters for v1.6.** With the confirming call already refused, step 5c created the catalog from the share anyway —

- **`docs/11-environment-baseline.md`** — line 1583
  > per consuming agency or use case" is satisfiable for *agency* and not for *use case* when both use cases sit in the same consuming metastore. v1.6 should say so.

- **`docs/11-environment-baseline.md`** — line 1812
  > **What v1.6 owes this finding:** a stated propagation expectation for entitlement *reductions*, and a revocation path that does not depend on

- **`docs/11-environment-baseline.md`** — line 1958
  > the mechanism from the topology would have carried the assumption silently into v1.6 — the §12.4 error in a more expensive form than the original, because it is not a verdict upgraded ahead of its measurement

- **`docs/11-environment-baseline.md`** — line 2487
  > nor "the allow-listed address" has a single referent in this architecture. v1.6 should say which of the two is the **control of record** for address-based refusal. Only the Databricks-side list can

- **`docs/11-environment-baseline.md`** — line 2607
  > listed paths. None of them ever emitted a rule that *refuses unlisted ones*. A row absent from the table was not absent from the gateway. v1.6 has to say which document is the enforced boundary and which merely

- **`docs/11-environment-baseline.md`** — line 2702
  > The rule, which belongs in v1.6 as a configuration constraint and not a footnote: **no `condition` on any step whose absence fails open.** A

- **`docs/11-environment-baseline.md`** — line 2732
  > The generalisation for v1.6, stronger than the one B-46 already carries: **a perimeter test that never observes the perimeter absent is measuring

- **`docs/11-environment-baseline.md`** — line 2968
  > because route X's generic selector is evaluated first and answers before the named deny is reached. v1.6 should state the limit rather than repeat the requirement.

- **`docs/11-environment-baseline.md`** — line 2985
  > them. This is not an incomplete list; it is the wrong layer." What was missing was the setting, so the entry read `status: OPEN -- v1.6 input`.

- **`docs/15-deferred-to-client-environment.md`** — line 153
  > | **Resource needed** | A policy that both refuses and emits a body (Gravitee EE, or a custom policy), or the same fronting component as A-5 | | **Owner** | E6 / architecture, plus a v1.6 language decision |

- **`docs/15-deferred-to-client-environment.md`** — line 161
  > This is an asymmetry v1.6 should **state** rather than imply, which is the cheaper half of the remedy and does not need the client environment.

- **`docs/15-deferred-to-client-environment.md`** — line 231
  > |---|---| | **Resource needed** | A CONOPS v1.6 decision, not a client resource | | **Owner** | CONOPS owner |

- **`docs/15-deferred-to-client-environment.md`** — line 237
  > are labelled `ahead_of_document: true`, and carry `exposure_sanctioned_by` plus `confinement`. v1.6 owes them an id and a class. Listed here so the migration does not carry an undocumented

- **`docs/15-deferred-to-client-environment.md`** — line 368
  > Injection works and rewrite is undemonstrated. The current single row says so, but `docs/14-conops-v1.6-inputs.md` is generated by literal search for `v1.6`, so the distinction only reaches the drafter if the

- **`docs/15-deferred-to-client-environment.md`** — line 369
  > says so, but `docs/14-conops-v1.6-inputs.md` is generated by literal search for `v1.6`, so the distinction only reaches the drafter if the phrase is written where the finding lives. Cheap, and it is the exact

- **`docs/15-deferred-to-client-environment.md`** — line 375
  > the upstream path template it is about, phrased so the generator's literal `v1.6` search picks it up: injection confirmed, rewrite reached by concatenation and therefore not demonstrated, `dynamic-routing` the

- **`docs/15-deferred-to-client-environment.md`** — line 377
  > by concatenation and therefore not demonstrated, `dynamic-routing` the candidate, R12 live on the rewrite half only, and v1.6 owed the row as two rows rather than one.

- **`docs/16-epic2-end-to-end.md`** — line 291
  > On egress we do not. That asymmetry is real, it is not going away without a component in front of the gateway, and **v1.6 should state it rather than imply uniformity**.

- **`docs/16-epic2-end-to-end.md`** — line 644
  > wrong thing to change first — a class whose limit is enforced as a 200-millisecond gate needs its shape described in v1.6 before its value is argued about. And changing a limit so that a test reads better is the

- **`docs/epics/E1-T04-10-perimeter-and-access.md`** — line 413
  > records either a real result or the specific tier capability that refused it; the E-2 result is written up as a v1.6 test proposal rather than filed against an existing test ID.

- **`docs/epics/E1-closure-record.md`** — line 222
  > **The CONOPS may not claim the caller is told why the legacy MCP route is closed.** v1.6 needs that sentence changed.

- **`docs/epics/E1-closure-record.md`** — line 232
  > **Rule for v1.6, as a configuration constraint:** no `condition` on any step whose absence fails open. A condition is safe on a step that *adds*

- **`docs/epics/E1-closure-record.md`** — line 249
  > table that carries it cannot be added to such a share. The clause should be **struck** from v1.6 with that error as the evidence. The entitlement model is view-based only.

- **`docs/epics/E1-closure-record.md`** — line 393
  > The generalisation for v1.6, and the single most transferable thing this epic produced: **a perimeter test that never observes the perimeter

- **`docs/epics/E2-T04-11-traffic-control.md`** — line 476
  > > the wrong thing to change first — a class whose limit is enforced as a > 200 ms gate needs its *shape* described in v1.6 before its value is > argued about, and changing a limit so a test reads better is B-47.

- **`docs/epics/E2-T04-11-traffic-control.md`** — line 799
  > > > **An asymmetry v1.6 should state.** PC-4 records that the egress deny > class CANNOT say why -- `resource-filtering` has no status field, so

- **`docs/epics/E2-arb-package.md`** — line 239
  > v1.6 owes **both** a row. An earlier revision of this package named only the first, which understated the ask.

- **`docs/epics/E2-arb-package.md`** — line 293
  > for a policy requirement. Any later consolidation onto a shared route reintroduces one caller throttling another, silently. v1.6 should either key spike arrest or state that the route shape carries it.

- **`docs/epics/E2-arb-package.md`** — line 295
  > either key spike arrest or state that the route shape carries it. Owner: E2/v1.6.

- **`docs/epics/E2-arb-package.md`** — line 412
  > | `docs/11-environment-baseline.md` §11.7 | The blocker register, B-1 to B-55, plus the `spike-arrest` smoothing finding | | `docs/14-conops-v1.6-inputs.md` | Every v1.6 input the repository has recorded, generated from source |

- **`docs/epics/E3-1227-E3-data-governance.md`** — line 105
  > Record one behaviour that only a live rotation reveals: whether an in-flight read survives the old token's expiry or fails mid-query. The CONOPS specifies an overlap period but not what happens to work already running, and that is exactly the kind of detail v1.6 can carry because this exercise produced it.

- **`docs/epics/E3-1227-E3-data-governance.md`** — line 123
  > **Deliverable:** `docs/epics/E3-integration-section.md` ready for §3.3 revision in CONOPS v1.6.

- **`docs/epics/E3-1227-E3-data-governance.md`** — line 194
  > | `docs/epics/E3-OD5-both-branches.md` | Bearer token and OIDC federation branches, both built and ready | | `docs/epics/E3-integration-section.md` | CONOPS §3.3 integration section, ready for v1.6 revision |

- **`docs/epics/E3-streamlining-inputs.md`** — line 186
  > it would have surfaced in front of stakeholders against a claim that cannot be met as written. CONOPS v1.6 should strike the masks-and-filters clause from all three sections.

- **`docs/epics/E8-T04-15-user-testing-support.md`** — line 32
  > The count is worth stating carefully, because **the CONOPS contradicts itself and the script may have been right once**. §5.3 says eight steps and lists eight. But §3.8 says *"Run: the seven-step client verification session (Section 5.3)"* — pointing at the same section while naming a different count. §5.3 is the one that enumerates, so eight is authoritative and §3.8 is the stale cross-reference. This is a new document defect for v1.6 (recorded as **D-5** in docs/10 §10.7), and it is the kind of thing worth catching before a client reads §3.8, counts se [...]

