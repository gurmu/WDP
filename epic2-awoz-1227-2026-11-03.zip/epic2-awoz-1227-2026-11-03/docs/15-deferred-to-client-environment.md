# Deferred to the client environment — and what is still owed here first

**AWOZ-1227 / INC17 milestone 1227 · written 2026-10-30**
**Delivery commitment: 20 December 2026, from the company-side
environment.**

## Why this document exists

The milestone cannot be delivered from the client environment on the
original schedule, and that has been escalated. The commitment made in
its place is that the work is completed **here**, on company
infrastructure, and migrated as a finished package — so that when the
client environment has the resources requested, the remaining items drop
into place rather than being discovered.

That promise only holds if two lists are kept honestly and kept apart:

- **Part A — deferred.** Items that cannot be closed here for a stated
  reason, each naming the specific client-side resource that unblocks
  it. An item belongs here only if the resource is named. "Needs the
  client environment" is not a reason; it is a restatement.
- **Part B — owed here, before migration (items P-1 to P-7).** Items that are *not*
  blocked, are not done, and would be cheap now and expensive after the
  handover. Part B exists to stop Part A becoming the place work goes to
  avoid being done. **Nothing migrates until Part B is empty or each
  remaining line carries an explicit decision not to do it.**

The test for a Part A entry: *if the named resource appeared tomorrow,
could someone pick this up without asking us anything?* Where the answer
is no, the entry says what else is missing.

---

## Part A — deferred, with the resource named

### A-1. AC2 clause 2.5: that the edge trips *before* Databricks

| | |
|---|---|
| **Resource needed** | **SHARPENED 2026-11-03 — not "enable system tables".** `system.access.audit` is already readable here. What is missing is an audit surface that **records Delta Sharing reads**. See the measurement below: the ask to the client changed shape. |
| **Owner** | Client platform / Data Governance |
| **Closes** | AC2 clause 2.5; §3.2's throttle row's compute-protection half |
| **Test to run** | `tests/t05_rate_limit.py`, the upstream half (not yet written — see B-3) |

What is already measured here: both throttles fire and clear at the
configured points, verbatim, and neither 429 carries a retry indication
(`evidence/t05-throttle.json`, `evidence/t05-report.json`). What is not:
that Databricks saw fewer requests than were sent. **A 429 at the edge
is consistent with the upstream never being called and does not
demonstrate it** — and that demonstration is the entire content of
clause 2.5, which says throttling exists *"to protect compute
resources"*. The assertion needs a count of requests that reached the
upstream, and this tier exposes no audit table to count them in.

Recorded as `clause_2_5_not_measured` in the evidence file rather than
inferred from the 429s.

### A-1 MEASURED 2026-11-03 — the table is readable and blind

`tests/t05b_edge_trips_first.py` ran. Both preconditions **passed**: a
SQL warehouse exists and `system.access.audit` **is readable**. Then the
positive control failed:

```
one read through the edge -> 200
+ 15s … +105s   audit rows since the control read: 0
```

A read that demonstrably succeeded produced **no audit row in 105
seconds**. The table is there, we can query it, and it is not recording
this traffic. Candidate causes, none yet distinguished: the action names
differ on this tier, Delta Sharing reads are not audited at this tier,
the rows land in another table, or propagation is slower than the
window.

**This is the single most useful thing the test produced, and it is the
reason it was written to refuse rather than to count.** Had it gone
straight to the burst, the answer would have been *zero upstream
requests against sixty-eight sent* — presented as total compute
protection, the strongest claim in the package, and an artefact of a
blind table. The control cost two minutes and saved a false headline.

**What this changes about the ask.** "Enable the system catalog" is the
wrong request; it is already enabled. The request to the client platform
is: **an audit surface that records Delta Sharing reads, with the action
names it records them under.** Those are different conversations with
different owners, and asking the first one would have wasted a cycle.

### A-1 ALTERNATIVE — ask the gateway, not the upstream

Worth weighing before this is carried to the client at all, because it
may close clause 2.5 **here**.

The requirement is that the edge trips *before* Databricks. We have been
trying to prove it from the upstream's side — "how many did you see?"
The gateway is the component that decides whether to forward, and it
keeps its own log. A request interrupted by a request-phase policy is
**never forwarded**, by construction, and the gateway's log records
which policy interrupted it. So the same claim is answerable as "how
many did you forward?", from the one component that knows for certain.

The substrate already exists: the gateway's Elasticsearch indices are
behind it and the correlation work already reads them.

Honest about its standing: this is the gateway attesting to its own
behaviour, which is weaker than an independent upstream count and
stronger than inferring from a 429 — it attributes the refusal to a
named request-phase policy and shows no upstream call followed. The
upstream count would corroborate it, not replace it.

### A-1 ALTERNATIVE TRIED AND BLOCKED, 2026-11-03

`tests/t05c_gateway_forwarded.py` was built and run. It is also blocked,
for a reason worth recording.

The gateway's request documents carry **eight fields, all entrypoint**:
`@timestamp`, `api-id`, `api-name`, `client-identifier`,
`entrypoint-request`, `entrypoint-response`, `request-ended`,
`request-id`. There is **no endpoint or upstream field** — nothing
recording whether a backend was called. The v4 analytics on this edition
report what entered and what the client got, and are silent on what the
gateway did in between.

Verdict `CANNOT_SEE_NO_UPSTREAM_MARKER_FIELD`, refused before the burst.
Had it counted anyway, every request would have looked un-forwarded and
the burst would have read as perfect compute protection — the blind
audit table again, in a different store.

**So both routes to row 2.5 are closed here, for two different
reasons**, and the ask to the client is now in two parts:

1. an audit surface that records Delta Sharing reads, with its action
   names (the upstream count); **or**
2. gateway analytics that emit endpoint-level metrics (the forwarding
   count) — worth asking whether the edition or reporting configuration
   can emit them, since that would close the row without the upstream.

Either settles it. Neither exists here. Row 2.5 stays unevidenced and
the mechanism stays measured.

### A-2. Task 2.9 / T-08 / route F1: the storage proxy, and OD-1

| | |
|---|---|
| **Resource needed** | Customer-managed storage for the Delta Sharing data (so a storage host exists that is not only inside the pre-signed URL), **or** a decision to accept OD-1 option (b) |
| **Owner** | Data Tooling + Data Governance (OD-1) |
| **Closes** | OD-1; §3.2's file-URL-rewrite row; part of R12 |
| **Test to run** | `tests/t08_storage_proxy.py` (not written — correctly, see below) |

F1's upstream host lives **inside the pre-signed URL** in an S8/S9
response body (B-9), so there is no static target to configure. The
listener and the policy chain are generated and real; the forwarding
step is deliberately `FORWARDING_DISABLED`
(`evidence/gravitee-route-family.json`). On Free Edition, storage is
Databricks-managed, so T-08's refusal half is not provable either —
there is no second storage address to be refused.

**Recommendation carried into the ARB package: defer OD-1 rather than
decide it, with option (b) as the working assumption**, because (b) is
the only branch that does not depend on a rewrite nobody has
demonstrated. §2.3.2's documented fallback — storage address limits plus
short-lived credentials — is intact and needs no gateway capability we
have failed to find.

No test is written for this on purpose: a test that cannot observe its
subject produces a `CANNOT_SEE` at best and a false green at worst.

### A-3. Task 2.10 / T-15 and T-16: the AI routes

| | |
|---|---|
| **Resource needed** | Model Serving entitlement plus at least one deployed serving endpoint (T-15); Unity Gateway MCP availability (T-16) |
| **Owner** | Client platform |
| **Closes** | §3.2 indirectly; class E's only route |
| **Already here** | `gravitee/generated/api-m1-ai-gateway.json`, `evidence/t15-report.json`, `evidence/t16-report.json`, `evidence/m2-mcp-methods.json` |

The route and its policy class exist and the upstream credential
injection on this route is the **one half of §3.2's rewrite/injection
row that is confirmed working** — the token is set as an API property
and re-read off the server, so the consumer never holds it. What is
missing is a live endpoint behind it. Note the monitoring hazard already
recorded: a broken MCP service answers **HTTP 200 carrying an error**, so
a status-code health check reports it healthy.

### A-4. T-09: JWT validation and client certificates

| | |
|---|---|
| **Resource needed** | OD-5 decided (sign-in method), then an OIDC issuer to validate against |
| **Owner** | Data Governance (OD-5) |
| **Closes** | §3.2's JWT row; §2.3.4's client-certificate row |

OD-5 is open and the prototype builds the **bearer-token branch**.
Reporting a JWT result would imply a decision nobody has made, so §3.2's
row reads *"not applicable until OD-5 decides"* rather than carrying a
number. Client certificate support is a property of the **reference
clients**, not of Gravitee; §2.3.4 already names the fallback (the
address allow-list plus the recipient IP list carry the binding), and
that fallback is measured working (T-03).

### A-5. B-55 and the response-header allow-list: a component in front of the gateway

| | |
|---|---|
| **Resource needed** | Either gateway-level configuration access on the client's APIM deployment, or the corporate edge component that strips response headers by allow-list |
| **Owner** | E6 / architecture |
| **Closes** | AC2 clause 2.2's remaining two limits |

Two findings with one remedy:

- **The allow-list is enforced by the test, not the gateway.**
  `transform-headers` can add and remove *named* headers; it cannot
  express "keep only these", and no installed policy can — measured
  against all 79 policy schemas. A header a new upstream version starts
  sending reaches clients until the next test run.
- **B-55: sanitization covers successes, not refusals.** The remove-list
  is a response-phase step, and a request-phase policy that interrupts
  answers before the response chain runs. Every refusal the *perimeter*
  raises — 400, 405, 409, 413, 415, 429, route X's 403 — goes out
  unsanitized; refusals from the **upstream** traverse the chain and are
  sanitized. The line falls on *who refused*, not on the status code.

Neither is fixable by a policy. B-52 found a gateway *setting* for the
`X-Gravitee-Request-Id` / `Transaction-Id` pair, so one may exist for
`x-gravitee-client-identifier` — that is a half-hour of searching in an
environment where gateway configuration can be changed, which is why it
sits here and not in Part B. What currently leaks on a refusal is a
gateway product name and an opaque per-caller id: no credential, no
path, no upstream hostname.

### A-6. PC-4: the protocol error format on the egress deny path

| | |
|---|---|
| **Resource needed** | A policy that both refuses and emits a body (Gravitee EE, or a custom policy), or the same fronting component as A-5 |
| **Owner** | E6 / architecture, plus a v1.6 language decision |

`resource-filtering` has no message, body or status field, and a
response-phase carrier does not run after an interrupting policy —
measured, twice, from both directions (PC-4, and now B-55). So §2.3.2's
*"denied in the protocol error format"* is met on **ingress** and not on
**egress**. Route X returns a correct but reasonless 403.

This is an asymmetry v1.6 should **state** rather than imply, which is
the cheaper half of the remedy and does not need the client environment.

### A-7. Path rewrite, R12, and the landing volume

| | |
|---|---|
| **Resource needed** | The producer's landing volume provisioned (`psp7-producer` is `DECLARED_NOT_PROVISIONED`), in a schema that is **not** the published `opensharing_test` |
| **Owner** | E2 / E4 in the client environment |
| **Closes** | §3.2's rewrite half; R12 |

I1's correct upstream path currently comes from **concatenation** of the
endpoint's deep base path with the request tail — B-48's mechanism, one
target edit from being gone — and scoring that as a rewrite would be a
false capability claim. `dynamic-routing` is the candidate policy and its
schema is measured (`rules[].pattern` and `rules[].url`, both required,
both EL-capable); it is untested because there is nothing to route to.

**Sequencing constraint, and it is load-bearing.** Credential injection
on I1 must not be built before B-54's path allow-list is measured working
*on a route that authenticates*. The moment a forwarded request
authenticates, a traversal becomes a real write outside the producer's
landing volume — and T-24 would score that 200 and **pass**, because a
successful upload is what its positive controls look for. The two items
sit together in `not_built_yet` for that reason, not alphabetically.

### A-8. Push ingest content scanning

| | |
|---|---|
| **Resource needed** | An owner. OD-9 leaves this unassigned |
| **Owner** | **unassigned — this is the ask** |

§2.4.5 calls content scanning a platform security capability, not a
gateway policy. Route I1 is confined to the test environment for that
reason, and the six edge refusals passing does not widen it: they check
the **shape** of a request and say nothing about what is inside a file
whose shape is permitted.

### A-9. The 24-hour credential lifetime

| | |
|---|---|
| **Resource needed** | A Databricks tier or configuration in which the configured recipient-token lifetime is honoured — or an accepted operational cost |
| **Owner** | Data Governance / OD-3 |

Measured on three recipients for three: a token configured for 7 days
expires **24 hours after it is created**
(`LIFETIME_DIFFERS_SET_AT_BIRTH`). Every credential needs re-activating
the morning of a demo, and AC4's self-service portal inherits a daily
re-activation step nobody has costed. **CORRECTED 2026-11-02 — the clock starts at creation, not at
activation.** Three activation links written on 10-30 at 21:04Z were
first exchanged on 11-02 and all three were refused with 404
`RECIPIENT_DOES_NOT_EXIST`, "activation nonce not found", while the
token records showed `expiration_time` exactly 24h after `created_at`
and the links never consumed. The two readings were indistinguishable
until now because every earlier rotation was activated minutes later.

The consequence is sharper than what was on record: **a rotation that is
not activated the same session is a wasted token, not a pending
activation.** Rotate and activate must happen together, and a recovery
path that only activates cannot rescue a link left overnight.

Mitigated here by P-4 (below), not
fixed.

### A-10. Class I and route I1 are ahead of §2.3.2

| | |
|---|---|
| **Resource needed** | A CONOPS v1.6 decision, not a client resource |
| **Owner** | CONOPS owner |

The baselined document gives channel I-2 no route id and names five
policy classes. Both the class and the route were invented deliberately,
are labelled `ahead_of_document: true`, and carry
`exposure_sanctioned_by` plus `confinement`. v1.6 owes them an id and a
class. Listed here so the migration does not carry an undocumented
route silently.

### A-11. The ARB package and user testing

| | |
|---|---|
| **Resource needed** | The corporate **1694-G2** template (ARB package), and client users (E8 user testing) |
| **Owner** | Client programme |

Both were excluded from the company-side commitment by agreement. The
AC2 content for the package is written and traceable
(`docs/epics/E2-arb-package.md`); what is missing is the template it has
to be poured into. The same is true of Epic 1's Task 1.12.

---

## Part B — owed here, before migration

Numbered **P-** rather than B-, because this repository's blocker register already owns B-1 to B-55 and a second B-4 in the same package would be read as that one.

Each line is unblocked. Each is cheaper now than after the handover,
because the environment that produced the evidence still exists.

### P-1. Run T-07 phase 3b and record B-55's measured extent

Phase 3b is written and committed; it has not been run. Until it runs,
B-55's extent is **argued from the mechanism** and demonstrated on a
single 429 that T-05 happened to capture. One run converts it into a
measurement across two refusal types with the allow-list applied. The
verdict to expect is `SANITIZED_ON_SUCCESS_BUT_NOT_ON_REFUSALS`; if it
comes back clean on refusals, B-55 is narrower than this document says
and this document is wrong, which is worth knowing before the ARB reads
it.

```
python3 tests/t07_header_sanitization.py --no-mutate
```

### P-2. Measure rate-limit key isolation between two live credentials

§3.2's rate-limit-key row currently reads *"enforcing, on one key"*
because the other two recipient credentials had expired at test time —
A-9's lifetime, not a capability limit. **This is measurable here**:
activate two recipients, exhaust one credential's minute budget, and
check the second still answers 200 on the same route. That converts the
per-consumer claim from *"carried by the route shape"* to *"carried by
the key, and separately by the route shape"*, which is a materially
stronger sentence in front of an ARB.

Deliberately not claimed as done, and deliberately not left in Part A
where it would look blocked.

### P-3. Write T-05's upstream half, even though it cannot pass here — DONE 2026-11-03

A-1 is blocked on a system table, but the *test* is not blocked on
anything. Writing it here — with the audit query, the attribution rules,
and a `CANNOT_SEE` verdict when the table is absent — means the client
environment runs one command instead of commissioning a test. The repo's
own standard: a test that returns `CANNOT_SEE` for a stated reason is a
deliverable; a missing test is a task.

**Written and committed as `tests/t05b_edge_trips_first.py`.** It
discovers a SQL warehouse, checks `system.access.audit` is readable, and
returns a distinct `CANNOT_SEE` for each way that can fail — no
warehouse, no table, no live credential, the edge never throttling.

**Its design turns on one trap worth knowing about.** The obvious
implementation bursts, counts audit rows, and asserts the count is lower
than what was sent. If the audit table does not record Delta Sharing
reads at all — different action names on this tier, rows landing
elsewhere, propagation slower than the window — that query returns
**zero**, and zero upstream requests against sixty-eight sent reads as
*total compute protection*. The strongest possible result, produced by a
blind table.

So the positive control runs **first** and the test refuses to proceed
without it: make one read known to have succeeded through the edge, then
confirm *that* read appears in the audit table. Only once the table has
been seen recording a request we know was made does a lower count
afterwards mean anything. B-40's rule applied to an upstream counter
rather than to a refusal.

### P-4. One-command credential refresh

Three credentials, each expiring 24h after activation, currently take a
rotate-then-activate pair per recipient with a file move in between —
and a stale credential file has already caused a test to be read as a
gateway finding. `scripts/43_refresh_credentials.py` makes it one
command and prints each resulting expiry, so a session starts from a
known state. Mitigates A-9; does not fix it.

### P-5. Re-run the full gate set from inside the migration archive

Not from the working tree. Epic 1's archive was built *before* a
template was restored and carried a file it should not have — the gates
passed in the working tree and the archive was still wrong. The bundle
builder therefore writes a SHA-256 manifest and the extraction is
re-gated: `scripts/22_check_cac_config.py` and
`scripts/check_secret_hygiene.py`, run from the extracted copy.

**DONE 2026-11-03 for the 11-03 archive, and it produced a finding about
this item itself.**

| Check | From the extraction | Reading |
|---|---|---|
| Manifest, verified independently of the builder | 189 files, 0 differ, 0 missing | the archive is internally consistent |
| Static config gate | **398 checks, 0 failed** | and it ran on the extraction's OWN files, which is the real proof of self-containment |
| Hygiene: token-shaped strings | **clean, 181 files**, 4 declared placeholders exempted | the half that answers "did we ship a secret" |
| Hygiene: git tracking | **FAIL** — *"no git repository, .gitignore is inert and T-12 has no substrate"* | see below |
| Hygiene: rewritten credentials, duplicate .env keys | skipped, neither present | correct for an archive |

**The git failure is not a defect in the archive; it is this item's
instruction being slightly wrong.** A zip has no `.git/` by
construction, so that check can never pass from an extraction. It asks
whether the WORKING TREE is a repository, so that `.gitignore` actually
protects something — a meaningful question about a development
environment and a meaningless one about a delivered archive.

Same shape as the structural-unobservability case in A-10: a gate with a
condition that cannot be satisfied in the context it is being run in.
The remedy is the same — name it rather than override it. **P-5 should
read: from an extraction, run the static gate in full and the hygiene
gate's content scan; the git-tracking check is not applicable there and
should report `N/A` rather than `FAIL`.** Until the gate says so itself,
anyone following this item will hit the same confusing failure.

### P-6. Record the §3.2 rewrite row's two halves separately in v1.6's inputs — DONE 2026-11-03

Injection works and rewrite is undemonstrated. The current single row
says so, but `docs/14-conops-v1.6-inputs.md` is generated by literal
search for `v1.6`, so the distinction only reaches the drafter if the
phrase is written where the finding lives. Cheap, and it is the exact
failure mode that index was built to prevent.

**Done.** The finding now lives on route I1 in the route table, beside
the upstream path template it is about, phrased so the generator's
literal `v1.6` search picks it up: injection confirmed, rewrite reached
by concatenation and therefore not demonstrated, `dynamic-routing` the
candidate, R12 live on the rewrite half only, and v1.6 owed the row as
two rows rather than one.

### P-7. Re-run the perimeter tests on refreshed credentials, before the bundle is built

**This one is not optional and it is currently failing.**
`evidence/t01-report.json`'s last run reads **one pass and three
`CANNOT_SEE`**: two recipient credentials had expired and one check
found the edge forwarding to the wrong upstream
(`CANNOT_SEE_EDGE_FORWARDED_TO_THE_WRONG_UPSTREAM`). T-01 is the
evidence the route table's faithful-read claim rests on, so a bundle
built today would ship a 1-of-4 run behind a sentence that reads as
though the control was measured.

`CANNOT_SEE` is a legitimate third verdict and that is exactly why it
cannot be shipped silently: the reader cannot distinguish "we looked and
it held" from "we could not look". The remedy is a refresh and a re-run,
not a re-word:

```
python3 scripts/43_refresh_credentials.py --all
python3 tests/t01_gateway_read.py
python3 tests/t24_push_refusals.py --no-mutate
```

`scripts/41_build_epic2_bundle.py` refuses to build while any task
declared CLOSED cites evidence containing a `CANNOT_SEE` row, so this
item is enforced rather than remembered. If the re-run reproduces the
wrong-upstream finding on a live credential, that is a real defect and
not an expiry artefact — it stops being P-7 and becomes a blocker.

**CONFIRMED 2026-11-03. The structural claim holds.** The arm-and-reverse
ran: the activation info call returned **403**, the widen fired and
reported `IP_ACCESS_LIST_ENFORCEMENT_OBSERVED_ON_ACTIVATION_ENDPOINT`,
activation then succeeded, and the address list was restored and
verified — `RESTORED_AND_VERIFIED`, back to its declared value.

So the recipient that exists to be refused is refused **on the
activation endpoint too**, by the same address list T-03 measures. Its
T-01 row being unobservable from this host is the control working, not
an outage, and no re-run will change that. The bundle's structural
declaration moves from SUSPECTED to CONFIRMED and now grants acceptance
on its own terms instead of through an override.

Note the asymmetry this settles. The 403 is what the claim predicted; an
earlier refusal had been a **404, nonce not found**, which is an expired
link and not an IP refusal. Two different causes behind one
`INFO_REFUSED` label — which is exactly why the confirmation had to be
run rather than assumed.

That recipient now holds a live credential, so T-01 should be re-run:
its row will change from "no credential" to whatever the address list
does to a read, which is a measurement rather than an absence.

---

## How this document stays true

`scripts/41_build_epic2_bundle.py` refuses to build the migration bundle
unless every id declared in its `DEFERRED_IDS` list appears in this file.
That is a completeness check, not a correctness check: it catches an item
dropped from the register, and it cannot catch an entry whose named
resource is wrong. The named resources are the part that needs a human
to read them.
