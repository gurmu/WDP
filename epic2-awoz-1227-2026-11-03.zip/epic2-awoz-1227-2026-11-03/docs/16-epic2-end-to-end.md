# Epic 2 end to end — what we built, why, and what it proves

**AWOZ-1227 / INC17 milestone 1227 · Epic T04-11 · AC2 · written 2026-11-01**

This is the lead's briefing, not the report. The report says what
happened; this says **what it means**. It is written so you can talk
through Epic 2 from beginning to end without opening a file, and so that
when someone interrupts with "but how do you know?" the answer is a
sentence away.

It names the tests, because the tests are the evidence. It does not name
files, scripts or configuration keys, because nobody will ask you about
those and they are not what the epic is about.

**How to use it.** Parts 1–4 are the mental model: read those once and
the rest follows. Part 5 is AC2 clause by clause and is the spine of any
review conversation. Part 12 is the Q&A — the questions that will
actually be asked, with the answers.

---

## Part 1 — What Epic 2 is

### The criterion, verbatim

CONOPS §3.2 defines AC2 as:

> *exposure of Databricks endpoints through Gravitee with enforced rate
> limits, spike arrest and request schema validation to protect compute
> resources.*

Three nouns and a purpose clause. The nouns are buildable. **The purpose
clause is the hard part**, and most of what Epic 2 learned lives in the
gap between them.

### Where Epic 2 sits between its neighbours

Epic 1 owns **who may see what** — recipients, shares, grants, the IP
access list, the credential model. Epic 3 owns **data governance** —
what the data itself is allowed to be.

Epic 2 owns the thin, busy layer between them: **what the edge does to a
request on its way through**. Not who is asking, not what they are
asking for — what happens to the request between the client and
Databricks.

That boundary matters when you are explaining a finding. If someone asks
"why didn't Epic 2 catch the entitlement propagation problem?", the
answer is that entitlements are Epic 1's subject and E3's consequence;
Epic 2's subject is traffic. If someone asks "why is Epic 2 looking at
credential expiry?", the answer is that an expired credential makes
every traffic measurement unreadable, so Epic 2 has to care about it
without owning it.

### The sentence AC2 actually has to earn

§2.3.3 states the design intent in one line that is easy to read past:

> *"The Gravitee limit is set below the Databricks-side limit on the
> same route so the edge trips first."*

Read it carefully. **AC2 is not satisfied by a rate limit existing.** It
is satisfied by a rate limit demonstrably firing at the gateway *while
Databricks never sees the burst*. A configuration listing does not
demonstrate that. A 429 does not demonstrate it either — a 429 at the
edge is perfectly consistent with the upstream never having been called,
and equally consistent with the upstream having been called and the
gateway refusing afterwards. The two look identical from outside.

That one distinction is why clause 2.5 is the only AC2 clause we have
**not** evidenced, and it is the single most important thing to be
straight about in front of an ARB. We have measured the mechanism. We
have not measured the claim.

---

## Part 2 — The architecture, in words

### What is actually happening on an egress read

A consuming agency — call it the recipient — wants to read a table we
have shared. Without a gateway, Delta Sharing works like this: the
recipient holds a credential file containing an endpoint and a bearer
token, calls the endpoint directly, gets back metadata, then asks for
the data and receives **pre-signed object-storage URLs**, which it
fetches directly from cloud storage.

Three facts about that flow shape everything in Epic 2:

1. **The recipient holds a bearer token by construction.** Delta Sharing
   is a token protocol. CONOPS §1 already treats this as the
   architectural principle rather than a defect — the token is scoped to
   one recipient and vends nothing but that recipient's shares. What the
   recipient must never hold is a *Databricks workspace* credential.
2. **The protocol hands out a second credential.** One route exists
   purely to vend temporary object-storage credentials. A successful
   call there widens the blast radius more than any data route does.
3. **The data does not come back through the gateway by default.** It
   comes from object storage, directly, over a signed URL whose hostname
   is inside its own signature.

Our design puts Gravitee in front of step one. The recipient's
credential is rewritten so its endpoint points at our gateway instead of
at Databricks. Everything the recipient does on the protocol now
traverses the edge.

### Where the trust boundary sits, and where it does not

The boundary sits at the gateway for **the protocol**: discovery,
metadata, queries, credential vending. It does **not** sit at the
gateway for **the bytes**, because the bytes come from object storage on
a signed URL.

That is the whole subject of route F1 and open decision OD-1 — whether
we proxy the file download too, so that the bytes also traverse the
edge, or whether we accept that the signed URL plus a short expiry plus
a storage address restriction is the control. We did not decide it. Part
10 explains why that was the right call rather than a dodge.

### Why there is one gateway API per recipient

This is the single most counter-intuitive thing in the design and you
will be asked about it.

The naive design is one gateway API fronting all recipients. It does not
work, and it does not work for a platform reason rather than a
configuration reason: **Databricks binds the sharing host to the
recipient**. Each recipient's issued credential names a per-recipient
sharing host with a metastore path inside it. A token issued for
recipient A, presented to recipient B's sharing host, is refused — and
refused by the platform, with an error naming both halves.

So the upstream address is not a property of the *service*, it is a
property of the *recipient*. One route cannot front them all, because
there is no single upstream to point it at.

This produced the first real blocker of the programme, B-1, and it is
worth telling as a story because it generalises. The first route was
built against an *assumed* endpoint URL — the shape you would guess from
the documentation — rather than the one inside the issued credential.
Wrong host and wrong path. It was misdiagnosed for a day as a gateway
fault.

**The rule it produced, which the production build inherits for free:
resolve every upstream from the issued credential, never from a
template.**

The second-order consequence is the one to carry into conversations
about scale: the route family is one API per recipient, so onboarding a
recipient means generating a route family, not editing a shared one.
That is more objects to manage and it is *also* why a per-consumer rate
limit is currently safe — see Part 4.

### The five channels

The CONOPS defines five channels, and Epic 2 touches four of them:

| Channel | What it is | Epic 2's involvement |
|---|---|---|
| **E-1** | Egress, OpenSharing to an outside org (D2O) | The main subject. Routes S1–S11 and F1. |
| **E-2** | Egress, OpenSharing Databricks-to-Databricks (D2D) | Same routes, different counterparty. |
| **E-3** | Egress, API and MCP | Routes M1, M2, M3 — the AI surface. |
| **I-1** | Ingress, pull | Not Epic 2. |
| **I-2** | Ingress, push | Route I1 — a producer uploading a file. |

---

## Part 3 — The route table, and the deny path

### What the route table is for

The route table is the complete list of what the edge will carry. §2.3.2
states the governing rule:

> *"Routes not listed are denied."*

That sentence is the whole security argument of the perimeter. Epic 2's
most consequential finding is that **it was not true**, and that nothing
in the system would have told us.

### The eighteen routes, and what each is

**The sharing protocol, channel E-1** — these are the Delta Sharing
protocol's own paths, and on these routes the edge path is *identical*
to the protocol path, because the recipient's client builds them itself:

| | Route | What it does | Class |
|---|---|---|---|
| S1 | list shares | the entry point a client calls first | A |
| S2 | share detail | | A |
| S3 | list schemas in a share | | A |
| S4 | list tables in a schema | | A |
| S5 | list all tables in a share | | A |
| S6 | table version | | A |
| S7 | schema and format (metadata) | **carries the protocol capability header** | A |
| S8 | **query a table** | where data actually leaves | B |
| S9 | change data feed | | B |
| S10 | **temporary table credentials** | vends an object-storage credential | C |
| S11 | the Iceberg REST surface | **not exposed — explicit deny** | deny |

**The storage proxy** — F1, file download, on its own listener because
it is not part of the sharing protocol's path space. Class D.

**The AI surface, channel E-3** — M1, model serving invocations. M2,
Unity Gateway MCP. M3, the legacy managed MCP surface, **not exposed**.
A1, every other Databricks REST API — SQL statements and the rest —
**not exposed**, and the reason is obvious once stated: the sharing host
is a Databricks host, and if you front it carelessly you have fronted
the whole workspace API.

**Ingress, channel I-2** — I1, push ingest: a producer uploads one file
to its own landing volume.

**X** — everything else, denied.

### The two rows that are ahead of the document

S11 and I1 both exist in our route table and **not** in CONOPS §2.3.2.
Both are labelled as such rather than quietly added, and both carry what
sanctions their existence.

S11 came out of a repair. Fixing an unrelated bypass made the Iceberg
endpoint rewrite to our gateway, which exposed a hole the bypass had
been masking. Iceberg is a **second data plane** that hands out
credentials for direct object-store reads — exactly the bypass OD-1(b)
exists to close. So it is denied explicitly rather than left to fall
through.

I1 exists because §2.4.5 describes push ingest as a channel but gives it
no route id and no policy class. We invented both, deliberately, and
labelled them. **v1.6 owes §2.3.2 a row for each.**

Say this plainly in a review. A route that is ahead of the document and
*says so* is a governance item; a route that is ahead of the document
and does not say so is an audit finding.

### B-48 — the finding that changed the epic

Here is the mechanism, and it is worth being able to say it cleanly.

In Gravitee, a request that matches no flow is **not refused. It is
forwarded upstream.** The route table, as written, was a documentation
allow-list. It described what we intended to carry. It enforced nothing.

Why did nothing fail? Because the sharing routes *looked* confined. The
upstream target is a deep base path on the per-recipient sharing host,
and an unlisted path appended to that deep base path landed somewhere
that did not exist, and the upstream returned an error. The perimeter
appeared to hold.

**It was holding by string concatenation.** Confinement was a property
of how two strings joined — not a decision, and one target edit from
being gone.

The fix was to build the deny explicitly: a catch-all that refuses
anything outside an allow-list derived from the forwarding routes' own
definitions, so the allow-list cannot drift from the route table. §3.2
had anticipated exactly this and named "explicit catch-all deny" as the
fallback for its deny-by-default capability. **The fallback was not a
compromise; it was the only route.**

This mechanism appeared **three times** in this epic. The third time was
in a route built *after* B-48 was written up, by the person who had
written it up. That is the strongest possible argument that it is a
structural property of the platform rather than three mistakes, and that
is how we present it:

> **Anything not explicitly refused at a Gravitee edge is forwarded, and
> a test that does not observe the refusal is measuring the upstream.**

### What the deny path costs

Route X refuses correctly and it refuses **without a reason**. It
returns a bare 403 with no body.

§2.3.2 requires denials in the **protocol error format** — a structured
body with an error code and a message. We cannot produce it on the
egress deny path, and we know exactly why: the policy that performs the
path filtering has no message, body or status field, and a response-phase
policy that would add one **never runs**, because an interrupting
request-phase policy answers immediately and the response chain is
skipped.

We checked this rather than assumed it: every installed policy on the
gateway was read, all seventy-nine of them, and none both refuses and
emits a body.

So §2.3.2's requirement is **met on ingress and not on egress**. On
ingress we control the refusal statuses, so I1's refusals are specific.
On egress we do not. That asymmetry is real, it is not going away
without a component in front of the gateway, and **v1.6 should state it
rather than imply uniformity**.

---

## Part 4 — The policy classes, and why the numbers are what they are

§2.3.3 defines policy classes so that routes with the same risk get the
same treatment and nobody tunes a limit per route by hand. There are
five in the document; we have six plus a deny class.

### What each class is for

**Class A — metadata and discovery reads.** S1 through S7. Cheap,
idempotent, no request body, no credential vending, no bulk data. A
client browsing a share hits these repeatedly and legitimately, so this
is the loosest class: **60 per minute, 5 per second**.

**Class B — data queries.** S8 and S9. This is where data actually
leaves. Tighter — **20 per minute, 2 per second** — and the only class
that validates a request body.

**Class C — credential vending.** S10 alone. The tightest class:
**10 per minute, 1 per second**. The reasoning is worth repeating out
loud because it is the clearest risk argument in the design: *a
successful call here hands the caller a credential for object storage,
so the blast radius of an over-permissive limit is larger than on any
data route.*

**Class D — file download through the storage proxy.** F1. Bulk bytes,
so the loosest quota of all at **120 per minute**, and no spike arrest,
because a download is not a burst. Two constraints make this class
special: range requests must pass through, and the signed query string
must be forwarded **unchanged** — any rewrite of it invalidates the
signature, turning a working download into a 403 that looks like a
storage-side refusal.

**Class E — the AI routes.** M1 and M2. **30 per minute, 3 per second.**
Unlike A–D, these sit in front of a service that **has its own rate
limiter**, which makes this the only class where "whose limit refused
this?" is a live question — and that question has a known-bad answer
mode, described in Part 8.

**Class I — push ingest, edge refusals only.** I1. The only ingress
class, invented by us. Five steps in a load-bearing order, covered in
Part 6 under T-24.

**The deny class.** S11, A1, M3 and X. Not forwarded.

### The per-consumer question — and the thing that is quietly load-bearing

§2.3.3 says *"class settings are per consumer."* Two policies implement
throttling, and only one of them is keyed.

The **rate limit** is keyed on the caller's authorization header. Since
the plans are key-less — Gravitee has no subscription to key on, because
our consumers authenticate with a Delta Sharing bearer token and nothing
else — a hash of that token is the only consumer identity available.
That makes it a **per-credential** limit, which equals per-consumer only
while one credential means one consumer. If a recipient shares its
credential between two of its own systems, the limit is shared too, and
that is invisible at the edge. Recorded as a limitation of the key-less
choice, not as a defect.

The **spike arrest is not keyed at all.** It is one bucket for the whole
API.

So how is §2.3.3's "per consumer" satisfied for spike arrest today? **By
the route shape, not by the policy.** One API per recipient means a
recipient can only exhaust its own bucket.

That is a correct outcome reached by an accident of a different
decision, and it is fragile in a specific way: **any future
consolidation onto a shared route silently reintroduces one caller
throttling another**, and the requirement that broke would be a policy
requirement carried by a routing decision, which is the last place
anyone would look. Flag this whenever someone proposes collapsing the
route family.

---

## Part 5 — AC2 clause by clause

This is the spine. For each clause: what it asks, why, how we built it,
which test measures it, and — the part that matters — **what the test
proves and what it cannot**.

### Clause 2.1 — the gateway is the only public surface, and the caller never holds a Databricks credential

**What it asks.** Two things in one sentence: everything reaches
Databricks through us, and nothing the caller holds would work against
Databricks directly.

**Why.** It is the architectural principle the whole CONOPS rests on. If
either half fails, every other control is optional.

**How built.** The recipient's credential is rewritten so its endpoint
is our gateway. The route family covers the protocol. Route X refuses
everything else. On the AI routes, the upstream credential is held by
the gateway as a property and injected — the consumer never sees it.

**Measured by T-01**, which reads every discovered protocol path through
the edge and compares each response against the *same path read
directly, in the same run, with the same credential*.

**What it proves.** That the edge is faithful — that routing a recipient
through us does not change what they get. That is the permissive half.

**What it does not prove, and this is the important half.** T-01 green
proves the perimeter does not **over-refuse**. It would be exactly as
green against a whitelist that admitted everything. Faithfulness and
confinement are different properties and T-01 measures only one. The
refusing half is clause 2.3's job, and that separation is the single
most useful idea to take from this epic.

**Where it stands.** Evidenced on egress. On ingress it is evidenced in
part: the producer holds nothing, which is the hard half, but the
upstream credential is not yet injected on the push route — see Part 11,
and note the sequencing constraint there, which is not optional.

### Clause 2.2 — internal headers and hostnames removed from the response

**What it asks.** That a response leaving the edge does not tell the
caller what is behind it.

**Why.** Mundane but real: product names and versions are
reconnaissance, and an upstream hostname in a header undoes the point of
putting a gateway in front.

**How built.** A response-phase step removes a named list of headers.
Crucially the list is an **allow-list of what may pass**, derived from
measured before-and-after captures, not a deny-list of what to strip —
a deny-list is a list of the headers somebody already thought of.

**Measured by T-07.**

**What it found, and it is a good story.** When the epic opened, a
successful read returned the upstream product name, a request id, a
timing header and three gateway headers to the caller. Six headers.

- Three were removed by policy, measured, with a positive control
  proving the sanitizer was running rather than the upstream having
  stopped sending them.
- **Three could not be removed by any policy at all** (B-45, then B-52).
  They are stamped after the policy chain has finished. No ordering
  fixes that. They were eventually fixed by a *gateway-level setting* —
  the right diagnosis was "this is the wrong layer", and it sat
  correctly diagnosed and unfixed for days before anyone went looking
  for the setting.
- A fourth header had been captured leaking weeks earlier, written into
  this epic's own task text, and **never added to the removal list**. It
  was gone within minutes of being put there. That is a deny-list
  failing exactly as the task that wrote it predicted.

**Two limits remain, and you should state both.**

First, **the allow-list is enforced by the test, not the gateway.** The
header policy can add and remove named headers; it cannot express "keep
only these", and no installed policy can. So a header that a future
upstream version starts sending reaches clients until the next test run.

Second, **B-55: sanitization covers successes, not refusals.** The
removal step is in the response phase. A request-phase refusal answers
immediately, so the response chain never runs and nothing removes what
the gateway attached. Every refusal the *perimeter* raises goes out
unsanitized; refusals from *Databricks* traverse the chain normally and
are sanitized. **The line falls on who refused, not on the status code.**

What leaks is a product name and an opaque caller id — no credential, no
path, no hostname. Severity low. **The correction is to the claim**,
which read as total and was not.

**How we found it is the lesson.** Not by looking. A throttle test
captured a 429 and the header was sitting in it. T-07's reasoning was
sound; its *sample* was one-sided, because every probe it ran drove a
successful read. Which gives the sentence worth keeping:

> **A control is only measured on the responses the test provokes. For
> any response-phase control, ask which responses never reach that
> phase — then probe those on purpose.**

### Clause 2.3 — routes are explicit, and routes not listed are denied

**What it asks.** Both halves: listed routes work, unlisted routes are
refused.

**Why.** It is the perimeter.

**How built and what it cost.** This is B-48, told in Part 3. Short
version for a conversation: *deny-by-default is not native to this
gateway — an unmatched route is forwarded — so we built an explicit
catch-all, which is the fallback the CONOPS itself names for this
capability.*

**Measured in both directions, and the two directions are different
tests.** The permissive half is T-01. The refusing half is a dedicated
probe of unlisted paths with a **before-and-after control on either
side**: a legitimate request succeeds, seven unlisted paths are refused,
a legitimate request succeeds again. Seven of seven refused at the edge.

**Why the controls matter.** A refusal with no control either side is
indistinguishable from a broken route. The controls convert "it
refused" into "it refused *and the route was working at that moment*".

**One subtlety worth having ready**, because it is the kind of thing a
sharp reviewer asks: how do you know the *edge* refused, rather than
Databricks? Because Databricks also answers 403. Status alone identifies
nothing. Every probe attributes the refusal by **the responder's own
voice** — the specific wording in the body, which differs between the
gateway's refusal and the upstream's. We learned that by getting it
wrong first: a probe once read 403 as "the edge refused" purely from the
status code.

**Where it stands.** Evidenced, both directions. Limit: the reasonless
403, covered above.

### Clause 2.4 — request validation at the edge

**What it asks.** That malformed and oversized requests are rejected
*by us*, not passed to Databricks to deal with.

**Why.** Two reasons, and the second is the one people forget. The
obvious one is compute protection. The second is that a request rejected
upstream has already consumed the upstream — the point of edge
validation is that the upstream never sees it.

**How built, egress.** Class B carries a body schema on the query route.
The schema is **derived from the route table's own declaration of the
allowed fields**, not hand-written, so the schema and the route table
cannot disagree. Four guards refuse to generate it rather than emit a
permissive one — because an absent policy and a policy that validates
nothing are indistinguishable from outside, and only one of them is a
decision.

**Measured by T-06**, which sends three rejections and two acceptances,
each body sent **direct and through the edge in the same run**. The
acceptances are the positive control: without them, a validator that
rejects everything scores perfectly.

**How built, ingress.** Class I on the push route, five steps whose
**order is load-bearing**. Covered under T-24 in Part 6.

**Where it stands.** Evidenced on both sides.

### Clause 2.5 — throttling to protect compute resources

**What it asks.** Re-read the §2.3.3 sentence: the gateway limit sits
below the Databricks limit *so the edge trips first*.

**Why.** It is the compute-protection argument — the thing the ARB will
ask about before anything else in AC2, because it is the clause with a
cost attached.

**How built.** Rate limit plus spike arrest per class, values as in
Part 4.

**Measured by T-05**, in four phases, and the phase design is the point:

- **Phase 0** drives a successful request, so a later 429 is
  attributable to a throttle rather than to a broken route.
- **Phase 1** bursts ten requests in two tenths of a second to trip
  spike arrest.
- **Phase 2** waits a full minute so both windows clear — *without that
  wait, phase 1's requests have already spent the minute budget and
  phase 2's trip point means nothing* — then paces requests under the
  spike limit until the per-minute limit trips.
- **Phase 4** waits and sends one more request. **A throttle that does
  not clear is an outage, not a throttle.** This is the control in the
  other direction and it is the one most tests omit.

**What it proved.** Both limits trip where configured and both clear.
The per-minute limit trips exactly at request 61 of a 60-per-minute
window. The route answers normally before and after.

**Two findings came out of reading the refusal bodies rather than the
status codes**, and both are things the CONOPS does not currently say:

**First, the spike limit is smoothed.** The gateway says so itself, in
its own refusal text: a limit configured as *five per second* is
enforced as *one request per 200 milliseconds*. Ten requests inside two
tenths of a second produced one success and nine refusals, with the
first refusal at **request two**, not request six.

Why that matters to a consumer: five requests spread evenly across a
second pass. The same five inside a hundred milliseconds do not. **The
constraint is on instantaneous burst, not on per-second volume**, so a
reference client must *pace* rather than budget. §2.3's own words — the
class values are "proposals to be tuned in the Section 5 tests" — cover
the *number*. They do not cover a different enforcement *shape*. A
consumer who reads "5/s", builds a five-request burst and gets throttled
will report a defect, and the gateway will be behaving exactly as
configured.

**Second, neither refusal carries a retry indication.** No `Retry-After`,
no rate-limit headers. The two throttles are distinguishable — but
**only by the wording of the body**; status and headers are identical,
so an operator reading status codes cannot tell a burst from a quota.

That is risk **R9 realised**, and §3.2's named fallback for this
capability is precisely "record the actual response". So the fallback
was **taken, not failed** — a distinction worth making explicitly,
because "fallback taken" reads as a miss unless you say that the CONOPS
pre-accepted the outcome. The consequence lands on §2.3.4: **the
reference clients need a backoff of their own**, because nothing will
tell them when to retry.

**What is still NOT measured, and say this before you are asked.** That
the edge trips *before* Databricks. Demonstrating it requires counting
the requests that actually reached the upstream, which means reading the
platform's access audit table — and this workspace tier does not expose
it. A 429 at the edge is consistent with the upstream never being called
and does not demonstrate it.

So: **the mechanism is measured, the claim is not.** The gap is one
system table wide. It is named, it has an owner, and it is the first
resource to chase in the client environment.

---

## Part 6 — The tests, and what each one means

T-01, T-06 and T-07 are covered above. These are the rest.

### T-03 — a valid token from an address that is not on the allow-list

**The CONOPS question.** §2.3.4 relies on an address allow-list plus the
recipient IP list to bind a consumer to where it calls from, because
client certificates are a property of the reference clients and not of
the gateway.

**What the test does.** Presents a *valid, live* credential from an
address that is not permitted, and confirms refusal — then **reverses
it** and confirms the same call succeeds.

**Why the reversal is the test.** A deny that has only ever read "denied"
is indistinguishable from a control nobody has armed. Arming it,
observing the refusal, disarming it and observing success is what turns
a configuration into evidence.

**What it showed beyond the pass.** Three layers refuse independently —
the gateway edge, the recipient IP access list, and Databricks' own
host-to-token binding. One of our recipients is refused by **both**
allow-lists at once, and they are not even comparing the same address:
Databricks sees the host's public address, the gateway sees its
container address. That is layering genuinely working, and it is also
why one of T-01's four checks can only ever report "cannot see".

### T-05 — throttling

Covered in clause 2.5. The one thing to add: **T-05 was deliberately not
used to tune the numbers.** §2.3.3's values are proposals and the test
was expected to tune them. The measured *shape* makes the numbers the
wrong thing to change first — a class whose limit is enforced as a
200-millisecond gate needs its shape described in v1.6 before its value
is argued about. And changing a limit so that a test reads better is the
exact failure the repository records as a rule: **a configuration value
changed so a gate passes is a disabled gate.**

### T-24 — the edge half of push ingest

**The CONOPS question.** §2.4.5 describes ingress push: a producer
uploads a file. The rule is the mirror of egress — the gateway is the
only public surface and the producer never holds a Databricks
credential.

**What makes this route different from every other one.** On egress, the
refusal statuses are whatever the platform gives us. On ingress **we
choose them**, which means we can meet §2.3.2's specific-reason
requirement here even though we cannot meet it on the egress deny path.

**The five checks, and why the order is load-bearing:**

1. **Method and path confinement** — only a PUT, only inside the
   producer's own prefix.
2. **Path character allow-list** — rejects traversal. **400.**
3. **Size limit** — one megabyte. **413.**
4. **Content type** — **415.**
5. **Overwrite guard** — refuses writing over an existing object. **409.**

Order matters because a wrong order gives a *correct refusal for the
wrong reason*. Put the content-type check before the method check and a
GET gets told its content type is wrong rather than that its method is
not allowed. The status is a refusal either way; the message is a lie.

**T-24 found B-54, and this is the finding to tell if you only tell
one.** Path traversal was being **forwarded to Databricks**. Two of
three traversal forms reached the upstream. The one that was stopped was
stopped by the gateway's own path handling, not by any policy of ours.

The dangerous part is what came back: **a 401, which proves nothing**.
Databricks checks the credential before it resolves the path, so a 401
says only "no credential". It does not say the path would have stayed
inside the producer's volume. The escape was unmeasured — and
**unmeasurable while nothing authenticates**, which is precisely the
state in which it looks harmless.

The fix was a **character allow-list** on the path rather than a deny
list of escape sequences, because a deny list is a list of the escapes
somebody already thought of. Excluding the percent sign from the
permitted characters refused every percent-encoded form, which covered
the double-encoded case nobody had enumerated.

**The sequencing constraint this creates is not optional and belongs in
any handover conversation.** Credential injection on the push route must
**not** be built before the path rule is measured working on a route
that authenticates. The moment a forwarded request authenticates, a
traversal becomes a real write outside the producer's landing volume —
and T-24 would score that **200 and pass**, because a successful upload
is what its positive controls look for.

**What T-24 does not cover.** Content scanning. §2.4.5 calls it a
platform security capability, not a gateway policy, and OD-9 leaves it
unowned. Six passing edge refusals check the **shape** of a request and
say nothing about what is inside a file whose shape is permitted. The
route is confined to the test environment for exactly that reason, and
the refusals passing does not widen it.

### T-11 — correlation

**The CONOPS question.** §3.5 and AC5 need a request to be traceable
from the client's hand to the gateway's log.

**Why it belongs in this epic's story even though AC5 owns it.** Because
of what happened. Suppressing the gateway's own identifying headers —
the correct fix for clause 2.2 — removed the only client-visible
correlation handle, since our correlation id was being injected on the
request phase only and never appeared in the response. **T-07 passed its
leak half in the same run in which AC5 had no handle at all.** A green
test over a broken capability.

The remedy was a deliberate, reserved exception: one header we *add* on
the way out. **A leak test alone is not enough to accept a sanitizer** —
you also need an assertion that the thing you meant to keep is still
there.

A related finding, B-53: §2.3.3 requires metadata-only logging, and it
sat **unimplemented with nothing failing**, because no test ever asked
the gateway whether it reported. *A requirement nothing tests is a
requirement nothing enforces.*

### T-08, T-09, T-15, T-16 — the four that could not run here

Covered in Part 11 with the reason each one is blocked, because the
reasons are different and the differences matter.

---

## Part 7 — §3.2's capability table

This table is, in my view, the most honest thing in the CONOPS: seven
capabilities the design depends on, each marked *"not yet confirmed for
the Gravitee version in use"*, each with a named fallback. Replacing
those cells with measurements against the actual deployed version was
Epic 2's main contribution.

**Four of the seven now carry an observation: two answered, two answered
in part. Three carry a stated reason they cannot be answered yet.**

| Capability | Where it stands now |
|---|---|
| **Deny by default for unlisted routes** | **Answered.** Not native — an unmatched route is forwarded. Explicit catch-all built and measured, seven of seven unlisted paths refused with controls either side. **Fallback taken, and it was the only route.** Limit: reasonless 403. |
| **Return 429 with a retry indication** | **Answered.** 429 on both limits; the retry indication is confirmed **absent**. R9 realised; §3.2's "record the actual response" fallback taken. |
| **Rate-limit key from the authorization header** | **In part.** Measured enforcing on one key — trips exactly at 61. Isolation *between* keys not yet measured. The per-consumer property currently rests on the route shape, with the key as a second line proven present and unproven separating. |
| **Path rewrite and upstream credential injection** | **In part — and the halves are in different states.** *Injection* works and is confirmed on the AI route; the consumer never holds the credential. *Rewrite* is **not demonstrated** — the push route's upstream path comes from string concatenation, which is B-48's mechanism wearing a useful hat, and scoring that as a rewrite would be a false capability claim. **R12 stays live.** |
| **Validate the agency JWT** | **Not applicable until OD-5 decides.** We build the bearer-token branch. Reporting a JWT result would imply a decision nobody has made. |
| **Rewrite file URLs; forward signed storage requests including range** | **Cannot be measured here.** No static upstream — the host lives inside the pre-signed URL. On this tier storage is platform-managed, so the refusal half has no subject either. |
| **Client certificate support in reference clients** | **Not a gateway property.** §2.3.4 already names the fallback: the address allow-list plus the recipient IP list carry the binding, and that is measured working by T-03. |

**No row is blank and no row claims more than was measured.** That
sentence is worth saying out loud in the review, because the instinct in
the room will be to read empty-looking cells as incomplete work.

---

## Part 8 — What we learned about the platform

These are the facts that will outlive the prototype. They are what makes
the production build cheaper, and they are the most quotable part of the
epic.

### About the gateway

- **An unmatched route is forwarded, not refused.** Three times, in this
  one epic. Treat it as structural.
- **A request-phase refusal skips the response phase entirely.** This
  single fact explains three separate findings: a refusal cannot carry a
  reason added downstream (the reasonless 403), a refusal is not
  sanitized (B-55), and a refusal cannot be given a correlation id on
  the way out.
- **Some headers are stamped after the policy chain** and are
  unreachable by any policy. They are reachable by gateway
  configuration — which lives outside the API definition, and therefore
  outside the thing we version as code. For this one case the setting
  landed in a file we do version, so the "redeploy from code" claim
  holds; the general point stands for any gateway setting that does not.
- **Spike arrest smooths its window.** Five per second is one per two
  hundred milliseconds.
- **Spike arrest cannot be keyed.** The rate limit can.
- **Pattern languages differ between policies.** The route definitions
  name parameters one way; the path filter expects a different pattern
  syntax, and its patterns are relative to the API's own base path, not
  absolute. We got this wrong twice — right derivation, wrong language,
  then right language and wrong scope — each costing a full
  generate-deploy-test cycle. The generalisation: **a derivation is only
  as sound as its claim about how the consumer reads what was derived,
  and that claim has to be written down somewhere it can be checked.**
- **No installed policy both refuses and emits a body.** Measured across
  all seventy-nine.

### About the platform we are fronting

- **The sharing host is bound to the recipient.** One route cannot front
  all recipients.
- **The pre-signed URL's hostname is inside its own signature.** You
  cannot rewrite it without invalidating it. This is not a limitation to
  engineer around; it is the sharpest statement of why OD-1 is a real
  decision.
- **Recipient tokens expire 24 hours after activation, against a
  configured 7 days.** Measured on three recipients for three. Every
  credential needs re-activating the morning of a demo, and AC4's
  self-service portal inherits a daily re-activation step nobody has
  costed.
- **The credential check happens before path resolution**, which is why
  a 401 on a forwarded traversal proves nothing.
- **A broken MCP service answers HTTP 200 carrying an error**, so a
  status-code health check reports it healthy. Monitoring's problem, not
  this epic's — but nothing we built would have caught it either.

---

## Part 9 — The method, and why it will be asked about

If the evidence is challenged, it will be challenged here. These are the
rules the tests are built on. Each one exists because of a specific
mistake.

**A refusal must be attributed, not assumed.** Databricks answers 403
and so does the edge; status alone identifies nothing. Every probe
attributes by the responder's own voice.

**A perimeter test that never observes the perimeter absent is measuring
the wrong thing.** A faithfulness test is green against a whitelist that
admits everything.

**A control is only measured on the responses the test provokes.** The
sharper cousin, and the newest. T-07's probes all succeeded, so it
measured the half of the control that successes exercise.

**A header absent from a response is not evidence of redaction.** Five
of the names on our removal list were never sent by the upstream at
all. Counting them would have credited the sanitizer with work nobody
did.

**A positive control in the same run, on the same path.** A conditional
refusal and a silently omitted policy look identical from outside, so
the permitted case must succeed in the same run in which the forbidden
case is refused.

**Three verdict states, not two.** "Cannot see" is a result. Collapsing
it into pass or fail is how a credential expiry becomes a gateway
finding — which happened, and was caught because the third state exists.

**A configuration value changed so a gate passes is a disabled gate.**
Twice avoided deliberately: an exposure flag that would have let a live
route past an invariant, and a local-test address range that would have
made an IP filter permissive.

**An exit code is a summary somebody else wrote for their own purpose.**
The newest rule, and it cost us. A helper read a non-zero exit code as
"the step failed" when the step had succeeded and the exit code was
describing the *environment*. Ask the step what it did; it says so in its
output.

**A finding recorded is not a finding fixed.** Two requirements in this
epic sat correctly diagnosed and unimplemented for days with nothing
failing.

---

## Part 10 — Decisions and risks in play

**OD-1 — the storage proxy.** Do the bytes traverse the edge?
**Recommendation: defer, do not decide.** It turns on T-08, which cannot
run here for a platform reason rather than a scheduling one. Option (b)
— storage address limits plus short-lived credentials — is the working
assumption because it is the only branch that does not depend on a
rewrite nobody has demonstrated. The decision is cheap to defer and
expensive to get wrong. §2.3.2's documented fallback is intact and needs
no gateway capability we have failed to find.

**OD-3 — token policy.** Relevant because of the 24-hour lifetime. Needs
a decision about operational cost, not a technical fix.

**OD-5 — the sign-in method.** Blocks the JWT capability row. We build
the bearer-token branch and label every policy value as a prototype
default rather than a policy.

**OD-9 — content scanning ownership.** Unassigned. This is an *ask*, not
a status. Route I1 stays confined until it has an owner.

**R9 — no retry indication.** Realised, measured, fallback taken. The
consequence lands on §2.3.4's reference clients.

**R10 — client certificates.** Property of the clients; fallback named
and measured.

**R12 — path rewrite unproven.** Live. See the §3.2 table.

---

## Part 11 — What is not done, and precisely why

Every item here names the specific thing that unblocks it. "Needs the
client environment" is not a reason — it is a restatement.

**Clause 2.5's claim** needs the platform's access audit table, so the
requests that reached the upstream can be counted. Nothing in this
environment can substitute.

**T-08 and route F1** need customer-managed storage, so that a storage
host exists somewhere other than inside the pre-signed URL — or a
decision to accept OD-1(b). No test is written for it on purpose: a test
that cannot observe its subject returns "cannot see" at best and a false
green at worst.

**T-15 and T-16** need a deployed serving endpoint and MCP availability.
The route, the class and the credential injection are built; what is
missing is something live behind them.

**T-09** needs OD-5 decided, and then an issuer to validate against.

**Path rewrite and R12** need the producer's landing volume provisioned
— in a schema that is *not* the published one — so there is something to
route to. And the sequencing rule from T-24 applies: the path allow-list
must be measured working on an authenticating route first.

**The two remaining clause 2.2 limits** — allow-list enforcement and
B-55 — need either gateway-level configuration access or a component in
front of the gateway. Neither is expressible as a policy, by an argument
we have now reached from both directions.

**The ARB package** needs the corporate template. The AC2 content is
written and traceable; what is missing is the shape it has to be poured
into.

**What is owed here, before any migration**, and this is the list that
keeps the deferred list honest: re-run the perimeter tests on refreshed
credentials so the archived evidence is not dominated by "cannot see";
measure rate-limit isolation between two live credentials, which is
blocked by nothing but token expiry; run the refusal-sanitization probe
so B-55's extent is measured rather than argued from the mechanism; and
re-run the gates from inside the migration archive rather than from the
working tree — because Epic 1's archive passed in the working tree and
was still wrong.

---

## Part 12 — The questions you will be asked

**"Is AC2 met?"**
Four of five clauses are evidenced. Clause 2.5's mechanism is measured —
both throttles fire and clear exactly where configured — and clause
2.5's *claim*, that the edge trips before Databricks, is not, because
demonstrating it needs an audit table this tier does not expose. I would
rather state that than show a configuration listing and let the room
infer enforcement.

**"So the rate limiting doesn't work?"**
It works and it is measured working. What is unmeasured is that it
protects *compute* — that the upstream never saw the burst. Those are
different claims and only one of them is in the acceptance criterion's
purpose clause.

**"Why did you build a catch-all deny instead of using the gateway's
deny-by-default?"**
Because this gateway does not have one. An unmatched route is forwarded
upstream, not refused. §3.2 anticipated that possibility and named the
explicit catch-all as the fallback — so the fallback was not a
compromise, it was the only route available.

**"How do you know the gateway refused it and not Databricks?"**
Because we attribute by the responder's own wording, not by the status
code. Both answer 403. We learned that by getting it wrong once.

**"Your header sanitization test passed. Then why is there a header
leaking?"**
Both are true. The removal list works, and the step that applies it runs
in the response phase, which a request-phase refusal never reaches. So
successes are sanitized and perimeter refusals are not. We found it by
accident in a throttle test, and the correction is to the claim, which
read as total.

**"Why is there a route in your table that isn't in the CONOPS?"**
Two of them, and both are labelled as such with what sanctions their
exposure. One is an explicit deny on a second data plane we found while
repairing something else; one is the push ingest route, which §2.4.5
describes as a channel without giving it a route or a class. v1.6 owes
both a row.

**"Why one API per recipient? That seems like a lot of objects."**
Because the platform binds the sharing host to the recipient — a token
issued for one recipient is refused at another's host. There is no
single upstream to point a shared route at. It also happens to be what
makes the unkeyed spike arrest safe today, which is worth remembering
before anyone consolidates them.

**"What is the biggest risk you are carrying out of this epic?"**
Not a control — a shape. Three separate findings in this epic were
"something that looked enforced was not": the route table that enforced
nothing, the logging requirement nothing tested, and the sanitizer that
only ever saw successes. The risk is that the fourth one exists and
nothing has provoked it yet. That is why the tests are built the way
they are, and why "cannot see" is a verdict.

**"Can you redeploy this from code?"**
The generated configuration's input hashes are recorded, so the claim is
checkable rather than asserted. One caveat stated honestly: a gateway
setting fixed outside the API definition would sit outside that claim.
For the one case we hit, it landed in a file we version, so it holds.

**"What do you need from us?"**
One thing above all others: the access audit table. It is the only item
standing between clause 2.5 and an evidenced claim, and clause 2.5 is
the compute-protection argument. After that: an owner for content
scanning, a decision on OD-5, and a landing volume.
