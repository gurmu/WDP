#!/usr/bin/env python3
"""E2 Task 2.4 / PC-4: does the reason-carrier run after the enforcer refuses?

scripts/34 settled the SHAPE of route X: no single installed policy both
refuses and emits a body, so it is a pair --

    enforcer = resource-filtering   (the only MEASURED fail-closed one)
    carrier  = policy-assign-content (supplies the body it cannot)

and left one question open, recorded in policy-classes.yaml PC-4:

    Whether a response-phase policy runs at all after an interrupting
    policy has already refused the request.

If it does not, route X carries no `errorCode`, §2.3.2's "denied in the
protocol error format" cannot be met by this pair, and that becomes an
accepted limit rather than something to design around. That is AI-9's
outcome a second time, and it is better to know now than after route X
is generated across every API.

WHY THIS BUILDS ITS OWN API
---------------------------
The question could be answered by adding the pair to a live route and
watching. It must not be. The live APIs are the perimeter T-01 and T-03
read through, and docs/11 B-48 records what a whitelist wrong by one
pattern does to them: both tests' positive control becomes a 403, and
the epic loses its baseline. So this probe creates a throwaway API on a
context path nothing else claims, exercises it, and deletes it in a
`finally` -- including when an assertion fails, because a probe that
leaves a half-built API behind has changed the thing it was measuring.

WHAT THE TARGET IS, AND WHY IT IS DELIBERATELY DEAD
----------------------------------------------------
The upstream is 127.0.0.1:1, which refuses connections. That is the
point: this probe never asks whether a request reaches an upstream, only
whether the EDGE refused it. A 502 therefore means "the policy did not
refuse" and is a positive control, not a failure. Pointing it at a real
host would make a successful forward indistinguishable from a policy
that was never evaluated, and would put probe traffic on a real
endpoint for no gain.

The three observations, and each needs the other two to mean anything:

  allowed path   -> NOT 403. Proves the whitelist admits what it lists,
                    so a 403 below is the pattern and not the policy
                    refusing everything. Without this the probe cannot
                    tell a working allow-list from a broken one.
  unlisted path  -> 403. The refusal itself.
  encoded path   -> 403. normalizeRequestPath and decodeEncodedSlash are
                    both set, and the live AI route sets them too, so
                    this confirms the setting does what its description
                    claims rather than trusting the description.

And then the actual question: does the 403 carry the body the carrier
assigned?
"""
import json
import os
import sys
import time
import urllib.error
import urllib.request
from base64 import b64encode
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
EVIDENCE = REPO / "evidence" / "deny-pair-probe.json"

CONTEXT = "/awoz1227-denyprobe"
ALLOWED = "/allowed"
DENIED = "/denied"
ENCODED = "/%64enied"          # /denied with the d percent-encoded
DEAD_TARGET = "http://127.0.0.1:1"

PROTOCOL_ERROR_BODY = json.dumps({
    "errorCode": "RESOURCE_DOES_NOT_EXIST",
    "message": "This path is not exposed. See CONOPS 2.3.2 route X.",
})


def load_env():
    env = REPO / ".env"
    if not env.exists():
        raise SystemExit(f"Missing {env}.")
    for line in env.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        if v.strip():
            os.environ.setdefault(k, v)


def require_env(name, what):
    val = (os.environ.get(name) or "").strip()
    if not val:
        raise SystemExit(f"Refusing to run: ${name} is unset. It names {what}.")
    return val


def req(url, auth=None, method="GET", body=None, timeout=30):
    data = json.dumps(body).encode() if body is not None else None
    headers = {}
    if auth:
        headers["Authorization"] = auth
    if data:
        headers["Content-Type"] = "application/json"
    r = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            return resp.status, resp.read().decode(errors="replace")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode(errors="replace")
    except Exception as exc:  # noqa: BLE001
        return None, repr(exc)


def api_body():
    """One API, two flows. The terminal flow's selector is `/`
    STARTS_WITH, which docs/11 B-48's second retraction says Gravitee
    evaluates FIRST -- most generic to most specific, regardless of
    array position. That ordering is the thing being relied on here, so
    it is stated rather than assumed."""
    return {
        "name": "AWOZ-1227 deny-pair probe (throwaway)",
        "apiVersion": "1.0",
        "definitionVersion": "V4",
        "type": "PROXY",
        "description": (
            "Created and deleted by scripts/35_probe_deny_pair.py to "
            "answer PC-4. If this API is still present, that script "
            "crashed between create and delete -- remove it."),
        "listeners": [{
            "type": "HTTP",
            "paths": [{"path": CONTEXT}],
            "entrypoints": [{"type": "http-proxy"}],
        }],
        "endpointGroups": [{
            "name": "default",
            "type": "http-proxy",
            "endpoints": [{
                "name": "dead",
                "type": "http-proxy",
                "weight": 1,
                "inheritConfiguration": False,
                "configuration": {"target": DEAD_TARGET},
            }],
        }],
        "flows": [
            {
                "name": "forwarding flow (the allowed path)",
                "enabled": True,
                "selectors": [{
                    "type": "HTTP", "path": ALLOWED,
                    "pathOperator": "EQUALS", "methods": ["GET"],
                }],
                "request": [], "response": [],
            },
            {
                "name": "terminal deny pair",
                "enabled": True,
                "selectors": [{
                    "type": "HTTP", "path": "/",
                    "pathOperator": "STARTS_WITH",
                }],
                "request": [{
                    "name": "enforcer: allow only listed paths",
                    "enabled": True,
                    "policy": "resource-filtering",
                    "configuration": {
                        "whitelist": [{"pattern": ALLOWED,
                                       "methods": ["GET"]}],
                        # Both default to false. The live AI route sets
                        # them; this probe sets them identically so what
                        # it measures is the same control.
                        "normalizeRequestPath": True,
                        "decodeEncodedSlash": True,
                    },
                }],
                "response": [{
                    "name": "carrier: protocol error body",
                    "enabled": True,
                    "policy": "policy-assign-content",
                    "configuration": {
                        # `scope` is marked deprecated in the schema and
                        # is also `required`. Sent because the schema
                        # demands it; recorded because a deprecated-but-
                        # required field is exactly the kind of thing a
                        # later Gravitee minor removes.
                        "scope": "RESPONSE",
                        "body": PROTOCOL_ERROR_BODY,
                    },
                }],
            },
        ],
    }


def main():
    load_env()
    root = require_env("GRAVITEE_MGMT_API_URL",
                       "the Gravitee management API").rstrip("/")
    edge = require_env("GRAVITEE_EDGE_BASE",
                       "the gateway edge base").rstrip("/")
    user = os.environ.get("GRAVITEE_MGMT_USER", "admin")
    pwd = os.environ.get("GRAVITEE_MGMT_PASSWORD", "admin")
    auth = "Basic " + b64encode(f"{user}:{pwd}".encode()).decode()
    base = f"{root}/management/v2/organizations/DEFAULT/environments/DEFAULT"

    print("=" * 70)
    print("Deny-pair probe -- E2 Task 2.4 / PC-4")
    print("=" * 70)
    print(f"management: {root}")
    print(f"edge:       {edge}")
    print(f"context:    {CONTEXT}  (throwaway, deleted on exit)\n")

    rec = {"task": "E2 Task 2.4 / PC-4",
           "question": "does a response-phase policy run after an "
                       "interrupting policy has refused?",
           "context_path": CONTEXT, "observations": {}}
    api_id = None
    try:
        # Refuse to run if anything already holds this context path: a
        # Gravitee context path is a PREFIX, and colliding with a live
        # API is how the 2026-10-21 import silently placed 1 of 4.
        st, body = req(f"{base}/apis?perPage=200", auth)
        if st != 200:
            print(f"[abort] cannot list APIs -> {st}")
            rec["verdict"] = "CANNOT_SEE_MANAGEMENT_API"
            return 1
        for item in (json.loads(body or "{}").get("data") or []):
            for lis in item.get("listeners") or []:
                for p in lis.get("paths") or []:
                    if (p.get("path") or "").rstrip("/") == CONTEXT:
                        print(f"[abort] {CONTEXT} is already claimed by "
                              f"{item.get('name')!r} ({item.get('id')}). "
                              "Delete it and re-run.")
                        rec["verdict"] = "ABORTED_CONTEXT_PATH_IN_USE"
                        return 1

        st, body = req(f"{base}/apis", auth, "POST", api_body())
        if st not in (200, 201):
            print(f"[abort] create -> {st}: {body[:400]}")
            rec["verdict"] = "COULD_NOT_CREATE_PROBE_API"
            rec["create_status"] = st
            rec["create_detail"] = body[:600]
            return 1
        api_id = json.loads(body)["id"]
        print(f"created probe API {api_id}")

        # A planless API will not start -- Gravitee answers 400. The
        # first run of this probe discovered that and reported only
        # "the route never came up", because it discarded the response
        # body. scripts/05 already carried the finding in a comment:
        # "that was Gravitee refusing to start a planless API, not this
        # script declining to ask".
        #
        # The plan shape below is copied from
        # gravitee/generated/api-m1-ai-gateway.json, which imports and
        # starts on THIS installation, rather than from the Gravitee
        # documentation -- policy-classes.yaml's warning about ids that
        # are right in the docs and wrong in 4.12.23 applies to bodies
        # too. Note what is absent: no `status` field. It was removed
        # from the generated plans on 2026-10-21 because publishing is a
        # separate call, and the field made the artifact assert an
        # outcome it does not control.
        plan = {
            "name": "probe-plan",
            "description": "KEY_LESS, throwaway. Deleted with the API.",
            "security": {"type": "KEY_LESS"},
            "definitionVersion": "V4",
            "validation": "AUTO",
            "mode": "STANDARD",
        }
        st, pbody = req(f"{base}/apis/{api_id}/plans", auth, "POST", plan)
        print(f"plan create -> {st}")
        rec["plan_create_status"] = st
        if st not in (200, 201):
            print(f"  {pbody[:400]}")
            rec["verdict"] = "COULD_NOT_CREATE_PLAN"
            rec["plan_create_detail"] = pbody[:600]
            return 1
        plan_id = json.loads(pbody)["id"]
        st, pubbody = req(f"{base}/apis/{api_id}/plans/{plan_id}/_publish",
                          auth, "POST")
        print(f"plan publish -> {st}")
        rec["plan_publish_status"] = st
        if st not in (200, 201, 204):
            print(f"  {pubbody[:400]}")
            rec["verdict"] = "COULD_NOT_PUBLISH_PLAN"
            rec["plan_publish_detail"] = pubbody[:600]
            return 1

        st, sbody = req(f"{base}/apis/{api_id}/_start", auth, "POST")
        print(f"start -> {st}")
        rec["start_status"] = st
        if st not in (200, 201, 204):
            # The body IS the diagnostic. Throwing it away is what made
            # the first failure of this probe unattributable.
            print(f"  {sbody[:400]}")
            rec["verdict"] = "COULD_NOT_START_PROBE_API"
            rec["start_detail"] = sbody[:600]
            return 1

        # Deployment is asynchronous. Poll the allowed path until the
        # edge stops answering 404, rather than sleeping a guessed
        # interval and reporting whatever happened to be true.
        allowed_status = None
        for _ in range(20):
            time.sleep(1.5)
            allowed_status, _ = req(f"{edge}{CONTEXT}{ALLOWED}")
            if allowed_status not in (404, None):
                break
        print(f"\n[control] GET {CONTEXT}{ALLOWED} -> {allowed_status}")
        rec["observations"]["allowed_path_status"] = allowed_status
        if allowed_status == 403:
            print("          the whitelist refused a path it LISTS. The "
                  "pattern is wrong,\n          so no refusal below is "
                  "attributable to the path.")
            rec["verdict"] = "CANNOT_SEE_WHITELIST_REFUSES_ITS_OWN_ENTRY"
            return 1
        if allowed_status is None or allowed_status == 404:
            print("          the route never came up; nothing to measure.")
            rec["verdict"] = "CANNOT_SEE_ROUTE_NOT_DEPLOYED"
            return 1
        print("          not refused, so the allow-list admits what it "
              "lists\n")

        d_status, d_body = req(f"{edge}{CONTEXT}{DENIED}")
        e_status, e_body = req(f"{edge}{CONTEXT}{ENCODED}")
        print(f"[deny]    GET {CONTEXT}{DENIED}  -> {d_status}")
        print(f"[encoded] GET {CONTEXT}{ENCODED} -> {e_status}")
        rec["observations"].update({
            "denied_path_status": d_status,
            "denied_path_body": (d_body or "")[:400],
            "encoded_path_status": e_status,
            "encoded_path_body": (e_body or "")[:400],
        })

        carrier_ran = False
        try:
            carrier_ran = json.loads(d_body or "{}").get("errorCode") == \
                "RESOURCE_DOES_NOT_EXIST"
        except ValueError:
            carrier_ran = "RESOURCE_DOES_NOT_EXIST" in (d_body or "")
        rec["observations"]["carrier_body_present"] = carrier_ran
        print(f"\n[carrier] assigned body present in the 403? {carrier_ran}")
        print(f"          body: {(d_body or '')[:160]!r}")

        refused = d_status == 403
        enc_refused = e_status == 403
        if refused and carrier_ran:
            rec["verdict"] = "PAIR_WORKS_ENFORCER_REFUSES_AND_CARRIER_DRESSES"
            rec["conops_action"] = (
                "Route X can be generated as this pair. §2.3.2's "
                "'denied in the protocol error format' is satisfiable.")
        elif refused and not carrier_ran:
            rec["verdict"] = "ENFORCER_REFUSES_BUT_CARRIER_DOES_NOT_RUN"
            rec["conops_action"] = (
                "This is AI-9 a second time. The response phase does not "
                "execute after an interrupting policy, so route X refuses "
                "without a reason and §2.3.2's protocol error format "
                "cannot be met by this pair. v1.6 must either record the "
                "reasonless 403 as an accepted limit -- with the "
                "justification that the enforcer fails CLOSED and `mock` "
                "fails OPEN -- or route X moves to a thin service in "
                "front of the gateway, which is a much larger change. Do "
                "NOT substitute `mock` to get the body: on a catch-all "
                "its fail-open mode forwards every unlisted path.")
        else:
            rec["verdict"] = f"UNEXPECTED_DENY_STATUS_{d_status}"
            rec["conops_action"] = (
                "The enforcer did not refuse an unlisted path. Recorded "
                "rather than rounded to the nearer verdict (B-46).")
        rec["observations"]["encoded_path_also_refused"] = enc_refused
        if refused and not enc_refused:
            rec["encoded_path_finding"] = (
                "The plain path was refused and the percent-encoded one "
                "was not, with normalizeRequestPath and decodeEncodedSlash "
                "both true. That is a bypass of the terminal allow-list "
                "and it applies to the LIVE AI route, which sets the same "
                "two flags. Raise before anything else in this epic.")
        return 0
    finally:
        if api_id:
            # Stop, close plans, delete -- in that order, because a
            # published plan blocks the delete and a started API blocks
            # the plan close. Same sequence as scripts/05's retire_api,
            # which paid for the ordering already.
            req(f"{base}/apis/{api_id}/_stop", auth, "POST")
            st, plist = req(f"{base}/apis/{api_id}/plans", auth)
            if st == 200:
                try:
                    doc = json.loads(plist or "{}")
                    rows = doc.get("data", doc if isinstance(doc, list) else [])
                except ValueError:
                    rows = []
                for pl in rows:
                    if pl.get("id"):
                        req(f"{base}/apis/{api_id}/plans/{pl['id']}/_close",
                            auth, "POST")
            time.sleep(1)
            st, dbody = req(f"{base}/apis/{api_id}", auth, "DELETE")
            print(f"\ncleanup: deleted probe API {api_id} -> {st}")
            rec["cleanup"] = st
            if st not in (200, 204, 404):
                rec["cleanup_detail"] = (dbody or "")[:400]
                print(f"  WARNING: probe API {api_id} may still exist. "
                      f"{(dbody or '')[:200]}")
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps(rec, indent=2) + "\n")
        print(f"VERDICT: {rec.get('verdict', 'INCOMPLETE')}")
        print(f"Evidence: evidence/{EVIDENCE.name}")


if __name__ == "__main__":
    sys.exit(main())
