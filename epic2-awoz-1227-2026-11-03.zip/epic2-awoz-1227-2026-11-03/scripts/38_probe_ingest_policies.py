#!/usr/bin/env python3
"""Which installed policies can express the six T-24 refusals?

E2 Task 2.11 | T-24 | R12 | CONOPS 2.4.5, 3.2 | AC2

WHY THIS RUNS BEFORE CLASS I IS WRITTEN
---------------------------------------
Task 2.11 asks for "class I flows with the six refusals". policy-classes
.yaml currently declares A, B, C, D, E and deny -- there is no class I --
so the class has to be written, and writing it means choosing a policy
id and configuration field names for each refusal.

Choosing those from recollection is B-50, which on 2026-10-27 cost a
full generate/import/test cycle: the terminal allow-list was derived
correctly and written in the wrong pattern language because nobody had
written down what the consumer actually reads. The same mistake is
available here six times over.

So this probe asks the installation. It reads every installed policy's
own schema off the management API and reports, per capability, which
policies declare a field that could carry it -- with the field names, so
the class can be written against measured names rather than remembered
ones.

WHAT §2.4.5 ACTUALLY REQUIRES, which is where the six come from
---------------------------------------------------------------
  "The edge route accepts PUT only. GET, LIST and DELETE are not
   forwarded, so a producer cannot read or alter what has been landed."

  "The Files API uploads a file with a PUT to
   /api/2.0/fs/files/Volumes/<catalog>/<schema>/<volume>/<path>, with an
   overwrite parameter. Databricks documents NO SIZE CAP for the REST
   call; the cap here is the gateway limit."

  "A direct call to the Files API with the producer's gateway credential
   fails, and the workspace accepts calls from the gateway addresses
   only."

  "Whether the gateway can inject the token and rewrite the path is
   unverified (test T-24, risk R12). If it cannot, a thin ingest service
   in front..."

Two of those sentences raise the stakes on specific refusals:

  * "no size cap for the REST call; the cap here is the gateway limit"
    means the gateway is the ONLY size cap. If no installed policy can
    enforce one, there is no cap anywhere, and that is a finding for
    §3.2 rather than a detail.

  * "with an overwrite parameter" means overwrite is a QUERY PARAMETER
    on the upstream call, so refusing it is an edge concern and not an
    upstream one. A policy that cannot see query parameters cannot
    refuse it.

CAPABILITY 4 IS ALREADY MEASURED, AND IS NOT RE-ASKED HERE
----------------------------------------------------------
The method refusal is settled. `resource-filtering`'s whitelist carries
a per-entry `methods` list, and T-07 probe U7 measured it enforcing:
a GET to a POST-only path was refused 405 -- the correct status, in the
policy's own voice. That is recorded in policy-classes.yaml PC-4 under
methods_field_constrains_MEASURED. This probe notes it and spends no
calls on it.

WHAT A SCHEMA DOES NOT TELL YOU
-------------------------------
That a policy declares a field is not evidence that it enforces it.
scripts/34 learned this the expensive way on the deny shape: `mock`
declares a status and a body and fails OPEN, which would have made it
the worst possible catch-all. So every candidate here is a CANDIDATE,
and the verdict says so. Behaviour is T-24's job, on a real route, with
a positive control on the same path (B-40).
"""

import importlib.util
import json
import os
import sys
from base64 import b64encode
from datetime import datetime, timezone
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
EVIDENCE = REPO / "evidence" / "ingest-policy-probe.json"
SCHEMA_EVIDENCE = REPO / "evidence" / "ingest-policy-schemas.json"

# The policies the keyword sweep of 2026-10-29 actually surfaced as
# plausible, by name rather than by score. `--detail` reads only these,
# in full, because field NAMES are not enough to write a policy class
# against: `limit` could be bytes, kilobytes or a count, and the first
# version of this probe stored names and not schemas, which left class I
# unwriteable from its own evidence. scripts/34 stored full schemas for
# its candidates and was right to.
SHORTLIST = [
    "request-content-limit",      # SIZE_LIMIT -- named for the job
    "policy-request-validation",  # QUERY_PARAM, CONTENT_TYPE, status
    "transform-queryparams",      # can REMOVE a query parameter
    "dynamic-routing",            # PATH_REWRITE (3.2 / R12)
    "oas-validation",             # content-type, but needs an OAS spec
    "authz-pep",                  # denyStatus -- refuses AND picks a code
    "policy-http-callout",        # errorStatusCode
    "resource-filtering",         # already measured; read for comparison
]


def _load(filename, modname):
    spec = importlib.util.spec_from_file_location(
        modname, REPO / "scripts" / filename)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[modname] = mod
    spec.loader.exec_module(mod)
    return mod


# Imported, not restated: scripts/34 already discovers the catalogue
# across five candidate URLs and records which one answered, and already
# has the auth/env handling and a schema key walker.
P34 = _load("34_probe_deny_policy.py", "p38_p34")
get = P34.get
load_env = P34.load_env
require_env = P34.require_env
walk_keys = P34.walk_keys

# The capabilities the six refusals need, and the words a schema would
# use for each. Deliberately broad: a missed candidate is a policy
# nobody considered, while a false positive costs one read of a schema.
CAPABILITIES = {
    "SIZE_LIMIT": {
        "for": "refusal 1 -- oversize. 2.4.5: Databricks documents no "
               "size cap for the REST call, so the gateway is the ONLY "
               "cap. If nothing can enforce one, nothing caps uploads.",
        "words": ["contentlength", "content-length", "maxsize", "max-size",
                  "size", "length", "limit", "maxlength", "bodysize",
                  "maxpayload", "payloadsize"],
    },
    "CONTENT_TYPE": {
        "for": "refusal 2 -- wrong content type.",
        "words": ["contenttype", "content-type", "mediatype", "mimetype",
                  "accept"],
    },
    "QUERY_PARAM": {
        "for": "refusal 4 -- overwrite. 2.4.5 puts overwrite in a QUERY "
               "PARAMETER, so a policy that cannot read query parameters "
               "cannot refuse it.",
        "words": ["queryparam", "query-param", "queryparameter", "param",
                  "parameters", "query"],
    },
    "PATH_REWRITE": {
        "for": "3.2's unconfirmed capability, with R12 attached: rewrite "
               "the edge path to the Files API path.",
        "words": ["rewrite", "path", "target", "endpoint", "uri", "url"],
    },
    "CREDENTIAL_INJECTION": {
        "for": "3.2's other half: inject the service principal token "
               "upstream without the producer ever holding it.",
        "words": ["header", "addheader", "authorization", "secret",
                  "property", "token"],
    },
    "REFUSAL_WITH_A_STATUS": {
        "for": "every refusal needs a status. PC-4 measured that "
               "resource-filtering cannot set one and that `mock` can "
               "but fails OPEN -- so a distinct, correct status per "
               "refusal (Task 2.11's Verify line) needs a policy that "
               "both refuses and chooses the code.",
        "words": ["status", "statuscode", "httpstatus", "errorstatus",
                  "responsestatus"],
    },
}

ALREADY_MEASURED = {
    "METHOD": {
        "for": "refusal 5 -- GET on an upload route, plus LIST and "
               "DELETE per 2.4.5.",
        "answer": "resource-filtering, whitelist[].methods",
        "evidence": ("T-07 probe U7, 2026-10-28: a GET to a POST-only "
                     "path was refused 405 in the policy's own voice. "
                     "Recorded in policy-classes.yaml PC-4 under "
                     "methods_field_constrains_MEASURED."),
        "so": "No calls spent re-asking it.",
    },
}


def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def find_catalogue(base_root, envbase, auth):
    """Same five candidates scripts/34 tries, in the order its evidence
    records as having worked. The URL is re-verified rather than taken
    from that record: a URL that answered once is not a URL that answers
    now, and the whole point of this file is to stop trusting memory."""
    candidates = [
        ("v2 org-scoped (worked 2026-10-27)",
         f"{base_root}/management/v2/organizations/DEFAULT/plugins/policies"),
        ("v2 env-scoped", f"{envbase}/plugins/policies"),
        ("v2 root", f"{base_root}/management/v2/plugins/policies"),
        ("v2 root, typed", f"{base_root}/management/v2/plugins?type=POLICY"),
        ("v1 env-scoped",
         f"{base_root}/management/organizations/DEFAULT"
         "/environments/DEFAULT/policies"),
    ]
    tried = []
    for label, url in candidates:
        st, body = get(url, auth)
        tried.append({"label": label, "url": url.replace(base_root, ""),
                      "status": st,
                      "body_head": (body or "")[:160] if st != 200 else None})
        print(f"  {label:<36} {str(st):<5} "
              f"{url.replace(base_root, '')}")
        if st == 200:
            try:
                doc = json.loads(body)
            except ValueError:
                continue
            items = doc if isinstance(doc, list) else (doc.get("data") or [])
            if items:
                return url, items, tried
    return None, [], tried


def describe(schema, path="", depth=0, out=None):
    """Flatten a JSON schema into (field path, type, default, enum, doc).

    Condensed rather than dumped: what class I needs is each field's
    name, its type, whether it has a default and what values it accepts.
    A raw schema dump of eight policies is unreadable and the detail
    that matters gets lost in it.
    """
    if out is None:
        out = []
    if not isinstance(schema, dict):
        return out
    props = schema.get("properties")
    if isinstance(props, dict):
        for name, spec in props.items():
            if not isinstance(spec, dict):
                continue
            here = f"{path}.{name}" if path else name
            row = {
                "field": here,
                "type": spec.get("type"),
                "default": spec.get("default"),
                "enum": spec.get("enum"),
                "title": spec.get("title"),
                "doc": (spec.get("description") or "")[:220] or None,
                "required": name in (schema.get("required") or []),
            }
            out.append(row)
            if spec.get("type") == "array" and isinstance(spec.get("items"), dict):
                describe(spec["items"], here + "[]", depth + 1, out)
            elif spec.get("type") == "object" or "properties" in spec:
                describe(spec, here, depth + 1, out)
    return out


def detail_mode(cat_url, auth, base_root, names):
    """Read a few policies' schemas in full and print what class I needs."""
    print("=" * 70)
    print("FULL SCHEMAS for the shortlisted policies")
    print("E2 Task 2.11 -- so class I is written against measured names")
    print("=" * 70)
    store = {}
    for pid in names:
        st, body = get(f"{cat_url}/{pid}/schema", auth)
        print(f"\n{'=' * 70}\n{pid}   (schema HTTP {st})\n{'=' * 70}")
        if st != 200 or not body:
            print("  CANNOT SEE -- no schema returned. Recorded, not "
                  "guessed around.")
            store[pid] = {"status": st, "schema": None}
            continue
        try:
            schema = json.loads(body)
        except ValueError:
            try:
                schema = json.loads(json.loads(body))
            except (ValueError, TypeError):
                print("  schema is not JSON; body head:")
                print("  " + (body or "")[:300])
                store[pid] = {"status": st, "schema_raw_head": body[:800]}
                continue
        store[pid] = {"status": st, "schema": schema}
        rows = describe(schema)
        if not rows:
            print("  no `properties` in the schema -- it declares no "
                  "configurable field.")
        for r in rows:
            bits = [r["type"] or "?"]
            if r["required"]:
                bits.append("REQUIRED")
            if r["default"] is not None:
                bits.append(f"default={r['default']!r}")
            if r["enum"]:
                bits.append(f"enum={r['enum']}")
            print(f"  {r['field']:<38} {' '.join(bits)}")
            if r["doc"]:
                print(f"      {r['doc']}")
    SCHEMA_EVIDENCE.parent.mkdir(exist_ok=True)
    SCHEMA_EVIDENCE.write_text(json.dumps(
        {"at": now(), "probe": "scripts/38 --detail",
         "catalogue_url": cat_url.replace(base_root, ""),
         "policies": store}, indent=2) + "\n")
    print(f"\nWrote evidence: {SCHEMA_EVIDENCE.relative_to(REPO)}")
    return 0


def main():
    load_env()
    base_root = require_env("GRAVITEE_MGMT_API_URL",
                            "the management API base").rstrip("/")
    # scripts/34's get() passes `auth` straight into
    # headers={"Authorization": auth}, so it wants a HEADER STRING and a
    # (user, password) tuple would be sent as its repr. Built the same
    # way scripts/34 builds it. Defaults match scripts/34's rather than
    # refusing, because the management credentials for this local
    # compose stack are admin/admin and scripts/34 already treats them
    # that way -- diverging here would make one of the two wrong.
    user = os.environ.get("GRAVITEE_MGMT_USER", "admin")
    password = os.environ.get("GRAVITEE_MGMT_PASSWORD", "admin")
    auth = "Basic " + b64encode(f"{user}:{password}".encode()).decode()
    envbase = (f"{base_root}/management/v2/organizations/DEFAULT"
               f"/environments/DEFAULT")

    print("=" * 70)
    print("Which installed policies can express the six T-24 refusals?")
    print("E2 Task 2.11 | T-24 | R12 | CONOPS 2.4.5, 3.2")
    print("=" * 70)
    print()
    print("locating the policy catalogue:")
    cat_url, items, tried = find_catalogue(base_root, envbase, auth)
    if cat_url and "--detail" in sys.argv:
        named = [a for a in sys.argv[1:] if not a.startswith("-")]
        return detail_mode(cat_url, auth, base_root, named or SHORTLIST)
    if not cat_url:
        print("\nVERDICT: CANNOT_SEE_POLICY_CATALOGUE_UNREACHABLE")
        print("  None of the five candidate paths returned a policy list. "
              "Recorded rather than guessed -- naming a policy without "
              "reading the catalogue is what this probe exists to avoid.")
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps(
            {"at": now(), "verdict": "CANNOT_SEE_POLICY_CATALOGUE_UNREACHABLE",
             "paths_tried": tried}, indent=2) + "\n")
        return 1

    ids = []
    for it in items:
        pid = it.get("id") or it.get("policy") or it.get("name")
        if pid:
            ids.append(str(pid))
    ids = sorted(set(ids))
    print(f"\n{len(ids)} policies installed.")

    print("\nreading each policy's own schema "
          "(this is the slow part -- one call per policy):")
    schemas, unreadable = {}, []
    for i, pid in enumerate(ids, 1):
        st, body = get(f"{cat_url}/{pid}/schema", auth)
        if st != 200 or not body:
            unreadable.append({"policy": pid, "status": st})
            continue
        try:
            schemas[pid] = json.loads(body)
        except ValueError:
            # Some installations return the schema as a JSON *string*.
            try:
                schemas[pid] = json.loads(json.loads(body))
            except (ValueError, TypeError):
                unreadable.append({"policy": pid, "status": st,
                                   "why": "schema is not JSON"})
        if i % 20 == 0:
            print(f"    {i}/{len(ids)} ...")
    print(f"    {len(schemas)} schema(s) read, "
          f"{len(unreadable)} unreadable")

    # ------------------------------------------------------------------
    print("\n" + "=" * 70)
    print("CANDIDATES PER CAPABILITY  (a declared field, not a behaviour)")
    print("=" * 70)
    results = {}
    for cap, spec in CAPABILITIES.items():
        hits = []
        for pid, schema in schemas.items():
            # walk_keys writes into a SET and already lowercases, so a
            # list here would die on .update and a second .lower() would
            # be redundant. Signature read, not assumed.
            keys = set()
            walk_keys(schema, keys)
            matched = sorted({k for k in keys
                              for w in spec["words"] if w in k})
            if matched:
                hits.append({"policy": pid, "fields": matched[:12]})
        # Fewest fields first: a policy whose schema is mostly about this
        # capability is a better candidate than one that mentions it in
        # passing among forty keys.
        hits.sort(key=lambda h: (len(h["fields"]), h["policy"]))
        results[cap] = {"for": spec["for"], "candidates": hits}
        print(f"\n{cap}  ({len(hits)} candidate(s))")
        print(f"  need: {spec['for']}")
        for h in hits[:6]:
            print(f"    {h['policy']:<34} {', '.join(h['fields'][:6])}")
        if not hits:
            print("    NO DEDICATED FIELD. Read this narrowly: it means "
                  "no schema NAMES a property for this, not that the "
                  "capability is absent. Gravitee policies accept "
                  "expression language inside generic value fields, so "
                  "e.g. {#request.params['overwrite']} can express a "
                  "query-parameter test through a field called `field` or "
                  "`condition`, which no keyword here would match. The "
                  "next step is to read one candidate's schema in full, "
                  "not to invoke §3.2's fallback.")

    print("\n" + "=" * 70)
    print("ALREADY MEASURED -- not re-asked")
    print("=" * 70)
    for cap, rec in ALREADY_MEASURED.items():
        print(f"  {cap}: {rec['answer']}")
        print(f"    {rec['evidence']}")

    missing = [c for c, r in results.items() if not r["candidates"]]
    if missing:
        verdict = "SOME_REFUSALS_HAVE_NO_CANDIDATE_POLICY"
        why = (f"No installed policy declares a field for: "
               f"{', '.join(missing)}. For SIZE_LIMIT in particular that "
               f"would be a finding and not a detail -- §2.4.5 says "
               f"Databricks caps nothing, so the gateway is the only cap "
               f"and there would be none. §3.2's fallback (a thin ingest "
               f"service in front of the Databricks API) becomes the "
               f"route, and R12 is realised rather than mitigated.")
    else:
        verdict = "EVERY_REFUSAL_HAS_AT_LEAST_ONE_CANDIDATE_POLICY"
        why = ("Each capability has a policy whose schema declares a "
               "field that could carry it. That is enough to WRITE class "
               "I against measured field names instead of remembered "
               "ones. It is not enough to claim the refusals work: a "
               "schema is not a behaviour, which is what scripts/34 "
               "learned when `mock` declared a status and a body and "
               "failed OPEN. T-24 measures behaviour on a real route.")

    out = {
        "at": now(),
        "probe": "scripts/38_probe_ingest_policies.py",
        "task": "E2 Task 2.11 / T-24 / R12",
        "catalogue_url": cat_url.replace(base_root, ""),
        "catalogue_paths_tried": tried,
        "policies_installed": len(ids),
        "policy_ids": ids,
        "schemas_read": len(schemas),
        "schemas_unreadable": unreadable,
        "capabilities": results,
        "already_measured": ALREADY_MEASURED,
        "verdict": verdict,
        "why": why,
        "limits_of_this_method": (
            "Field NAMES only. walk_keys collects property names under "
            "`properties`, so a capability reachable through Gravitee "
            "Expression Language in a generic field -- "
            "{#request.params['overwrite']} inside a rule's `field`, or a "
            "step's `condition` -- is invisible to a keyword search and "
            "will show as NO DEDICATED FIELD. That is a floor on what is "
            "possible, not a ceiling."),
        "design_tension_for_class_I": (
            "The overwrite refusal is conditional by nature: refuse PUT "
            "only when overwrite=true. The obvious implementation is a "
            "step `condition`, and AI-10 records what that costs -- a "
            "step condition that does not evaluate true causes Gravitee "
            "to OMIT the policy silently, with PUT 200 and deploy 202 and "
            "no warning. A conditional refusal therefore fails OPEN, "
            "which is the wrong direction for a refusal and the reason "
            "scripts/lib/terminal_allow_list.py carries 'No `condition` "
            "on this step, ever.' Class I should prefer a policy that "
            "reads the parameter in its OWN configuration over a step "
            "condition wrapped around an unconditional one, and T-24 must "
            "measure the overwrite refusal with a positive control -- an "
            "overwrite=false PUT that succeeds in the same run -- or a "
            "silently omitted policy reads as a passing test."),
        "what_this_does_not_prove": (
            "That any candidate ENFORCES what it declares. scripts/34 "
            "measured `mock` declaring a status and a body while failing "
            "OPEN, which on a catch-all would have been the whole "
            "perimeter forwarding every unlisted path. Candidates here "
            "are inputs to writing class I, and T-24 is what converts "
            "them into evidence -- on a real route, with a positive "
            "control on the same path (B-40)."),
        "conops_inputs": {
            "route_shape_decided_2026-10-29": (
                "One route per producer: PUT /push-ingest/<producer>/"
                "<path> rewritten to /api/2.0/fs/files/Volumes/<catalog>/"
                "<schema>/<volume>/<path>. Chosen because it mirrors the "
                "measured per-recipient egress family, and because a "
                "misconfigured rewrite then reaches one producer's volume "
                "rather than all of them. AHEAD OF DOCUMENT: §2.3.2 gives "
                "I-2 no route id, and channels.yaml records that absence "
                "rather than inventing one. v1.6 must give it an id."),
            "size_cap_owner": (
                "§2.4.5: 'Databricks documents no size cap for the REST "
                "call; the cap here is the gateway limit.' Whatever this "
                "probe finds for SIZE_LIMIT is therefore the only cap in "
                "the design, and v1.6 should say so explicitly."),
        },
    }
    EVIDENCE.parent.mkdir(exist_ok=True)
    EVIDENCE.write_text(json.dumps(out, indent=2) + "\n")
    print(f"\nWrote evidence: {EVIDENCE.relative_to(REPO)}")
    print()
    print("=" * 70)
    print(f"VERDICT: {verdict}")
    print("=" * 70)
    print(why)
    return 0


if __name__ == "__main__":
    sys.exit(main())
