#!/usr/bin/env python3
"""Build reports/2026-W43-weekly-report.docx.

The report exists as a SCRIPT rather than a hand-edited file for the same
reason every other artifact in this repository does: a document nobody can
regenerate is a document nobody can correct. Week 43's figures were revised
four times (357 -> 356 config checks, "600s" -> the measured 586.5s, 142 ->
143 archived files) and each revision had to land in five places. A builder
makes the figures single-origin.

Verify after running:
    soffice --headless --convert-to pdf --outdir /tmp reports/2026-W43-weekly-report.docx
    pdfinfo /tmp/2026-W43-weekly-report.pdf | grep Pages    # expect: 2
"""
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "reports" / "2026-W43-weekly-report.docx"

ACCENT = RGBColor(0x1F, 0x3B, 0x5C)
RED = RGBColor(0x9B, 0x22, 0x26)
MUTED = RGBColor(0x5A, 0x5A, 0x5A)
LABEL_FILL = "EEF2F7"
ALERT_FILL = "FBECEC"


def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    el = OxmlElement("w:shd")
    el.set(qn("w:val"), "clear")
    el.set(qn("w:fill"), fill)
    tcPr.append(el)


def fixed_grid(table, widths_in):
    """Word ignores cell widths unless the layout is fixed AND a tblGrid
    declares the columns. Inches() returns a Length whose .twips attribute is
    absent in this python-docx build, so twips are computed directly."""
    table.autofit = False
    tblPr = table._tbl.tblPr
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tblPr.append(layout)
    # add_table() ALREADY emits a tblGrid. Inserting a second one leaves the
    # file with two, and the renderer honours the first -- which is why an
    # earlier build clipped the right-hand column off the page instead of
    # wrapping it. Rewrite the existing grid in place.
    grid = table._tbl.find(qn("w:tblGrid"))
    if grid is None:
        grid = OxmlElement("w:tblGrid")
        table._tbl.insert(1, grid)
    for gc in list(grid):
        grid.remove(gc)
    for w in widths_in:
        gc = OxmlElement("w:gridCol")
        gc.set(qn("w:w"), str(int(w * 1440)))
        grid.append(gc)
    for row in table.rows:
        for cell, w in zip(row.cells, widths_in):
            cell.width = Inches(w)


def run(p, text, *, size=10, bold=False, italic=False, color=None):
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.italic = italic
    if color is not None:
        r.font.color.rgb = color
    return r


def para(doc, *, before=0, after=4, spacing=1.08, align=None):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.line_spacing = spacing
    if align is not None:
        pf.alignment = align
    return p


def heading(doc, text):
    p = para(doc, before=9, after=3)
    run(p, text, size=11.5, bold=True, color=ACCENT)
    return p


def body(doc, text, **kw):
    p = para(doc, **kw)
    run(p, text)
    return p


def bullet(doc, lead, rest):
    p = doc.add_paragraph(style="List Bullet")
    pf = p.paragraph_format
    pf.space_after = Pt(3)
    pf.line_spacing = 1.06
    run(p, lead, bold=True)
    run(p, " " + rest)
    return p


def kv_table(doc, rows, *, widths=(1.05, 5.7), red_labels=()):
    t = doc.add_table(rows=0, cols=2)
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.LEFT
    for label, value in rows:
        cells = t.add_row().cells
        shade(cells[0], LABEL_FILL)
        lp = cells[0].paragraphs[0]
        lp.paragraph_format.space_after = Pt(1)
        lp.paragraph_format.line_spacing = 1.0
        run(lp, label, size=9.5, bold=True,
            color=RED if label in red_labels else ACCENT)
        vp = cells[1].paragraphs[0]
        vp.paragraph_format.space_after = Pt(1)
        vp.paragraph_format.line_spacing = 1.03
        run(vp, value, size=9.5)
    fixed_grid(t, list(widths))
    return t


def build():
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Calibri"
    st.font.size = Pt(10)
    for s in doc.sections:
        s.top_margin = s.bottom_margin = Inches(0.7)
        s.left_margin = s.right_margin = Inches(0.85)

    # ---- title block ----
    p = para(doc, after=1)
    run(p, "Weekly Report \u2014 Week 43", size=19, bold=True, color=ACCENT)
    p = para(doc, after=1)
    run(p, "CONOPS AWOZ-1227 v1.5  \u00b7  OpenSharing + Gravitee API Gateway"
            "  \u00b7  INC17", size=10, color=MUTED)
    p = para(doc, after=8)
    run(p, "Week ending Friday 23 October 2026  \u00b7  Epic 1 (T04-10, AC1)"
            "  \u00b7  Prepared by the CONOPS owner", size=9, color=MUTED)

    # ---- action required: first thing on the page ----
    t = doc.add_table(rows=1, cols=1)
    t.style = "Table Grid"
    cell = t.rows[0].cells[0]
    shade(cell, ALERT_FILL)
    cp = cell.paragraphs[0]
    cp.paragraph_format.space_after = Pt(2)
    cp.paragraph_format.line_spacing = 1.04
    run(cp, "Action required \u2014 rotate three credentials. ", size=9.5,
        bold=True, color=RED)
    run(cp, "A tracked environment template was overwritten with live values "
            "on 22 Oct and sat that way for about a day: a Databricks personal "
            "access token, a second Databricks token, and a GitHub "
            "fine-grained token. It was never committed, so none of the three "
            "is in git history, and the repository is clean again \u2014 but "
            "the archive built earlier today carried the file before it was "
            "caught, so all three must be rotated regardless. Detail and the "
            "containment steps are in engineering note \u00a77.", size=9.5)
    fixed_grid(t, [6.75])
    para(doc, after=2)

    heading(doc, "The week in one paragraph")
    body(doc,
         "Epic 1 is closed \u2014 eleven of twelve tasks complete, with the "
         "twelfth deferred by instruction until the corporate 1694-G2 template "
         "arrives. Twelve tests now run where nine ran last week, and two of "
         "them fail. Those two failures are the most valuable thing the week "
         "produced: a narrowed entitlement did not reach the live consumer "
         "while every provider-side check reported the reduction in force. "
         "Rows taken out of scope stayed readable for as long as we watched. "
         "The CONOPS currently implies that editing a shared view revokes "
         "access; it does not, and v1.6 must say so.", after=5)

    heading(doc, "Status")
    kv_table(doc, [
        ("Tasks", "11 of 12 complete. Task 1.12 (ARB package) deferred "
                  "pending the 1694-G2 template."),
        ("Tests", "12 run \u2014 8 pass, 1 passes with a CANNOT_SEE "
                  "sub-check, 1 honestly partial, 2 fail."),
        ("Gates", "All green. Config consistency 356 checks / 0 failed; "
                  "secret hygiene clean. Pyflakes shows 14 cosmetic warnings "
                  "in files untouched this week \u2014 recorded, not claimed "
                  "clean."),
        ("Window", "1 Oct \u2013 29 Oct. Checkpoint 23 Oct."),
        ("Archive", "epic1.2.zip \u2014 both gates re-run from inside the "
                    "extraction after the template was restored."),
    ])

    heading(doc, "What moved")
    bullet(doc, "Change propagation measured, and it failed in both "
                "directions.",
           "Widening an entitlement and narrowing it are not the same "
           "experiment with the sign reversed. Narrowing is the "
           "security-relevant case and it is the one that failed: the "
           "provider-side row count fell from 16 to 8 while the consumer held "
           "16 across nineteen reads, the last at 586 seconds. That is a "
           "floor, not a limit \u2014 we know it had not arrived by then, not "
           "that it never would.")
    bullet(doc, "The internal egress channel now has a working control.",
           "The test checks its own probe before reporting a finding: a "
           "deliberate control grant makes the deny row read VIOLATED and name "
           "the principal, and revoking it returns the row to CLEAN. A deny "
           "row that has only ever read CLEAN is indistinguishable from one "
           "nothing is watching.")
    bullet(doc, "The credential time-box was discharged with 84 minutes to "
                "spare.",
           "Rotated, re-activated, and the perimeter tests re-run on the "
           "rotated credential \u2014 because a rotation that writes a file is "
           "not evidence the credential works.")
    bullet(doc, "The client verification session script was found broken and "
                "fixed.",
           "This is the script a client is walked through. It crashed on its "
           "first step, so six of seven steps produced no verdict at all. Two "
           "of its nine rows reported PASS while measuring nothing. It read 8 "
           "of 9 before; it now reads 6 of 9, and 6 is the first honest number "
           "it has produced.")

    heading(doc, "What leadership needs from this week")
    for lead, rest in [
        ("Five corrections to carry into CONOPS v1.6,",
         "set out in full in the decision note. The load-bearing one: strike "
         "any language implying that a view edit revokes access, and replace "
         "the revocation path with recipient-level revocation, which is "
         "measured and works."),
        ("One disclosure for the ARB front page.",
         "The gateway can inject an upstream credential \u2014 confirmed. "
         "Doing so without a long-lived secret is unbuilt. Both halves belong "
         "in the package; only the first is currently claimed."),
        ("Two decisions that are not ours to make",
         "remain open and block nothing this week: the token-policy decision "
         "(OD-5) and the 1694-G2 template that gates the ARB package."),
        ("Accept the closure record",
         "as the artifact the 23 Oct checkpoint reviews. The checkpoint asks "
         "for a review-ready package; the package is deferred on purpose, and "
         "the closure record plus the evidence directory covers the same "
         "ground with every AC1 clause traced to a verdict or a named gap."),
    ]:
        p = para(doc, after=3, spacing=1.06)
        run(p, lead, bold=True)
        run(p, " " + rest)

    heading(doc, "Carried into next week")
    kv_table(doc, [
        ("Open red", "Change propagation. No propagation mechanism is "
                     "specified and none was observed. E2 owns the fix; v1.6 "
                     "owes the corrected language."),
        ("Open red", "Credential endpoint. The credential rewriter still emits "
                     "a retired gateway path. Now a measured failing row "
                     "rather than a passing one. E2 Task 2.1 consolidates it."),
        ("Watch", "A status-code health check reports a broken MCP service as "
                  "healthy \u2014 the route answers HTTP 200 carrying an "
                  "error. Monitoring, not this epic, and nothing here would "
                  "have caught it."),
        ("Watch", "Rotation overlap is refused in a token's final 24 hours, "
                  "exactly when rotation is most urgent. Workaround "
                  "documented; policy decision needed."),
        ("Next", "E2 picks up the gateway-enforced controls and the "
                 "propagation mechanism. Task 1.12 resumes the day the "
                 "template lands."),
    ], red_labels=("Open red",))

    heading(doc, "One sentence worth keeping")
    p = para(doc, after=3)
    run(p, "A perimeter test that never observes the perimeter absent is "
           "measuring the wrong thing.", italic=True, color=ACCENT)
    body(doc,
         "Every control in Epic 1 now has a run in which it was switched off "
         "and seen to stop working. That is what makes this evidence worth "
         "taking to the ARB \u2014 and it is why the test count went up and "
         "the pass rate went down in the same week.", after=8)

    p = para(doc, after=0, align=WD_ALIGN_PARAGRAPH.LEFT)
    run(p, "Supporting detail: docs/leadership/ (three-note pack) \u00b7 "
           "docs/epics/E1-closure-record.md \u00b7 evidence/ \u00b7 archive "
           "epic1.2.zip", size=8.5, color=MUTED)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)
    print(f"wrote {OUT}")


if __name__ == "__main__":
    build()
