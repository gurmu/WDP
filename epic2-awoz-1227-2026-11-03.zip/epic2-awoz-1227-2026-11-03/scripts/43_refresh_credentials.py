#!/usr/bin/env python3
"""Rotate and re-activate every declared recipient credential. One command.

docs/15 Part B, item P-4 | mitigates A-9 | RKI-5

WHY THIS EXISTS
---------------
A recipient token configured for 7 days expires 24 HOURS after activation
(`LIFETIME_DIFFERS_SET_AT_BIRTH`, measured on three recipients for
three). So every working session starts by refreshing credentials, and
until now that meant three commands per recipient with a file move in
the middle:

    python3 scripts/27_build_recipient_model.py --rotate-token NAME \\
        --rotate-overlap-seconds 0
    mv _secrets/credential-NAME.json _secrets/credential-NAME.json.pre-...
    python3 scripts/28_activate_credential.py --recipient NAME --activate

Nine commands for three recipients, with an irreversible one in the
middle and a hand-typed date in the archive name. It has already gone
wrong in the way that matters: a stale credential file on disk was read
as LIVE, T-05 ran against an expired token, and the failure looked like
a gateway finding for long enough to be written down. That is the whole
argument for this script -- not convenience, but that the manual
sequence has a silent failure mode and this one does not.

WHAT IT WILL NOT DO
-------------------
- It never prints a token. Only the sha12 prefix that scripts/28 prints,
  and the expiry. CONOPS 5.1: metadata, never values.
- It never deletes a credential file. The existing one is archived with
  a UTC timestamp, so a rotation that goes wrong leaves the previous
  file recoverable even though its token is already superseded.
- It never reports success on the strength of an exit code. After the
  pair has run it RE-READS each credential file off disk and reports the
  expiry it finds there. A rotation that writes a file is not evidence
  that the credential works -- that lesson cost a day in Epic 1 and the
  same reasoning is why this script's last act is a read, not a claim.
- Activation is single-use and irreversible, so --dry-run is the
  default-adjacent habit: run it first if the state on disk is unclear.

Run:
    python3 scripts/43_refresh_credentials.py --dry-run
    python3 scripts/43_refresh_credentials.py --all
    python3 scripts/43_refresh_credentials.py --recipient psp7-demo-recipient
    python3 scripts/43_refresh_credentials.py --status    # read only, no change
"""

import argparse
import importlib.util
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
SECRETS = ROOT / "_secrets"
RECIPIENTS_YAML = ROOT / "iac" / "config" / "recipients.yaml"
S27 = ROOT / "scripts" / "27_build_recipient_model.py"
S28 = ROOT / "scripts" / "28_activate_credential.py"
HYGIENE = ROOT / "scripts" / "check_secret_hygiene.py"

MARGIN_HOURS = 2.0  # below this, treat a live credential as needing refresh


# ---------------------------------------------------------------------------
# Expiry reading. Prefer scripts/28's own helper so there is ONE definition
# of "live" in the repository; fall back to the profile field, and say in
# the output which path was taken rather than leaving it ambiguous.
# ---------------------------------------------------------------------------
def load_s28():
    if not S28.is_file():
        return None
    try:
        spec = importlib.util.spec_from_file_location("_s28", S28)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod if hasattr(mod, "credential_expiry_state") else None
    except Exception:
        return None


def parse_iso(v):
    if not isinstance(v, str) or not v:
        return None
    try:
        return datetime.fromisoformat(v.replace("Z", "+00:00"))
    except ValueError:
        return None


def expiry_of(path: Path, s28):
    """(state, expiry-or-None, how). Never returns the token."""
    if not path.is_file():
        return "NO_CREDENTIAL_FILE", None, "file absent"
    if s28 is not None:
        try:
            state = s28.credential_expiry_state(path)
            if isinstance(state, tuple):
                st, exp = state[0], state[1] if len(state) > 1 else None
            else:
                st, exp = state, None
            exp = parse_iso(exp) if isinstance(exp, str) else exp
            if exp is None:
                exp = parse_iso(
                    (json.loads(path.read_text()) or {}).get("expirationTime"))
            return str(st), exp, "scripts/28.credential_expiry_state"
        except Exception:
            pass  # fall through to the profile field
    try:
        doc = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError) as exc:
        return "UNREADABLE", None, f"{type(exc).__name__}"
    exp = parse_iso(doc.get("expirationTime"))
    if exp is None:
        return "EXPIRY_UNKNOWN", None, "no expirationTime field"
    now = datetime.now(timezone.utc)
    return ("LIVE" if exp > now else "EXPIRED"), exp, "expirationTime field"


def hours_left(exp):
    if exp is None:
        return None
    return (exp - datetime.now(timezone.utc)).total_seconds() / 3600.0


# ---------------------------------------------------------------------------
def declared_recipients():
    if not RECIPIENTS_YAML.is_file():
        return [], f"{RECIPIENTS_YAML.relative_to(ROOT)} is missing"
    doc = yaml.safe_load(RECIPIENTS_YAML.read_text()) or {}
    node = doc.get("recipients", doc)
    names = []
    if isinstance(node, dict):
        for k, v in node.items():
            names.append(v.get("name", k) if isinstance(v, dict) else k)
    elif isinstance(node, list):
        for v in node:
            if isinstance(v, dict):
                n = v.get("name") or v.get("id")
                if n:
                    names.append(n)
            elif isinstance(v, str):
                names.append(v)
    out, seen = [], set()
    for n in names:
        if isinstance(n, str) and n not in seen:
            seen.add(n)
            out.append(n)
    return out, None if out else "no recipients found in the config"


def cred_path(name):
    return SECRETS / f"credential-{name}.json"


def pending_link_state(name):
    """Is there an unspent activation link, and is the token behind it
    still alive? Returns (state, expiry-or-None).

    MEASURED 2026-11-02, and it corrects what this repository had
    recorded. Three activation links were written on 10-30 at 21:04Z and
    exchanged for the first time on 11-02. All three were refused with
    404 `RECIPIENT_DOES_NOT_EXIST` -- "activation nonce not found" --
    and the token records show `expiration_time` exactly 24h after
    `created_at`, with the link never consumed.

    So the 24-hour clock starts at token CREATION, not at activation.
    The two were indistinguishable before, because every earlier
    rotation was activated minutes later. They are distinguishable now:
    an unactivated token dies on the same schedule as an activated one.

    The operational consequence is sharper than the one on record. A
    rotation that is not activated the same day is not a pending
    activation -- it is a wasted token, and --activate-only cannot
    recover it. Only a fresh rotation can. This function exists so the
    script says that BEFORE it moves any file, rather than discovering
    it afterwards.

    Nothing here is printed: the link itself never leaves this function.
    """
    candidates = [SECRETS / f"recipient-{name}-rotated.json",
                  SECRETS / f"recipient-{name}.json"]
    newest, unspent = None, False
    for f in candidates:
        if not f.is_file():
            continue
        try:
            doc = json.loads(f.read_text())
        except (json.JSONDecodeError, OSError):
            continue
        toks = doc.get("tokens") or doc.get("token") or []
        if isinstance(toks, dict):
            toks = [toks]
        for t in toks:
            if not isinstance(t, dict):
                continue
            url = str(t.get("activation_url") or "")
            exp = t.get("expiration_time")
            exp = (datetime.fromtimestamp(exp / 1000, timezone.utc)
                   if isinstance(exp, (int, float)) and exp else None)
            spent = (not url) or url.startswith("<")
            if newest is None or (exp and newest[1] and exp > newest[1]):
                newest, unspent = (t, exp), not spent
            elif not spent and not unspent:
                newest, unspent = (t, exp), True
    if newest is None:
        return "NO_RECORD_ON_DISK", None
    exp = newest[1]
    if not unspent:
        return "LINK_ALREADY_SPENT", exp
    if exp is None:
        return "LINK_UNSPENT_EXPIRY_UNKNOWN", None
    if exp <= datetime.now(timezone.utc):
        return "LINK_UNSPENT_BUT_TOKEN_EXPIRED", exp
    return "LINK_UNSPENT_AND_TOKEN_LIVE", exp


def run(cmd, dry, marker=None):
    """Run a step and judge it by its OWN VERDICT, not by its exit code.

    FIXED 2026-10-30, after this script damaged the environment it was
    written to protect. scripts/27 ends with

        sys.exit(0 if res["verdict"] == "RECIPIENT_MODEL_VERIFIED_PROVIDER_SIDE"
                 ...)

    and this metastore carries unmanaged dormant recipients, so its
    verdict is MODEL_VERIFIED_PROVIDER_SIDE_ENVIRONMENT_NOT_CLEAN and it
    exits NON-ZERO on a completely successful rotation. That is a
    statement about the environment, not about the rotation.

    This function read the exit code and reported ROTATE FAILED for all
    three recipients. The rotations had in fact succeeded -- and because
    --rotate-overlap-seconds 0 revokes the previous token immediately,
    the one credential that had been live was revoked and then, because
    the script believed the step had failed, never activated. T-01 went
    from 1-of-4 to 0-of-4 and T-07 lost its last live credential.

    The irony is exact and worth leaving in the file: this script's own
    docstring says it never reports SUCCESS on the strength of an exit
    code, and it then reported FAILURE on the strength of one. An exit
    code is a summary written by someone else for their own purpose. Ask
    the step what it did; it says so in its output.
    """
    printable = " ".join(str(c) for c in cmd)
    if dry:
        print(f"      would run: {printable}")
        return True, "(dry run)"
    proc = subprocess.run([sys.executable, *cmd], cwd=ROOT,
                          capture_output=True, text=True)
    out = proc.stdout or ""
    lines = out.strip().splitlines()
    # The last three lines are whatever the step printed last, which for
    # these steps is a "now run..." hint rather than the outcome. Prefer
    # the lines that carry a verdict; fall back to the tail.
    carriers = [l.strip() for l in lines
                if "verdict" in l.lower() or "VERDICT" in l
                or "error_code" in l or "status" in l.lower()]
    detail = "\n      ".join(carriers[-4:]) if carriers else (
        "\n      ".join(lines[-3:]) if lines
        else (proc.stderr or "").strip()[-300:])
    if marker is not None:
        ok = marker in out
        if not ok and proc.returncode == 0:
            detail = (f"exit 0 but the verdict marker {marker!r} is absent "
                      f"from the output -- treating as not done.\n" + detail)
        elif ok and proc.returncode != 0:
            detail = (f"{marker} (exit {proc.returncode}, which for this "
                      f"step reports the ENVIRONMENT, not the step)\n" + detail)
        return ok, detail
    return proc.returncode == 0, detail


def report_table(rows, s28_used):
    print("-- credential state (read from disk, not from an exit code) ----")
    for name, state, exp, how in rows:
        h = hours_left(exp)
        when = exp.isoformat().replace("+00:00", "Z") if exp else "-"
        left = f"{h:6.1f}h left" if h is not None else "   unknown "
        flag = ""
        if state == "LIVE" and h is not None and h < MARGIN_HOURS:
            flag = "  <-- under the margin; refresh before testing"
        print(f"  {name:<34} {state:<22} {left}  {when}{flag}")
    print(f"  expiry read via: {s28_used}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--recipient", action="append", default=[],
                    help="refresh one recipient; repeatable")
    ap.add_argument("--all", action="store_true",
                    help="refresh every recipient declared in recipients.yaml")
    ap.add_argument("--status", action="store_true",
                    help="read and report expiries; change nothing")
    ap.add_argument("--dry-run", action="store_true",
                    help="print the commands without running them")
    ap.add_argument("--activate-only", action="store_true",
                    help="skip rotation; archive the stale credential and "
                         "activate the link a previous rotation already "
                         "wrote. The recovery path when a rotation succeeded "
                         "but its activation did not run.")
    ap.add_argument("--skip-live", action="store_true",
                    help=f"leave alone any credential with more than "
                         f"{MARGIN_HOURS}h left")
    args = ap.parse_args()

    s28 = load_s28()
    s28_used = ("scripts/28's own credential_expiry_state"
                if s28 else "this script's fallback (profile expirationTime)")

    print("=" * 70)
    print("Credential refresh -- docs/15 P-4, mitigating A-9")
    print("=" * 70)
    print(f"  repo:   {ROOT}")
    mode = ("STATUS" if args.status
            else "DRY RUN" if args.dry_run
            else "APPLY (activate only)" if args.activate_only
            else "APPLY")
    print(f"  mode:   {mode}")
    print()

    declared, why = declared_recipients()
    if why:
        print(f"  REFUSED: {why}")
        print("  Nothing was changed. This script will not guess a recipient")
        print("  name: rotating the wrong recipient is irreversible.")
        return 1

    targets = args.recipient or (declared if (args.all or args.status) else [])
    if not targets:
        print("  Declared recipients:")
        for n in declared:
            print(f"    {n}")
        print()
        rows = [(n, *expiry_of(cred_path(n), s28)) for n in declared]
        report_table(rows, s28_used)
        print()
        print("  Pass --all to refresh every one, or --recipient NAME for one.")
        print("  Activation is single-use and irreversible, so no default.")
        return 0

    unknown = [t for t in targets if t not in declared]
    if unknown:
        print(f"  REFUSED: not declared in recipients.yaml: {unknown}")
        print(f"  Declared: {declared}")
        return 1

    before = [(n, *expiry_of(cred_path(n), s28)) for n in targets]
    report_table(before, s28_used)
    print()

    if args.status:
        print("=" * 70)
        print("VERDICT: STATUS_ONLY_NOTHING_CHANGED")
        print("=" * 70)
        return 0

    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H%M%SZ")
    if args.activate_only:
        print("  NOTE: --activate-only. No token is rotated. scripts/28 "
              "consumes the activation link a previous rotation already "
              "wrote; the stale credential is set aside only once the new "
              "one is written.")
        print()
        print("-- pending activation links ------------------------------------")
        dead = []
        for name in targets:
            st, exp = pending_link_state(name)
            when = exp.isoformat().replace("+00:00", "Z") if exp else "-"
            print(f"  {name:<34} {st:<32} token expiry {when}")
            if st != "LINK_UNSPENT_AND_TOKEN_LIVE":
                dead.append((name, st))
        print()
        if dead:
            print("  REFUSED -- nothing was moved or consumed.")
            for name, st in dead:
                print(f"    {name}: {st}")
            print()
            print("  A link whose token has already expired cannot be")
            print("  exchanged: the platform answers 404 'activation nonce")
            print("  not found'. The 24h clock runs from token CREATION, so a")
            print("  rotation left unactivated overnight is a spent rotation,")
            print("  not a pending one.")
            print()
            print("  Recover with a FRESH rotate-and-activate in one pass:")
            print("      python3 scripts/43_refresh_credentials.py --all")
            print("=" * 70)
            print("VERDICT: NO_EXCHANGEABLE_LINK_NOTHING_CHANGED")
            print("=" * 70)
            return 1
    print("-- refreshing --------------------------------------------------")
    results = []
    for name, state, exp, _how in before:
        h = hours_left(exp)
        if (args.skip_live and not args.activate_only and state == "LIVE"
                and h is not None and h >= MARGIN_HOURS):
            print(f"  {name}: SKIPPED ({h:.1f}h left, --skip-live)")
            results.append((name, "SKIPPED_STILL_LIVE"))
            continue

        print(f"  {name}:")
        if args.activate_only:
            print("      rotation skipped (--activate-only): activating the "
                  "link an earlier rotation already wrote")
        else:
            ok, tail = run([S27, "--rotate-token", name,
                            "--rotate-overlap-seconds", "0"], args.dry_run,
                           marker="ROTATED")
            if not ok:
                print("      ROTATE DID NOT HAPPEN -- stopping before "
                      "activation.")
                print(f"      {tail}")
                results.append((name, "ROTATE_FAILED"))
                continue
            print("      would rotate" if args.dry_run else "      rotated")

        # The stale credential is moved ASIDE, not away, and only for as
        # long as the activation takes.
        #
        # FIXED 2026-11-02. This used to archive the file and then
        # activate. When activation failed -- which it did, for all three
        # recipients at once -- the archive had already happened and the
        # environment was left with NO credential files at all. A failure
        # path must not be more destructive than the success path. The
        # files were recoverable from the archives, so nothing was lost;
        # the principle was.
        cp = cred_path(name)
        archived = None
        if cp.is_file():
            archived = cp.with_name(cp.name + f".pre-rotation-{stamp}")
            if args.dry_run:
                print(f"      would set aside {cp.name} -> {archived.name}")
            else:
                shutil.move(str(cp), str(archived))
                archived.chmod(0o600)

        ok, tail = run([S28, "--recipient", name, "--activate"], args.dry_run,
                       marker="ACTIVATED_CREDENTIAL_WRITTEN")
        if not ok:
            print("      ACTIVATE DID NOT HAPPEN")
            print(f"      {tail}")
            if archived is not None and archived.is_file() and not cp.is_file():
                shutil.move(str(archived), str(cp))
                cp.chmod(0o600)
                print(f"      restored     {cp.name} (activation failed, so "
                      f"the previous file is put back)")
            results.append((name, "ACTIVATE_FAILED"))
            continue
        if archived is not None and not args.dry_run:
            print(f"      archived     {cp.name} -> {archived.name}")
        print("      would activate" if args.dry_run else "      activated")
        results.append((name, "WOULD_REFRESH" if args.dry_run else "REFRESHED"))
    print()

    # The last act is a READ. A rotation that writes a file is not evidence
    # that the credential works.
    after = [(n, *expiry_of(cred_path(n), s28)) for n in targets]
    report_table(after, s28_used)
    print()

    live = [n for n, st, exp, _ in after
            if st == "LIVE" and (hours_left(exp) or 0) >= MARGIN_HOURS]
    failed = [n for n, r in results if r.endswith("FAILED")]

    if not args.dry_run and HYGIENE.is_file():
        ok, tail = run([HYGIENE], False)
        print(f"-- secret hygiene gate: {'PASS' if ok else 'FAIL'}")
        if not ok:
            print(f"  {tail}")
            failed.append("secret-hygiene")
        print()

    print("=" * 70)
    if args.dry_run:
        verdict = "DRY_RUN_NOTHING_CHANGED"
    elif failed:
        verdict = "REFRESH_INCOMPLETE"
    elif len(live) == len(targets):
        verdict = "ALL_TARGETED_RECIPIENTS_HOLD_A_LIVE_CREDENTIAL"
    else:
        verdict = "REFRESH_RAN_BUT_NOT_EVERY_CREDENTIAL_READS_LIVE"
    print(f"VERDICT: {verdict}")
    print("=" * 70)
    for n, r in results:
        print(f"  {n:<34} {r}")
    if failed:
        print()
        print("  Something did not complete. Do NOT re-run blindly:")
        print("  activation is single-use, so re-running can consume a second")
        print("  activation link. Read the state above first, then target the")
        print("  one recipient that needs it with --recipient.")
    elif not args.dry_run and verdict.startswith("ALL_"):
        print()
        print(f"  Credentials are live for about "
              f"{min((hours_left(e) or 0) for _n, _s, e, _h in after):.0f}h.")
        print("  That is the 24h lifetime, not the 7d configured (A-9).")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
