#!/usr/bin/env python3
"""E2 Task 2.3 / PC-2: settle S10's path by asking the server.

CONOPS §2.3.2 gives route S10 as "POST /temporary-table-credentials" with
the note "Exact path confirmed against the API reference in the test".
iac/config/route-table.yaml carries the candidate expansion

    /shares/{share}/schemas/{schema}/tables/{table}/temporary-table-credentials

flagged `protocol_path_unconfirmed: true`. This probe settles it, and it
probes rather than reads documentation for a reason this repository has
now paid for twice: B-1 was an API definition built against an assumed
Databricks URL instead of the issued one, and the M2 path shape in
§2.3.2 turned out to be wrong in a way only the server's own error
revealed. An untested path is not a confirmed path.

WHAT THE DOCUMENTATION SAYS, AND WHY IT IS NOT THE ANSWER ON ITS OWN
--------------------------------------------------------------------
The only `temporary-table-credentials` endpoint in current Databricks
documentation is

    POST <workspace-host>/api/2.1/unity-catalog/temporary-table-credentials

with `table_id` and `operation` in the body. That is Unity Catalog
credential vending for external engines. It is:

  - on the WORKSPACE host, not the sharing host, and §2.3.2 targets S10
    at `sharing_endpoint`;
  - FLAT, not nested under /shares/{share}/schemas/{schema}/tables/{t};
  - under /api/2.1/unity-catalog/, a different API surface entirely.

So either the open sharing protocol exposes a credential-vending path
this probe will find, or S10 as written conflates UC credential vending
with the sharing protocol -- in which case S10 is not an S-class sharing
route at all. It would belong with A1 ("other Databricks REST APIs, not
exposed by default; added only by change request, each with its own
route, schema and limit"), on a different host, with a different policy
class and a different upstream identity.

That second outcome is the more consequential one and it is a v1.6
change to §2.3.2, not a config edit. Hence a probe that reports which,
rather than a generator that picks one.

HOW A PATH IS JUDGED TO EXIST
-----------------------------
Status codes, read carefully:

  404  the path is not there. On this server a 404 carries the protocol
       error envelope, so it is a real answer rather than a proxy's.
  405  the path exists; the METHOD is wrong. Still proof of existence.
  400  the path exists and parsed the request far enough to object to
       the body. Strong proof -- an endpoint that is absent never reads
       a body.
  401  the path exists and the credential was refused.
  200  the path exists and answered.

THE POSITIVE CONTROL IS NOT OPTIONAL
------------------------------------
Every candidate returning 404 is also what a malformed probe, a dead
credential, an expired token and a wrong host produce. So this probe
first calls a path KNOWN to exist -- the table query route, which T-01
exercises -- with the same credential, in the same run, against the same
host. If that control does not answer, no verdict is reported about any
candidate. B-40: the control must be the same path as the subject.
"""
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
SECRETS = REPO / "_secrets"
EVIDENCE = REPO / "evidence" / "s10-path-probe.json"

# Candidates, each with where it came from. Provenance is recorded
# because "we tried four paths" is a weaker fact than "we tried the one
# the config declares, the one the document abbreviates, and the two
# plausible protocol spellings".
CANDIDATES = [
    ("/shares/{share}/schemas/{schema}/tables/{table}/temporary-table-credentials",
     "iac/config/route-table.yaml S10.protocol_path (the flagged candidate)"),
    ("/shares/{share}/schemas/{schema}/tables/{table}/credentials",
     "plausible protocol spelling, shorter noun"),
    ("/temporary-table-credentials",
     "CONOPS 2.3.2's literal abbreviation, taken flat"),
    ("/shares/{share}/schemas/{schema}/tables/{table}/temporaryTableCredentials",
     "plausible protocol spelling, camelCase"),
]

CONTROL = ("/shares/{share}/schemas/{schema}/tables/{table}/query",
           "T-01 exercises this route and it answers 200 -- the positive control")


def load_profiles(only=None):
    """Every activated recipient credential on disk, newest file last.

    This returns a LIST rather than a preferred one, because on
    2026-10-27 the preferred one was dead. psp7-demo-recipient carries a
    24-hour token window set at birth (the closure record records it as
    LIFETIME_DIFFERS_SET_AT_BIRTH, 24h against a configured 7d), so a
    credential activated to re-baseline T-01 on one day is refused the
    next. The probe reported `GET /shares returned 401` and stopped,
    which was the correct refusal and the wrong selection: another live
    credential was sitting in the same directory.

    A probe that picks a credential by NAME is asserting something it has
    not checked. Picking by "answers 200" checks it."""
    out = []
    for f in sorted(SECRETS.glob("credential-*.json")):
        if ".pre-rotation-" in f.name:
            continue
        if only and only not in f.name:
            continue
        try:
            doc = json.loads(f.read_text())
        except ValueError:
            continue
        if doc.get("endpoint") and doc.get("bearerToken"):
            out.append((f.name, doc["endpoint"].rstrip("/"),
                        doc["bearerToken"]))
    if not out:
        sys.exit(
            "No activated recipient credential found in _secrets/.\n"
            "  Run scripts/28_activate_credential.py --recipient <name> "
            "--activate first."
        )
    return out


def pick_live_profile(profiles):
    """The first credential whose GET /shares returns 200, with every
    rejection named rather than passed over."""
    tried = []
    for name, endpoint, token in profiles:
        status, _ = call(endpoint, token, "/shares", "GET", timeout=30)
        tried.append({"credential": name, "shares_status": status})
        label = {200: "LIVE", 401: "REFUSED (expired or revoked)",
                 403: "REFUSED (address not allow-listed)"}.get(
                     status, f"status {status}")
        print(f"  {name:<58} {label}")
        if status == 200:
            return (name, endpoint, token), tried
    return None, tried


def call(endpoint, token, path, method, body=None, timeout=60):
    """One request. Redirects are NOT followed: scripts/32 recorded that
    urllib follows them by default, so a 200 can describe a different URL
    than the one asked about -- which here would turn 'this path does not
    exist' into 'this path works'."""

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *_a, **_k):
            return None

    data = json.dumps(body or {}).encode() if method == "POST" else None
    req = urllib.request.Request(
        endpoint + path,
        data=data,
        method=method,
        headers={
            "Authorization": "Bearer " + token,
            **({"Content-Type": "application/json"} if data else {}),
        },
    )
    opener = urllib.request.build_opener(NoRedirect)
    try:
        with opener.open(req, timeout=timeout) as resp:
            return resp.status, resp.read().decode(errors="replace")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode(errors="replace")
    except Exception as exc:  # noqa: BLE001
        return None, repr(exc)


def parse_json(body, what):
    """Parse a response body, or say why not -- never raise.

    The first version of this probe read only the first 400 bytes of
    every response, because the evidence record wants a short body head.
    Discovery then parsed that truncated text and died on a JSONDecodeError
    at char 400, which names the character offset and nothing about the
    cause. A truncation added for display had silently broken a parse --
    the same shape as B-47 (a value added so a local run would pass,
    disabling the thing it was meant to observe), arrived at from the
    opposite direction.

    So the body is now read in full and truncated only where it is
    RECORDED, and a body that is not JSON returns a stated reason rather
    than a stack trace. A probe whose failure mode is a traceback tells
    you less than one that says which call returned what."""
    try:
        return json.loads(body or "{}"), None
    except ValueError as exc:
        head = (body or "")[:200].replace("\n", " ")
        return None, f"{what} did not return JSON ({exc}); body head: {head!r}"


def classify(status):
    if status is None:
        return "UNREACHABLE"
    if status == 404:
        return "ABSENT"
    if status in (400, 401, 403, 405, 422):
        return "EXISTS_REFUSED_OR_REJECTED"
    if 200 <= status < 300:
        return "EXISTS_AND_ANSWERED"
    return f"UNCLASSIFIED_{status}"


def discover(endpoint, token):
    """Walk /shares -> /schemas -> /tables for one real triple. Nothing is
    assumed about the names: a path built from a guessed share name would
    404 for the share, not for the candidate, and the two are
    indistinguishable in the result."""
    status, body = call(endpoint, token, "/shares", "GET")
    if status != 200:
        return None, f"GET /shares returned {status}"
    doc, err = parse_json(body, "GET /shares")
    if err:
        return None, err
    for sh in doc.get("items") or []:
        s = sh.get("name")
        st, b = call(endpoint, token, f"/shares/{s}/schemas", "GET")
        if st != 200:
            continue
        sdoc, err = parse_json(b, f"GET /shares/{s}/schemas")
        if err:
            return None, err
        for sc in sdoc.get("items") or []:
            scn = sc.get("name")
            st2, b2 = call(endpoint, token,
                           f"/shares/{s}/schemas/{scn}/tables", "GET")
            if st2 != 200:
                continue
            tdoc, err = parse_json(
                b2, f"GET /shares/{s}/schemas/{scn}/tables")
            if err:
                return None, err
            for tb in tdoc.get("items") or []:
                return (s, scn, tb.get("name")), None
    return None, "no share/schema/table triple discoverable"


def main():
    only = None
    if "--recipient" in sys.argv:
        only = sys.argv[sys.argv.index("--recipient") + 1]
    print("=" * 68)
    print("S10 path probe -- E2 Task 2.3 / PC-2")
    print("=" * 68)
    print("selecting a live credential:")
    live, tried = pick_live_profile(load_profiles(only))
    if live is None:
        record = {
            "task": "E2 Task 2.3 / PC-2",
            "verdict": "CANNOT_SEE_NO_LIVE_CREDENTIAL",
            "credentials_tried": tried,
            "what_this_does_not_prove": (
                "Nothing about any path. Every credential on disk was "
                "refused by the sharing endpoint, so a 404 on a candidate "
                "would be the credential and not the route."),
            "remedy": (
                "python3 scripts/27_build_recipient_model.py "
                "--rotate-token <name> --rotate-overlap-seconds 3600 && "
                "python3 scripts/28_activate_credential.py --recipient "
                "<name> --activate --also-rewrite --force"),
        }
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps(record, indent=2) + "\n")
        print("\nVERDICT: CANNOT_SEE_NO_LIVE_CREDENTIAL")
        print("Every credential in _secrets/ was refused. Rotate one:")
        print("  python3 scripts/27_build_recipient_model.py \\")
        print("      --rotate-token <name> --rotate-overlap-seconds 3600")
        print("  python3 scripts/28_activate_credential.py \\")
        print("      --recipient <name> --activate --also-rewrite --force")
        return 1
    name, endpoint, token = live
    print(f"\ncredential: {name}")
    print(f"endpoint:   {endpoint}\n")

    triple, err = discover(endpoint, token)
    if not triple:
        sys.exit(f"Discovery failed: {err}. Cannot probe without a real "
                 "share/schema/table -- a guessed name would 404 for the "
                 "name rather than for the candidate path.")
    share, schema, table = triple
    print(f"discovered: {share}.{schema}.{table}\n")

    fill = lambda p: p.format(share=share, schema=schema, table=table)  # noqa: E731

    # --- controls, in two tiers ---------------------------------------
    #
    # The first version of this probe had ONE control -- the query route --
    # and refused to report anything when it did not answer. On the
    # 2026-10-27 run that threw away four real 404s because the slowest
    # route on the endpoint timed out, which is a verdict vocabulary too
    # coarse for what was actually observed (B-46, in the direction of
    # discarding evidence rather than overstating it).
    #
    # There are two separable questions, and only the first one gates a
    # verdict about a path:
    #
    #   GET control  -- is this the right host, with a live credential,
    #                   answering this protocol at all? Discovery already
    #                   settled that: three successive GETs returned 200
    #                   and yielded a real share/schema/table triple. If
    #                   that had failed we would not be here.
    #   POST control -- does this endpoint handle POST on a path we know
    #                   exists? A refinement. Without it, a 404 is still a
    #                   404 -- a server that 404s every POST would have to
    #                   404 the query route too, and that is exactly what
    #                   this control checks when it can run.
    #
    # So a failed POST control downgrades the verdict's confidence and is
    # recorded; it no longer erases the measurement.
    get_control = {
        "how": "discovery walked /shares -> /schemas -> /tables, 200 each",
        "result": "PASSED",
        "proves": "right host, live credential, server speaks this protocol",
    }
    cpath, cwhy = CONTROL
    cstatus, cbody = call(endpoint, token, fill(cpath), "POST",
                          {"limitHint": 1})
    cclass = classify(cstatus)
    if cclass == "UNREACHABLE":
        print(f"[control] POST {fill(cpath)}")
        print(f"          -> UNREACHABLE  {cbody}")
        print("          retrying once -- the query route builds pre-signed")
        print("          URLs and is the slowest route on this endpoint")
        cstatus, cbody = call(endpoint, token, fill(cpath), "POST",
                              {"limitHint": 1}, timeout=120)
        cclass = classify(cstatus)
    print(f"[control] POST {fill(cpath)}")
    print(f"          -> {cstatus}  {cclass}"
          + (f"  {cbody}" if cclass == "UNREACHABLE" else ""))
    post_control_ok = cclass in ("EXISTS_AND_ANSWERED",
                                 "EXISTS_REFUSED_OR_REJECTED")
    if post_control_ok:
        print("          POST is handled, so an ABSENT below is the path\n")
    else:
        print("          POST control did not answer. Candidates are still")
        print("          probed: the GET control already proves host and")
        print("          credential. The verdict says what is unconfirmed.\n")

    results = []
    for path, provenance in CANDIDATES:
        full = fill(path)
        status, body = call(endpoint, token, full, "POST", {})
        cls = classify(status)
        results.append({
            "candidate": path,
            "resolved": full,
            "provenance": provenance,
            "status": status,
            "classification": cls,
            "body_head": (body or "")[:200],
        })
        print(f"[cand] POST {full}")
        print(f"       -> {status}  {cls}")

    found = [r for r in results if r["classification"].startswith("EXISTS")]
    unreachable = [r for r in results if r["classification"] == "UNREACHABLE"]
    record = {
        "task": "E2 Task 2.3 / PC-2",
        "settles": "iac/config/route-table.yaml S10.protocol_path_unconfirmed",
        "endpoint": endpoint,
        "credential": name,
        "credentials_tried": tried,
        "discovered_triple": f"{share}.{schema}.{table}",
        "get_control": get_control,
        "post_control": {"path": fill(cpath), "status": cstatus,
                         "classification": cclass, "why": cwhy,
                         "passed": post_control_ok},
        "candidates": results,
        "documentation_note": (
            "The only documented temporary-table-credentials endpoint is "
            "POST <workspace-host>/api/2.1/unity-catalog/"
            "temporary-table-credentials -- Unity Catalog credential "
            "vending, on the WORKSPACE host, flat, with table_id in the "
            "body. CONOPS 2.3.2 targets S10 at the SHARING endpoint. If "
            "every candidate below is ABSENT, that is evidence S10 is not "
            "a sharing-protocol route at all."),
    }

    if found:
        record["verdict"] = "S10_PATH_CONFIRMED"
        record["confirmed_path"] = found[0]["candidate"]
        record["conops_action"] = (
            "Set S10.protocol_path to the confirmed value and clear "
            "protocol_path_unconfirmed, then regenerate the route family.")
    elif len(unreachable) == len(results):
        record["verdict"] = "CANNOT_SEE_EVERY_CANDIDATE_UNREACHABLE"
        record["conops_action"] = (
            "No candidate produced an HTTP status at all, so nothing is "
            "claimed about any path. This is a network or timeout result, "
            "not an absence. Re-run; if it persists, the endpoint is "
            "refusing POST at the transport level and that is its own "
            "finding.")
    elif not post_control_ok:
        record["verdict"] = "S10_ABSENT_ON_THE_GET_CONTROL_ONLY"
        record["conops_action"] = (
            "Every candidate returned 404 from the sharing endpoint, and "
            "the GET control proves the host and credential are right. "
            "What is NOT independently confirmed is that this endpoint "
            "handles POST on a path known to exist, because the query "
            "route did not answer in this run. The reading is strong but "
            "not closed: re-run when the query route is responsive, and "
            "if it returns 404 for every candidate with the POST control "
            "passing, treat the absence as settled and follow the two "
            "options under S10_ABSENT_FROM_THE_SHARING_ENDPOINT.")
    else:
        record["verdict"] = "S10_ABSENT_FROM_THE_SHARING_ENDPOINT"
        record["conops_action"] = (
            "No candidate exists on the sharing endpoint while the control "
            "answers on the same host with the same credential. S10 cannot "
            "be an S-class sharing route as 2.3.2 draws it. Two options, "
            "and v1.6 has to pick one: (a) reclassify S10 as an A1-class "
            "Databricks REST route on the WORKSPACE host, with its own "
            "policy class, body schema and upstream identity -- note this "
            "makes it a credential-vending route, which is a materially "
            "different security review from a metadata route; or (b) "
            "remove S10 from 2.3.2 and record credential vending as out "
            "of scope for channel E-1. Until one is chosen, generating a "
            "class C flow onto a path that matches nothing produces a "
            "catch-all refusal that reads as enforcement -- which is "
            "precisely what protocol_path_unconfirmed was guarding "
            "against.")

    EVIDENCE.parent.mkdir(exist_ok=True)
    EVIDENCE.write_text(json.dumps(record, indent=2) + "\n")
    print("\n" + "=" * 68)
    print(f"VERDICT: {record['verdict']}")
    print(f"Evidence: evidence/{EVIDENCE.name}")
    print("=" * 68)
    return 0


if __name__ == "__main__":
    sys.exit(main())
