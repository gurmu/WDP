#!/usr/bin/env python3
"""T-11 / AC5: trace one request by its correlation ID.

AC5 | CONOPS 3.5 | E5 | E2 Task 2.8 (the deliberate exception)

WHAT THIS REPLACED, AND WHY
---------------------------
The first version of this script did three things it had not checked.

1. It fired at the bare `GRAVITEE_GATEWAY_EDGE_URL` -- no route path, no
   bearer token. The gateway answered 404, because no API is mounted at
   `/`. It then printed:

       X-Correlation-Id=<not present -- check transform-headers policy>

   On a 404 NO API MATCHED, so no policy chain ran, so there was nothing
   for a transform-headers policy to do. The message named the policy as
   the suspect for a request that never reached one. Measured 2026-10-28:
   tests/t07_header_sanitization.py read X-Correlation-Id as PRESENT on a
   real route in the same environment, minutes apart. The policy was
   fine; the request was wrong. This is B-44's shape -- a verdict naming
   a component the evidence never reached.

2. It queried Elasticsearch at localhost:9200 and reported a connection
   error as though it were a transient. `elasticsearch` publishes NO
   ports in docker-compose.yml, so that address could never have
   answered from the host. A structural impossibility was being reported
   as bad luck.

3. It wrote no evidence file, so an AC5 package had nothing to carry.

HOW IT WORKS NOW
----------------
A correlation id is only meaningful if the request it labels actually
happened. So:

  * The request goes to a REAL route with a credential proven live in
    the same run -- reusing scripts/33's pick_live_profile, because a
    credential chosen by NAME is an assumption (recipient tokens here
    expire 24h after activation, measured) and route-family.json is
    where the edge paths live.

  * A non-200 is a CANNOT_SEE, not a finding about headers. The policy
    chain only runs on a matched route, so the header question is not
    even asked unless the positive control passes.

  * X-Correlation-Id is read from the RESPONSE. That header exists
    because of E2 Task 2.8: common.request injected it toward the
    BACKEND only, so the caller never saw one, and the gateway's own
    x-gravitee-* ids were serving as an accidental handle until they
    were suppressed (B-52). iac/config/response-header-allowlist.yaml
    names it as the single deliberate exception.

WHAT THIS STILL CANNOT SEE
--------------------------
The Databricks half. system.access.audit needs the system catalog
enabled on the metastore, and the cross-reference is Story 3 of 1227-E5.
The SQL is printed for a human to run; it is NOT claimed as verified.
Saying "trace confirmed" on the strength of the gateway half alone would
be claiming AC5 on half its evidence.
"""

import importlib.util
import json
import os
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent.parent
FAMILY = ROOT / "gravitee" / "generated" / "route-family.json"
ALLOWLIST = ROOT / "iac" / "config" / "response-header-allowlist.yaml"
EVIDENCE = ROOT / "evidence" / "t11-trace-correlation.json"

CORRELATION_HEADER = "x-correlation-id"

# Which indices hold REQUESTS. Measured 2026-10-29: this store also
# holds gravitee-monitor-*, which is JVM/node telemetry -- heap, os,
# process -- and nothing about requests. It dominates by volume (of
# 69,487 documents, almost all were monitor), so searching `gravitee-*`
# and sampling the newest document returns node telemetry and tells you
# nothing. The first version of this diagnostic did exactly that and
# printed fields ['@timestamp','gateway','hostname','jvm','os',
# 'process'] as though they were a request log's, then invited the
# reader to conclude the correlation id was absent from the log. Wrong
# index, confident sentence.
REQUEST_INDICES = "gravitee-v4-log-*,gravitee-v4-metrics-*,gravitee-request-*"
MONITOR_PREFIX = "gravitee-monitor-"


def _load(rel, modname):
    spec = importlib.util.spec_from_file_location(modname, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[modname] = mod
    spec.loader.exec_module(mod)
    return mod


P33 = _load("scripts/33_probe_s10_path.py", "t11_p33")


def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def load_env():
    env_path = ROOT / ".env"
    if not env_path.exists():
        sys.exit(f"Missing {env_path}.")
    for line in env_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        # A blank value is an ABSENCE, not a value -- docs/11 B-10b,
        # where a placeholder AWS_PROFILE= in .env reached botocore as a
        # request for a profile named "".
        if not v.strip():
            continue
        os.environ.setdefault(k, v)


def edge_base():
    explicit = os.environ.get("GRAVITEE_EDGE_BASE")
    if explicit:
        return explicit.rstrip("/"), "ENV_EXPLICIT"
    raw = os.environ.get("GRAVITEE_GATEWAY_EDGE_URL",
                         "http://localhost:8082").rstrip("/")
    for tail in ("/delta-sharing", "/opensharing-demo"):
        if raw.endswith(tail):
            return raw[:-len(tail)], f"ENV_STRIPPED_{tail}"
    return raw, "ENV_AS_IS"


def es_url():
    return os.environ.get("ELASTICSEARCH_URL", "http://localhost:9200").rstrip("/")


def inspect_log_store():
    """What is IN the store, asked before whether one id is in it.

    Added 2026-10-29. The previous version asked only "does this id
    appear?" and answered CORRELATION_ID_NOT_FOUND, which collapses two
    very different situations into one sentence:

      * the gateway is not reporting to this store at all, so there is
        nothing to find; or
      * it is reporting and the id is not matchable by the query used.

    The second was true here as well as possibly the first: the old
    query used Elasticsearch `query_string` with a raw UUID, and
    query_string reads a leading `-` as NOT. `670fe125-a00a-...` parses
    as one term followed by several NEGATED terms, so that query can
    match nothing whatever the store contains. A test whose own query
    cannot succeed reports an absence it manufactured.
    """
    base = es_url()
    try:
        r = requests.get(f"{base}/_cat/indices/gravitee-*",
                         params={"format": "json", "h": "index,docs.count"},
                         timeout=10)
    except requests.exceptions.RequestException as exc:
        return None, (f"{base} did not answer ({type(exc).__name__}). In "
                      f"this compose file `elasticsearch` is published on "
                      f"127.0.0.1:9200; if that was only just added, the "
                      f"container needs `docker compose up -d "
                      f"elasticsearch`. MISSING OBSERVATION, not a failed "
                      f"trace.")
    if r.status_code != 200:
        return None, f"{base}/_cat/indices answered {r.status_code}: {r.text[:200]}"
    try:
        rows = r.json()
    except ValueError:
        return None, f"_cat/indices did not return JSON: {r.text[:200]}"
    return rows, None


def query_gateway_log(correlation_id):
    """Find the request in Gravitee's own log store, and say what was
    observed rather than what was hoped for.

    Returns (verdict, detail, hits).
    """
    base = es_url()
    rows, err = inspect_log_store()
    if rows is None:
        return "CANNOT_SEE_LOG_STORE_UNREACHABLE", err, []

    # Count and name only the REQUEST indices. Monitor volume would
    # otherwise make an empty request log look like a full store.
    req_rows = [r for r in rows
                if not (r.get("index") or "").startswith(MONITOR_PREFIX)]
    monitor_rows = [r for r in rows if r not in req_rows]
    total = 0
    for row in req_rows:
        try:
            total += int(row.get("docs.count") or 0)
        except (TypeError, ValueError):
            pass
    names = sorted(r.get("index", "?") for r in req_rows)
    mon_note = (f" ({len(monitor_rows)} gravitee-monitor-* index/indices "
                f"ignored -- JVM telemetry, not requests)"
                if monitor_rows else "")
    rows = req_rows

    if not rows:
        return ("GATEWAY_IS_NOT_REPORTING_TO_THIS_STORE",
                f"{base} answered and holds NO request index at all{mon_note}, so "
                f"the gateway has never written here. The API-level "
                f"`analytics` block is confirmed on the server "
                f"(scripts/05 [REPORTING]), which enables reporting FOR "
                f"THE API -- it does not tell the gateway where to send "
                f"it. SUSPECT, not yet measured: docker-compose.yml sets "
                f"gravitee_ds_elastic_host/_port on the gateway, which is "
                f"the APIM 3.x analytics DATASOURCE key; the 4.x gateway "
                f"reporter is configured under reporters.elasticsearch.* "
                f"(e.g. gravitee_reporters_elasticsearch_enabled and "
                f"_endpoints_0). Confirm against this installation before "
                f"changing it -- a key name taken from recollection is "
                f"B-50.", [])

    if total == 0:
        return ("GATEWAY_IS_NOT_REPORTING_TO_THIS_STORE",
                f"{base} holds {len(rows)} gravitee-* index/indices "
                f"({', '.join(names)}) and ZERO documents{mon_note}, so the indices "
                f"exist but nothing has been written. Same suspect as "
                f"above: the gateway's reporter destination, not the "
                f"API's analytics flag.", [])

    # Phrase-safe, and only against the request indices. NOT
    # query_string -- see inspect_log_store's docstring.
    #
    # Retried with a wait, because Gravitee's reporter batches: the
    # request happened a second or two before this search, and "not
    # indexed yet" is not "not logged". An un-waited miss would be a
    # timing artefact reported as a finding.
    hits, waited = [], 0.0
    for delay in (0, 3, 5):
        if delay:
            time.sleep(delay)
            waited += delay
        try:
            r = requests.post(
                f"{base}/{REQUEST_INDICES}/_search",
                params={"ignore_unavailable": "true"},
                json={"query": {"multi_match": {"query": correlation_id,
                                                "fields": ["*"],
                                                "type": "phrase"}},
                      "size": 5},
                timeout=10)
        except requests.exceptions.RequestException as exc:
            return ("CANNOT_SEE_SEARCH_FAILED",
                    f"search against {base} failed ({type(exc).__name__})", [])
        if r.status_code != 200:
            return ("CANNOT_SEE_SEARCH_REFUSED",
                    f"{base} answered {r.status_code}: {r.text[:300]}", [])
        hits = (r.json().get("hits") or {}).get("hits") or []
        if hits:
            break
    if hits:
        return ("FOUND_IN_GATEWAY_LOG",
                f"{len(hits)} document(s) matched across "
                f"{len(rows)} request index/indices holding {total} "
                f"document(s){mon_note}"
                + (f", after waiting {waited:.0f}s for the reporter to "
                   f"flush" if waited else ", with no wait needed") + ".",
                hits)

    # Reporting works and this id is not matchable. Show what a document
    # DOES carry, so the next step is informed rather than guessed.
    sample_fields, sample_ids = [], {}
    try:
        sr = requests.post(f"{base}/{REQUEST_INDICES}/_search",
                           params={"ignore_unavailable": "true"},
                           json={"size": 1, "sort": [{"@timestamp":
                                                      {"order": "desc"}}]},
                           timeout=10)
        if sr.status_code == 200:
            sh = (sr.json().get("hits") or {}).get("hits") or []
            if sh:
                src = sh[0].get("_source") or {}
                sample_fields = sorted(src)
                sample_ids = {k: v for k, v in src.items()
                              if "id" in k.lower()}
    except requests.exceptions.RequestException:
        pass

    return ("REPORTING_WORKS_BUT_THIS_ID_IS_NOT_MATCHABLE",
            f"{total} request document(s) across {', '.join(names)}"
            f"{mon_note}, waited {waited:.0f}s for a flush, and none "
            f"carries this correlation id as a phrase. The gateway IS "
            f"reporting, so this is about which id is indexed, not about "
            f"whether anything was logged. A recent document carries "
            f"fields {sample_fields} with id-shaped values {sample_ids}. "
            f"If the id the caller receives is absent from those, then "
            f"X-Correlation-Id and the id the log is keyed on are "
            f"different values, and the claim that the caller's handle "
            f"finds the log entry is false and must be withdrawn.",
            [])


def scan_for_secrets(hits, token):
    """AC5's other half: no tokens or bodies in the logs."""
    findings = []
    for h in hits:
        blob = json.dumps(h.get("_source") or {})
        low = blob.lower()
        if token and token in blob:
            findings.append("THE BEARER TOKEN ITSELF appears in a log document")
        for needle in ("authorization", "bearer "):
            if needle in low:
                findings.append(f"the string {needle!r} appears in a log document")
    return sorted(set(findings))


def main():
    load_env()
    base, base_how = edge_base()

    print("=" * 68)
    print("T-11 / AC5: trace one request by its correlation ID")
    print("CONOPS 3.5 | AC5 | E5")
    print("=" * 68)
    print()
    print(f"edge base: {base}  ({base_how})")

    out = {"test": "T-11", "at": now(), "edge_base": base,
           "correlation_header": CORRELATION_HEADER}

    if not FAMILY.exists():
        print(f"\nVERDICT: CANNOT_SEE_NO_ROUTE_FAMILY\n  Missing {FAMILY}. "
              f"Run scripts/29 then scripts/05.")
        return 1
    family = json.loads(FAMILY.read_text()).get("family") or []

    print("\nselecting a live credential:")
    live, tried = P33.pick_live_profile(P33.load_profiles())
    if not live:
        print("\nVERDICT: CANNOT_SEE_NO_LIVE_CREDENTIAL")
        print("  Recipient tokens expire 24h after activation here "
              "(measured). Rotate with scripts/27 --rotate-token <name> "
              "--rotate-overlap-seconds 0, archive the stale credential "
              "file, then scripts/28 --recipient <name> --activate.")
        out["verdict"] = "CANNOT_SEE_NO_LIVE_CREDENTIAL"
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps(out, indent=2) + "\n")
        return 1
    cred_name, direct_endpoint, token = live

    member = next((m for m in family
                   if (m.get("recipient") or "") in cred_name
                   or (m.get("slug") or "zzz") in cred_name), None)
    if member is None:
        print("\nVERDICT: CANNOT_SEE_CREDENTIAL_NOT_IN_FAMILY")
        return 1

    # A REAL route, with the credential. The old version used the bare
    # base URL, got a 404, and blamed the header policy.
    url = f"{base}{member['edge_path']}/shares"
    hint = str(uuid.uuid4())
    print(f"credential: {cred_name}")
    print(f"firing:     GET {member['edge_path']}/shares")
    print(f"            (X-Demo-Correlation-Hint: {hint})")

    resp = requests.get(url, headers={"Authorization": f"Bearer {token}",
                                      "X-Demo-Correlation-Hint": hint},
                        timeout=30)
    hdrs = {k.lower(): v for k, v in resp.headers.items()}
    corr = hdrs.get(CORRELATION_HEADER)
    out.update({"credential": cred_name, "credentials_tried": tried,
                "edge_path": member["edge_path"], "url_path":
                f"{member['edge_path']}/shares", "demo_hint": hint,
                "status": resp.status_code,
                "correlation_id": corr,
                "response_header_names": sorted(hdrs)})

    print(f"\n--- phase 1: the request must succeed before anything else "
          f"is asked")
    print(f"    status {resp.status_code}")
    if resp.status_code != 200:
        print("\nVERDICT: CANNOT_SEE_NO_POSITIVE_CONTROL")
        print(f"    The route did not return 200, so the policy chain's "
              f"behaviour was not observed. A missing correlation header "
              f"on a non-200 says nothing about the policy -- on a 404 no "
              f"API matched and no chain ran at all. This is the reading "
              f"the previous version of this script got wrong.")
        out["verdict"] = "CANNOT_SEE_NO_POSITIVE_CONTROL"
        out["why"] = ("Non-200 at the edge; the header question is not "
                      "asked unless the route answers.")
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps(out, indent=2) + "\n")
        return 1

    print(f"\n--- phase 2: the caller's correlation handle")
    if not corr:
        print(f"    {CORRELATION_HEADER}: ABSENT on a 200")
        print(f"    Now this IS attributable: the route answered, so the "
              f"chain ran and did not add it. Check the 'Correlation ID "
              f"to the client' step in policy-classes.yaml common.response "
              f"and re-run scripts/29 + scripts/05.")
        out["verdict"] = "CORRELATION_HEADER_ABSENT_ON_A_SUCCESSFUL_ROUTE"
        out["why"] = ("The route returned 200, so the response policy "
                      "chain ran. The header's absence is the policy's.")
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps(out, indent=2) + "\n")
        return 1
    print(f"    {CORRELATION_HEADER}: {corr}")
    print(f"    CLAIM, tested in phase 3: this is {{#request.id}}, which "
          f"should be the id Gravitee's own request log is keyed on. If "
          f"phase 3 cannot find it, the claim is wrong and gets withdrawn "
          f"-- not reworded.")

    print(f"\n--- phase 3: the gateway's log")
    lv, ldetail, hits = query_gateway_log(corr)
    print(f"    {lv}")
    print(f"    {ldetail}")
    out["gateway_log"] = {"verdict": lv, "detail": ldetail,
                          "hits": len(hits), "store": es_url()}

    leaks = scan_for_secrets(hits, token) if hits else []
    if hits:
        print(f"\n--- phase 4: AC5's other half -- no tokens or bodies in "
              f"the log")
        if leaks:
            for f in leaks:
                print(f"    LEAK: {f}")
        else:
            print(f"    clean across {len(hits)} document(s)")
    out["secret_scan"] = {"checked_documents": len(hits),
                          "findings": leaks}

    # ------------------------------------------------------------------
    if leaks:
        verdict = "TRACE_WORKS_BUT_THE_LOG_CONTAINS_CREDENTIAL_TEXT"
        why = ("AC5 requires 'no tokens or bodies in logs' and the "
               "gateway log holds credential-shaped text. The trace half "
               "working does not offset this.")
    elif lv == "FOUND_IN_GATEWAY_LOG":
        verdict = "GATEWAY_HALF_TRACED_DATABRICKS_HALF_NOT_VERIFIED"
        why = ("The caller received a correlation id on a successful "
               "route and that id finds the gateway's own log entry, with "
               "no credential text in it. The DATABRICKS half is not "
               "verified here: system.access.audit needs the system "
               "catalog enabled on the metastore and the cross-reference "
               "is Story 3 of 1227-E5. AC5 is half-evidenced, and saying "
               "otherwise would claim it on half its evidence.")
    else:
        verdict = "CALLER_HAS_A_HANDLE_BUT_THE_LOG_WAS_NOT_OBSERVED"
        why = (f"The correlation header reaches the caller -- which is E2 "
               f"Task 2.8's deliberate exception working -- but the "
               f"gateway log could not be read ({lv}), so the trace was "
               f"not followed end to end. The handle existing and the "
               f"trace working are different claims.")

    out["verdict"] = verdict
    out["why"] = why
    out["databricks_half"] = {
        "status": "NOT_VERIFIED_BY_THIS_SCRIPT",
        "needs": "system catalog enabled on the metastore",
        "owner": "Story 3 of 1227-E5 (trace-compliance check); "
                 "dependency 1694-E4 for the propagation contract",
        "sql": ("SELECT event_time, action_name, request_params "
                "FROM system.access.audit "
                "WHERE service_name = 'unityCatalog' "
                "AND action_name IN ('deltaSharingQueryTable',"
                "'deltaSharingListTable') "
                "AND event_time > current_timestamp() - INTERVAL 10 MINUTES "
                "ORDER BY event_time DESC LIMIT 10;"),
    }
    EVIDENCE.parent.mkdir(exist_ok=True)
    EVIDENCE.write_text(json.dumps(out, indent=2) + "\n")
    try:
        EVIDENCE.chmod(0o600)
    except OSError:
        pass

    print(f"\n--- the Databricks half (not verified here)")
    print("    Run this and confirm an event lands in the same window:")
    print()
    for line in ("SELECT event_time, action_name, request_params",
                 "FROM system.access.audit",
                 "WHERE service_name = 'unityCatalog'",
                 "  AND action_name IN ('deltaSharingQueryTable',"
                 "'deltaSharingListTable')",
                 "  AND event_time > current_timestamp() - INTERVAL 10 MINUTES",
                 "ORDER BY event_time DESC LIMIT 10;"):
        print(f"      {line}")

    print(f"\nWrote evidence: {EVIDENCE.relative_to(ROOT)}  [0600]")
    print()
    print("=" * 68)
    print(f"T-11 VERDICT: {verdict}")
    print("=" * 68)
    print(why)
    return 0 if verdict.startswith("GATEWAY_HALF_TRACED") else 1


if __name__ == "__main__":
    sys.exit(main())
