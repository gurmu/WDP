#!/usr/bin/env python3
"""Build the Epic 2 migration bundle: dist/epic2-awoz-1227-<date>.zip

E2 Task 2.12 | AC2 | INC17 milestone 1227

WHY THIS IS A SCRIPT
--------------------
Epic 1's archive was built by hand. It passed both gates in the working
tree and still carried a file it should not have, because the file was
restored *after* the archive was written. The gates were run on the
wrong copy. A builder fixes that by construction: the manifest is
declared, the contents are hashed, and the guards run against what is
about to be written rather than against what happens to be on disk
nearby.

WHAT IT REFUSES TO DO
---------------------
Six guards, each of which has a real failure behind it:

1. A declared file that is missing -> refuse. A bundle quietly short a
   file is worse than no bundle, because the recipient cannot tell.
2. Anything under an EXCLUDED path (_secrets/, .env, .git/) -> refuse,
   even if something declares it. CONOPS 5.1: evidence carries metadata,
   never credentials.
3. A credential-shaped string in any included file -> refuse, naming the
   file and the key. Includes .docx, whose text is read out of its XML.
4. A task declared CLOSED whose evidence report says passed=false ->
   refuse. This is B-47 applied to the package: a bundle must not be the
   place a failing test becomes a green sentence.
5. A deferred item in the register that is not in DEFERRED_IDS, or an id
   in DEFERRED_IDS that is not in the register -> refuse. Keeps
   docs/15 and this script from drifting apart.
6. A README figure that this script cannot derive -> it is not written.
   Every test verdict in the README is READ from evidence/*.json at
   build time. None is typed here.

Run:
    python3 scripts/41_build_epic2_bundle.py            # build
    python3 scripts/41_build_epic2_bundle.py --check     # guards only
"""

import argparse
import hashlib
import json
import re
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
REGISTER = ROOT / "docs" / "15-deferred-to-client-environment.md"

# ---------------------------------------------------------------------------
# Paths that never enter a bundle, whatever declares them.
# ---------------------------------------------------------------------------
EXCLUDED_PREFIXES = ("_secrets/", ".git/", "dist/")
EXCLUDED_SUFFIXES = (".pyc", ".pem", ".key", ".p12", ".pfx")
# A dotenv file is excluded by NAME, not by prefix: ".env" as a prefix also
# swallows ".env.example", which is the one dotenv file that belongs in the
# bundle. Caught by the dry run, which is what dry runs are for.
DOTENV_ALLOWED = {".env.example", ".env.template", ".env.sample"}


# ---------------------------------------------------------------------------
# The manifest. Every entry carries a reason, because an artifact nobody
# can justify is an artifact nobody will maintain.
# ---------------------------------------------------------------------------
GROUPS = [
    ("Governing document", [
        ("CONOPS_AWOZ-1227_v1.5.docx",
         "The baselined document every finding is measured against."),
    ]),
    ("Configuration as code (the design, in machine-readable form)", [
        ("iac/config/route-table.yaml",
         "Every route, its class, its target and its refusals. The "
         "generator's only input for the route family."),
        ("iac/config/policy-classes.yaml",
         "Classes A-E plus class I, and the measured notes on each step: "
         "the spike-arrest enforced shape, B-55's extent, PC-1/2/4/5."),
        ("iac/config/producers.yaml",
         "Push-ingest producers and the landing-target rule. One "
         "producer, DECLARED_NOT_PROVISIONED."),
        ("iac/config/response-header-allowlist.yaml",
         "The 11 permitted response headers, derived from measured "
         "before/after captures, and the record that enforcement lives "
         "in the test rather than the gateway."),
        ("iac/config/recipients.yaml",
         "The recipient and credential model, including the two-phase "
         "T-02/T-03 procedure."),
        ("iac/config/channels.yaml", "Channel definitions (D2O, D2D, I-1, I-2)."),
        ("iac/config/entitlements.yaml", "Share and grant model."),
        ("iac/config/access-matrix.yaml", "Principal-to-object access."),
        ("iac/config/outbound-allow-list.yaml",
         "Egress addresses, generated."),
        ("iac/gravitee/schemas/query-body.schema.json",
         "Class B's request body schema, GENERATED from route-table S8 "
         "rather than written."),
        ("iac/databricks/access-matrix.tf", "Terraform, generated."),
        ("iac/databricks/entitlement.tf", "Terraform, generated."),
        ("iac/databricks/providers.tf", "Terraform providers."),
        ("iac/databricks/variables.tf", "Terraform variables."),
        ("iac/databricks/terraform.tfvars.example",
         "Variable template. Values are not in the bundle."),
    ]),
    ("Generators and probes", [
        ("scripts/05_import_gravitee_api.py",
         "Imports a generated definition and re-reads the server to "
         "confirm what it kept. Carries confirm_analytics_landed()."),
        ("scripts/29_gen_gravitee_route_family.py",
         "Generates the per-recipient API family and the push family "
         "from the route table. One API per recipient (B-42/D-9)."),
        ("scripts/30_gen_gravitee_ai_route.py", "Generates the M1 AI route."),
        ("scripts/37_gen_query_body_schema.py",
         "Derives class B's body schema from the route table; four "
         "guards refuse to generate rather than emit a permissive one."),
        ("scripts/36_probe_unlisted_paths.py",
         "Route X's refusing half: 7 unlisted paths plus before/after "
         "controls, attributed by the responder's own voice."),
        ("scripts/34_probe_deny_policy.py",
         "Which installed policy can refuse AND emit a body. Answer: "
         "none (PC-4)."),
        ("scripts/35_probe_deny_pair.py", "The paired form of the same question."),
        ("scripts/38_probe_ingest_policies.py",
         "All 79 installed policy schemas, read from the gateway, with "
         "the ingest shortlist printed in full."),
        ("scripts/33_probe_s10_path.py", "S10 path behaviour."),
        ("scripts/22_check_cac_config.py",
         "The static gate: ~400 checks across the CaC set, including "
         "that an ahead-of-document route carries its sanction."),
        ("scripts/27_build_recipient_model.py",
         "Recipient/credential model, applied and verified in eight rules."),
        ("scripts/28_activate_credential.py",
         "Credential activation, with a liveness verdict that cannot "
         "close on a stale file (B-51)."),
        ("scripts/06_trace_correlation.py",
         "AC5's correlation handle: fires a real route, requires a 200 "
         "before asking the header question, then interrogates the log "
         "store it has first inspected."),
        ("scripts/39_collect_conops_v16_inputs.py",
         "Generates docs/14 from every v1.6 mention in the repository."),
        ("scripts/40_build_weekly_report.py", "Week 43's report, as a builder."),
        ("scripts/41_build_epic2_bundle.py", "This script."),
        ("scripts/check_secret_hygiene.py", "The second gate."),
        ("scripts/lib/terminal_allow_list.py",
         "Derives route X's Ant whitelist from the forwarding flows' own "
         "selectors, with the translation shape asserted (B-50)."),
        ("scripts/hooks/pre-commit", "The hygiene hook."),
        ("scripts/hooks/install.sh", "Installs it."),
        ("scripts/00_check_capabilities.py",
         "The first thing to run after any environment change."),
    ]),
    ("Tests", [
        ("tests/common.py", "Shared harness."),
        ("tests/t01_gateway_read.py",
         "T-01: faithful reads through the edge, with CANNOT_SEE as a "
         "third verdict state and 1.1s pacing so a throttle is never "
         "scored as a refusal."),
        ("tests/t02_ip_access_list.py", "T-02: the IP allow-list, armed."),
        ("tests/t03_ip_refusal.py", "T-03: refusal from an address off the list, and reversed."),
        ("tests/t05_rate_limit.py",
         "T-05 edge half: four phases, both throttles captured verbatim, "
         "with a recovery control so a throttle that never clears cannot "
         "read as a pass."),
        ("tests/t06_body_schema.py", "T-06: class B body schema, each body sent direct and through the edge."),
        ("tests/t07_header_sanitization.py",
         "T-07: header sanitization, both halves, plus phase 3b which "
         "measures whether REFUSALS are sanitized (B-55)."),
        ("tests/t24_push_refusals.py",
         "T-24 edge half: 12 probes, attribution by constraint message, "
         "positive controls on the same path."),
        ("tests/t15_model_route.py", "T-15: the model-serving route (blocked, A-3)."),
        ("tests/t16_mcp_route.py", "T-16: the MCP route (blocked, A-3)."),
    ]),
    ("Generated gateway definitions (what was deployed)", [
        ("gravitee/api-definition.json", "The hand-written seed."),
        ("gravitee/generated/route-family.json", "The family manifest."),
        ("gravitee/generated/api-e1-psp7-demo.json", "Egress API, recipient 1."),
        ("gravitee/generated/api-e1-psp7-t2-us.json", "Egress API, recipient 2."),
        ("gravitee/generated/api-e1-t02-iplist.json", "Egress API, recipient 3."),
        ("gravitee/generated/api-i1-push-psp7-producer.json", "Push ingest, class I."),
        ("gravitee/generated/api-f1-storage-proxy.json",
         "F1, with FORWARDING_DISABLED. Included BECAUSE it is disabled: "
         "the listener is real and the forwarding step is not (A-2)."),
        ("gravitee/generated/api-m1-ai-gateway.json", "M1, upstream credential injected."),
    ]),
    ("Runtime", [
        ("docker-compose.yml",
         "The gateway stack, including the two overrideMode=keep env "
         "vars that closed B-52 and the loopback-bound Elasticsearch."),
        ("requirements.txt", "Python dependencies."),
        (".env.example",
         "The environment template. Values are NOT in the bundle; the "
         "header rule in this file says why."),
        (".gitignore", "What never gets committed."),
    ]),
    ("Documentation", [
        ("docs/epics/E2-T04-11-traffic-control.md",
         "Epic 2's working document: twelve tasks, each with its closure "
         "block or its stated blocker, and the filled §3.2 table."),
        ("docs/epics/E2-arb-package.md",
         "The AC2 package. Every figure traceable to evidence/; every "
         "gap named in the same sentence as the claim."),
        ("docs/11-environment-baseline.md",
         "The environment and the blocker register, B-1 to B-55."),
        ("docs/12-test-matrix.md", "All 25 tests, each assigned an epic and a feasibility verdict."),
        ("docs/13-decisions-and-risks.md", "Open decisions (OD-*) and risks (R*)."),
        ("docs/14-conops-v1.6-inputs.md",
         "Every v1.6 input the repository has recorded, GENERATED from "
         "the findings rather than transcribed."),
        ("docs/16-epic2-end-to-end.md",
         "The lead's briefing: Epic 2 end to end in CONOPS terms rather "
         "than artifact terms -- what each clause asks, which test "
         "measures it, what the test proves and what it cannot. Written "
         "to be talked from without opening a file."),
        ("docs/15-deferred-to-client-environment.md",
         "What is deferred and on which client resource -- and Part B, "
         "what is owed HERE before migration."),
        ("docs/10-implementation-manual.md", "How to stand the prototype up."),
        ("docs/00-services-setup-guide.md", "Service prerequisites."),
        ("docs/epics/E1-closure-record.md", "Epic 1's closure, which AC2 builds on."),
        ("docs/epics/E1-T04-10-perimeter-and-access.md", "Epic 1's working document."),
    ]),
]

# ---------------------------------------------------------------------------
# WHOLESALE directories.
#
# FIXED 2026-11-02, after a review found the bundle was not self-contained.
# The first version listed code file by file with a reason each, and took
# evidence wholesale. The result was 67 evidence files and 21 scripts:
# the T-04, T-19 to T-21, T-23 and B-32c evidence travelled without the
# code that produced it, `oss-provider/` was absent while docker-compose
# builds `./oss-provider`, so the README's own rebuild recipe could not
# work -- and `scripts/43` was cited three times by a bundled document
# and was not in the bundle.
#
# The lesson is the one this repository keeps relearning: a hand-kept
# list is the first thing to go stale. GROUPS below is kept, because an
# annotated core is genuinely useful to a reader, but it is now a
# COMMENTARY on the bundle rather than the definition of it. These
# directories are taken whole.
WHOLESALE_DIRS = ["scripts", "tests", "iac", "gravitee", "evidence",
                  "docs", "oss-provider", "reports"]
EVIDENCE_DIR = "evidence"

# ---------------------------------------------------------------------------
# Task status. The DECLARED half is a judgement; the VERDICT half is read
# from the evidence file at build time and is not typed here.
# ---------------------------------------------------------------------------
TASKS = [
    ("2.1", "Correct the B-1 diagnosis and fix the real fault", "CLOSED", None,
     "Upstream resolved from the issued credential, never a template."),
    ("2.2", "Make the import idempotent", "CLOSED", None,
     "scripts/05 re-reads the server to confirm what it kept."),
    ("2.3", "Generate the route table into the API definition", "CLOSED",
     "evidence/t01-report.json",
     "Both residue items settled; route X built after B-48. T-01 is the "
     "faithful-read evidence the route table's claim rests on, so it is "
     "cited here rather than left uncited -- which is what lets the "
     "guard below notice when its last run could not see."),
    ("2.4", "Policy classes A-E as shared configuration", "CLOSED", None,
     "Plus class I, labelled ahead-of-document."),
    ("2.5", "T-03: valid token from an address off the allow-list", "CLOSED",
     "evidence/t03-report.json", "Refusal measured and reversed."),
    ("2.6", "T-05: rate limit, spike arrest, and who trips first",
     "CLOSED (edge half); clause 2.5 deferred", "evidence/t05-report.json",
     "Both throttles verbatim; clause 2.5 needs system.access.audit (A-1)."),
    ("2.7", "T-06: schema validation, body limits, error format", "CLOSED",
     "evidence/t06-report.json", "Three rejections, two acceptances."),
    ("2.8", "T-07: header sanitization", "CLOSED, NARROWED by B-55",
     "evidence/t07-report.json",
     "Both halves measured. Covers successes only -- see A-5."),
    ("2.9", "T-08 and F1: the storage proxy, and B-3", "DEFERRED (A-2)", None,
     "No static upstream; Free Edition storage is Databricks-managed."),
    ("2.10", "T-15: class E and the serving routes",
     "PARTIAL -- injection confirmed; route deferred (A-3)",
     "evidence/t15-report.json",
     "T-15 passes on the half that is measurable here: the gateway "
     "replaces the caller's credential and the injected identity is "
     "scoped (R12A). What is deferred is a live serving endpoint behind "
     "the route, not the capability."),
    ("2.11", "T-24: the edge half of push ingest", "CLOSED",
     "evidence/t24-report.json",
     "Six refusals with distinct correct statuses; traversal fixed (B-54)."),
    ("2.12", "Fill in the §3.2 table, then build the package", "CLOSED", None,
     "Four of seven rows carry an observation; this bundle is the rest."),
]

# ---------------------------------------------------------------------------
# Structurally unobservable checks.
#
# A CANNOT_SEE has two very different causes and they need opposite
# remedies. A TRANSIENT one -- an expired credential, a service that was
# down -- is fixed by restoring the condition and re-running, and the
# builder should refuse until someone does. A STRUCTURAL one can never be
# observed from this environment, because the thing that prevents the
# observation is the control under test. Re-running will never fix it.
#
# Treating them alike is how a completeness gate becomes theatre: if a
# check can never reach a pass, a gate that demands one is overridden
# every single time, and an override that is always used stops being
# read. A structural case must be DECLARED, with its reason, and then
# accepted on its own terms.
#
# An entry only grants acceptance at status CONFIRMED. SUSPECTED is
# recorded, reported, and grants nothing -- because "we think this can
# never be observed" is exactly the kind of comfortable assumption this
# repository exists to not make.
STRUCTURAL_UNSEEN = [
    {
        "task": "2.3",
        "test_id_contains": "t02-iplist",
        "status": "CONFIRMED",
        "confirmed_on": "2026-11-03",
        "confirmed_by": (
            "The arm-and-reverse ran. The activation info call returned "
            "403; widening the recipient's address list made the SAME "
            "activation succeed, and scripts/28 reported "
            "IP_ACCESS_LIST_ENFORCEMENT_OBSERVED_ON_ACTIVATION_ENDPOINT; "
            "the list was then restored and verified. One variable, "
            "changed and changed back, with the outcome following it -- "
            "which is T-03's own method applied to the activation "
            "endpoint."),
        "claim": "The t02-iplist recipient cannot be activated from this "
                 "host, so T-01 can never observe it here.",
        "because": "That recipient exists in order to be REFUSED: its "
                   "address allow-list deliberately excludes this host, "
                   "which is the entire subject of T-03. If the activation "
                   "endpoint enforces the same list, the refusal is the "
                   "control working and no re-run will change it.",
        "why_not_confirmed": "Not yet measured. On 11-02 a FRESH rotation "
                             "activated two recipients and refused this one, "
                             "which is the asymmetry the claim predicts -- "
                             "but the refusal arrived as a generic "
                             "INFO_REFUSED_LINK_NOT_EXCHANGEABLE, not as the "
                             "IP-enforcement verdict scripts/28 has for "
                             "exactly this case. A generic refusal is "
                             "consistent with the claim and does not "
                             "establish it (B-46: a catch-all is not a "
                             "positive identification).",
        "how_to_confirm": "Run T-03's own arm-and-reverse against the "
                          "activation endpoint: widen this recipient's "
                          "address list, retry the activation, and observe "
                          "whether it then succeeds -- then restore the "
                          "list. Success under the widened list confirms "
                          "the structural claim; failure refutes it and "
                          "sends us looking for the real cause.",
    },
]

DEFERRED_IDS = ([f"A-{i}" for i in range(1, 12)]
                + [f"P-{i}" for i in range(1, 8)])

# ---------------------------------------------------------------------------
# Secret scanning
# ---------------------------------------------------------------------------
TOKEN_PATTERNS = [
    ("databricks PAT", re.compile(r"\bdapi[0-9a-f]{20,}", re.I)),
    ("github classic PAT", re.compile(r"\bghp_[A-Za-z0-9]{30,}")),
    ("github fine-grained PAT", re.compile(r"\bgithub_pat_[A-Za-z0-9_]{20,}")),
    ("aws access key id", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("private key block", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("bearer header literal", re.compile(r"Bearer\s+[A-Za-z0-9_\-\.]{30,}")),
]

# A long opaque value under one of these keys is a credential whatever it
# looks like. Hash fields are named explicitly so a SHA-256 in evidence
# does not read as a secret -- the whole point of key-aware scanning.
SECRET_KEY = re.compile(
    r"(bearer_?token|^token$|access_?token|refresh_?token|client_?secret"
    r"|password|passwd|secret|api_?key|private_?key)", re.I)
HASH_KEY = re.compile(r"(sha|hash|digest|fingerprint|checksum|_sha\d*)", re.I)
# A key can name a credential's LOCATION rather than hold one.
# `rotation.secret_written_to` = "_secrets/recipient-...-rotated.json"
# matched SECRET_KEY on the word "secret" and read as a leak, which it is
# not -- it is the pointer that lets an operator find the file. Exempting
# it needs BOTH halves: the key must name a location AND the value must
# look like a path. A token parked under a location-shaped key is still
# flagged, which is the case worth keeping.
LOCATION_KEY = re.compile(
    r"(written_to|^path$|_path$|^file$|_file$|^dir$|_dir$|location"
    r"|^ref$|_ref$|target|dest|_to$)", re.I)
PATHISH = re.compile(r"^[A-Za-z0-9_.][A-Za-z0-9_\-./]*\.[A-Za-z0-9]{1,8}$")
OPAQUE = re.compile(r"^[A-Za-z0-9_\-\.=+/]{25,}$")


def walk_json(node, path=""):
    if isinstance(node, dict):
        for k, v in node.items():
            yield from walk_json(v, f"{path}.{k}" if path else str(k))
    elif isinstance(node, list):
        for i, v in enumerate(node):
            yield from walk_json(v, f"{path}[{i}]")
    else:
        yield path, node


def text_of(path: Path):
    """Readable text for scanning, or None when there is nothing to scan."""
    if path.suffix.lower() == ".docx":
        try:
            with zipfile.ZipFile(path) as z:
                parts = [n for n in z.namelist()
                         if n.endswith(".xml") or n.endswith(".rels")]
                return "\n".join(z.read(n).decode("utf-8", "replace")
                                 for n in parts)
        except Exception as exc:
            return f"__UNREADABLE_DOCX__ {exc}"
    try:
        return path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        return None


def scan_for_secrets(rel: str, path: Path):
    """Return a list of (what, where) findings. Empty means clean."""
    found = []
    text = text_of(path)
    if text is None:
        found.append(("UNSCANNABLE BINARY", rel))
        return found
    if text.startswith("__UNREADABLE_DOCX__"):
        found.append(("UNREADABLE DOCX", f"{rel}: {text[:120]}"))
        return found

    for what, rx in TOKEN_PATTERNS:
        m = rx.search(text)
        if m:
            found.append((what, f"{rel} at offset {m.start()}"))

    if path.suffix.lower() == ".json":
        try:
            doc = json.loads(text)
        except json.JSONDecodeError:
            return found
        for keypath, val in walk_json(doc):
            if not isinstance(val, str) or not OPAQUE.match(val):
                continue
            leaf = keypath.split(".")[-1].split("[")[0]
            if HASH_KEY.search(leaf):
                continue
            if not SECRET_KEY.search(leaf):
                continue
            if LOCATION_KEY.search(leaf) and PATHISH.match(val):
                continue  # a pointer to the file, not the contents
            found.append(("opaque value under a credential key",
                          f"{rel} :: {keypath} ({len(val)} chars)"))
    return found


# ---------------------------------------------------------------------------
WHOLESALE_REASON = {
    "scripts": "Included so the evidence in this bundle travels with the "
               "code that produced it.",
    "tests": "Included so every verdict here can be re-derived rather than "
             "taken on trust.",
    "iac": "Configuration as code: the design in machine-readable form.",
    "gravitee": "The generated definitions, i.e. what was actually deployed.",
    "evidence": "Metadata only, per CONOPS 5.1. Scanned before writing.",
    "docs": "The written record, including the blocker register.",
    "oss-provider": "The open-source provider image context. docker-compose "
                    "BUILDS this path, so a bundle without it cannot be "
                    "stood up -- which is how its absence was found.",
    "reports": "The weekly reports issued against this work.",
}


def declared_files():
    """Every (relative path, reason) that goes into the bundle.

    GROUPS supplies the annotated core; WHOLESALE_DIRS supplies
    everything else, so adding a script tomorrow does not silently leave
    it out of the next bundle.
    """
    out, seen = [], set()
    for _group, entries in GROUPS:
        for rel, why in entries:
            if rel not in seen:
                seen.add(rel)
                out.append((rel, why))
    for d in WHOLESALE_DIRS:
        base = ROOT / d
        if not base.is_dir():
            continue
        why = WHOLESALE_REASON.get(d, "Included for self-containment.")
        for f in sorted(base.rglob("*")):
            if not f.is_file():
                continue
            rel = str(f.relative_to(ROOT))
            if rel in seen or is_excluded(rel):
                continue
            seen.add(rel)
            out.append((rel, why))
    return out


def is_excluded(rel: str):
    name = Path(rel).name
    if any(rel.startswith(p) for p in EXCLUDED_PREFIXES):
        return "excluded prefix"
    if name.startswith(".env") and name not in DOTENV_ALLOWED:
        return "live dotenv file"
    if rel.endswith(EXCLUDED_SUFFIXES):
        return "excluded suffix"
    if "__pycache__/" in rel + "/":
        return "build artifact"
    return None


def read_verdict(rel):
    """The verdict as the evidence file states it. Never typed by hand."""
    if rel is None:
        return None
    f = ROOT / rel
    if not f.is_file():
        return {"error": f"{rel} MISSING"}
    try:
        doc = json.loads(f.read_text())
    except json.JSONDecodeError as exc:
        return {"error": f"{rel} did not parse: {exc}"}
    rows = doc if isinstance(doc, list) else [doc]
    rows = [r for r in rows if isinstance(r, dict)]
    if not rows:
        return {"error": f"{rel} holds no verdict rows"}
    # Three verdict states, not two. A row that says CANNOT_SEE did not
    # fail -- it was not able to look, and the repository has treated that
    # as a result since B-46. Collapsing it into "fail" would be as wrong
    # as collapsing it into "pass", and the two need different remedies:
    # a failure needs a fix, a CANNOT_SEE needs a re-run under conditions
    # where the thing is visible.
    unseen = [r for r in rows
              if str(r.get("actual", "")).upper().startswith("CANNOT_SEE")]
    failed = [r for r in rows
              if r.get("passed") is not True and r not in unseen]
    return {
        "passed": not failed and not unseen,
        "checks": len(rows),
        "unseen": len(unseen),
        "failed": len(failed),
        "unseen_actuals": sorted({str(r.get("actual")) for r in unseen}),
        "unseen_ids": sorted({str(r.get("test_id")) for r in unseen}),
        "actual": rows[-1].get("actual", "(no actual field)"),
        "date": rows[-1].get("date", "(no date)"),
    }


def run_guards(accept_unseen=None):
    """accept_unseen: a stated reason, or None.

    A CANNOT_SEE is not a failure -- it is a test that could not look.
    Refusing to build on one was right as a default and wrong as an
    absolute: the environment can reach a state where the evidence
    cannot be refreshed quickly, and a bundle is still the right thing
    to produce. What must never happen is that the unseen state is
    INVISIBLE in the result.

    So the flag does not silence the condition; it moves it from a
    refusal to a caveat printed at the top of the bundle's own README,
    naming each affected task, the evidence file, the exact verdicts and
    the reason given. A genuine FAILING check is never acceptable this
    way and the flag does not touch it.
    """
    problems, warnings, unseen_accepted, structural = [], [], [], []

    # guard 1 + 2: declared files exist, and nothing excluded sneaks in
    files = declared_files()
    seen = set()
    for rel, _reason in files:
        if rel in seen:
            warnings.append(f"declared twice: {rel}")
            continue
        seen.add(rel)
        why = is_excluded(rel)
        if why:
            problems.append(f"GUARD 2  {rel}: {why} -- refused even though declared")
            continue
        if not (ROOT / rel).is_file():
            problems.append(f"GUARD 1  {rel}: declared and MISSING")

    # guard 3: secrets
    for rel, _reason in files:
        p = ROOT / rel
        if not p.is_file() or is_excluded(rel):
            continue
        for what, where in scan_for_secrets(rel, p):
            if what.startswith("UNSCANNABLE"):
                warnings.append(f"not scanned (binary): {where}")
            else:
                problems.append(f"GUARD 3  {what}: {where}")

    # guard 4: a task claimed CLOSED whose test did not pass
    verdicts = {}
    for tid, _title, status, report, _note in TASKS:
        v = read_verdict(report)
        verdicts[tid] = v
        if v is None:
            continue
        if "error" in v:
            problems.append(f"GUARD 4  Task {tid}: {v['error']}")
        elif v["failed"]:
            problems.append(
                f"GUARD 4  Task {tid} ({status}): {report} has "
                f"{v['failed']} FAILING check(s). A bundle must not be "
                f"the place a failing test becomes a green sentence.")
        elif v["unseen"] and status.startswith("CLOSED"):
            covered = [e for e in STRUCTURAL_UNSEEN
                       if e["task"] == tid and e["status"] == "CONFIRMED"
                       and any(e["test_id_contains"] in a
                               for a in v["unseen_ids"])]
            if covered and len(covered) >= v["unseen"]:
                structural.extend(covered)
                continue
            msg = (f"Task {tid} is declared {status!r} but "
                   f"{v['unseen']} of {v['checks']} checks in {report} read "
                   f"CANNOT_SEE: {', '.join(v['unseen_actuals'])}")
            if accept_unseen:
                unseen_accepted.append({
                    "task": tid, "status": status, "report": report,
                    "unseen": v["unseen"], "checks": v["checks"],
                    "actuals": v["unseen_actuals"]})
                warnings.append(msg + "  [accepted: see the README caveat]")
            else:
                problems.append(
                    f"GUARD 4  {msg}. Re-run it under conditions where the "
                    f"control is visible -- usually `python3 "
                    f"scripts/43_refresh_credentials.py --all` first "
                    f"(docs/15 P-7). Shipping evidence that could not see "
                    f"is worse than shipping none, because the reader "
                    f"cannot tell which it is. If the evidence genuinely "
                    f"cannot be refreshed now, build with "
                    f"--accept-unseen \"<reason>\": the condition is then "
                    f"printed on the bundle README's front page instead "
                    f"of being refused.")

    # guard 6: is the bundle self-contained? A path cited by a document
    # that is IN the bundle, which exists in the repo, and which is NOT in
    # the bundle, is a packaging defect. A path that exists nowhere is a
    # documentation defect -- different problem, reported as a warning so
    # it is visible without blocking the build.
    present_set = {r for r, _w in files if (ROOT / r).is_file()
                   and not is_excluded(r)}
    cite = re.compile(
        r"(?:scripts|tests|docs|iac|evidence|gravitee|oss-provider|reports)"
        r"/[A-Za-z0-9_][A-Za-z0-9_./-]*")
    missing_pack, missing_doc = {}, {}
    for rel in sorted(present_set):
        if not rel.endswith((".md", ".yaml", ".yml")):
            continue
        try:
            text = (ROOT / rel).read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        for m in cite.finditer(text):
            c = m.group(0).rstrip(".,);:`'\"")
            if c in present_set or is_excluded(c):
                continue
            if (ROOT / c).is_file():
                missing_pack.setdefault(c, set()).add(rel)
            elif "." in Path(c).name:
                missing_doc.setdefault(c, set()).add(rel)
    for c, where in sorted(missing_pack.items()):
        problems.append(
            f"GUARD 6  {c} exists in the repository, is cited by "
            f"{sorted(where)[0]}, and is NOT in the bundle. A bundle that "
            f"cites what it does not carry is not self-contained.")
    for c, where in sorted(missing_doc.items()):
        warnings.append(f"cited but exists nowhere: {c} "
                        f"(in {sorted(where)[0]}) -- documentation defect")

    # guard 5: register and DEFERRED_IDS agree
    if not REGISTER.is_file():
        problems.append(f"GUARD 5  {REGISTER.relative_to(ROOT)} is missing")
    else:
        reg = REGISTER.read_text()
        for i in DEFERRED_IDS:
            if not re.search(rf"(^|[^A-Za-z0-9-]){re.escape(i)}\.", reg, re.M):
                problems.append(f"GUARD 5  {i} is in DEFERRED_IDS and not in the register")
        for m in re.finditer(r"^### ([AP]-\d+)\.", reg, re.M):
            if m.group(1) not in DEFERRED_IDS:
                problems.append(
                    f"GUARD 5  the register has {m.group(1)} and DEFERRED_IDS does not")

    return files, verdicts, problems, warnings, unseen_accepted, structural


def readme(files, verdicts, at, stamp, unseen_accepted=(), reason=None):
    groups_present = [(g, [(r, why) for r, why in e if (ROOT / r).is_file()])
                      for g, e in GROUPS]
    n_ev = sum(1 for r, _ in files if r.startswith(EVIDENCE_DIR + "/"))

    L = []
    A = L.append
    A("# Epic 2 migration bundle — AWOZ-1227 / INC17 milestone 1227")
    A("")
    A(f"**Built {at} by `scripts/41_build_epic2_bundle.py`.** "
      "Every test verdict below is read out of the evidence file named "
      "beside it at build time. None is typed into the builder, so a "
      "verdict here cannot disagree with the evidence it cites.")
    A("")
    A("Platform measured: **Gravitee APIM CE 4.12.23**, Databricks "
      "OpenSharing (US-East-2), Free Edition tier.")
    A("")
    if unseen_accepted:
        A("## Read this before the evidence")
        A("")
        A("**Some evidence in this bundle could not see.** It did not "
          "fail — it was unable to observe its subject on its last run, "
          "which in this repository is a third verdict state and not a "
          "pass or a fail. The builder normally refuses to write an "
          "archive in this condition. It was overridden deliberately, "
          "and the override is why you are reading this block rather "
          "than finding out later.")
        A("")
        A(f"**Reason given at build time:** {reason}")
        A("")
        A("| Task | Evidence | Unseen | Verdicts |")
        A("|---|---|---|---|")
        for u in unseen_accepted:
            A(f"| **{u['task']}** ({u['status']}) | `{u['report']}` | "
              f"{u['unseen']} of {u['checks']} | "
              f"{', '.join(u['actuals'])} |")
        A("")
        A("**What this does and does not mean.** It does not mean the "
          "control failed; nothing here observed a control failing. It "
          "means that for these checks, this bundle carries no current "
          "observation either way, and any claim resting on them rests "
          "on an earlier run rather than on the evidence enclosed. "
          "Replace it by restoring the condition the test needs and "
          "re-running it, then rebuilding — the builder will then write "
          "the archive without this block.")
        A("")
    A("## Read these three first")
    A("")
    A("1. **`docs/epics/E2-arb-package.md`** — the AC2 package. Every "
      "figure traces to a file under `evidence/`, and every gap is "
      "stated in the same sentence as the claim it qualifies.")
    A("2. **`docs/15-deferred-to-client-environment.md`** — what is "
      "deferred, with the specific client-side resource each item needs, "
      "*and* Part B: what is owed here before migration. Part B is the "
      "part worth checking first, because it is the part that stops the "
      "deferred list becoming a parking space.")
    A("3. **`docs/11-environment-baseline.md` §11.7** — the blocker "
      "register, B-1 to B-55. The most useful thing in the bundle for "
      "anyone rebuilding this: it is a list of the mistakes, with what "
      "each cost.")
    A("")
    A("## What AC2 claims, and what it does not")
    A("")
    A("Four of AC2's five clauses are evidenced. **Clause 2.5 is not** — "
      "the throttles are measured firing and clearing at the configured "
      "points, and nothing here demonstrates that the edge trips *before* "
      "Databricks, which is what the clause actually asks for. That needs "
      "`system.access.audit`. See A-1 in the register.")
    A("")
    A("Three things this bundle deliberately does not claim:")
    A("")
    A("- **Deny-by-default is not native to this gateway.** An unmatched "
      "flow is *forwarded*, not refused (B-48). Route X is an explicit "
      "catch-all built because §3.2's fallback was the only route, and it "
      "returns a correct but **reasonless** 403 — the protocol error "
      "format is met on ingress and not on egress (PC-4).")
    A("- **Header sanitization covers successes, not refusals** (B-55). "
      "A request-phase refusal answers before the response chain runs.")
    A("- **Path rewrite is not demonstrated.** I1's upstream path comes "
      "from string concatenation, which is B-48's mechanism wearing a "
      "useful hat, and calling it a rewrite would be a false capability "
      "claim. R12 stays live.")
    A("")
    A("## Epic 2 task status")
    A("")
    A("| Task | | Status | Verdict, read from evidence |")
    A("|---|---|---|---|")
    for tid, title, status, report, note in TASKS:
        v = verdicts.get(tid)
        if v is None:
            cell = "_no test; see the epic document_"
        elif "error" in v:
            cell = f"**{v['error']}**"
        elif v["failed"]:
            mark = f"**FAIL** ({v['failed']}/{v['checks']})"
        elif v["unseen"]:
            mark = f"**CANNOT_SEE** ({v['unseen']}/{v['checks']})"
        else:
            mark = "PASS"
        if v is not None and "error" not in v:
            cell = (f"{mark} · `{report.split('/')[-1]}` · "
                    f"{v['actual']} · {v['checks']} check(s) · {v['date'][:10]}")
        A(f"| **{tid}** | {title} | {status} | {cell} |")
    A("")
    for tid, _title, _status, _report, note in TASKS:
        A(f"- **{tid}** — {note}")
    A("")
    A("## What is in here")
    A("")
    for group, entries in groups_present:
        A(f"### {group}")
        A("")
        for rel, why in entries:
            A(f"- **`{rel}`** — {why}")
        A("")
    A("### Evidence")
    A("")
    A(f"`evidence/` is included whole — {n_ev} file(s). It is taken "
      "wholesale rather than listed file by file because the package and "
      "`docs/11` both cite it, and a hand-kept list would be the first "
      "thing to go stale. Per CONOPS 5.1 it carries **metadata only**: no "
      "tokens, no credential files, no shared data. The builder scans "
      "every included file for credential-shaped strings and refuses to "
      "write the archive if it finds one.")
    A("")
    A("### What is deliberately NOT in here")
    A("")
    A("- `_secrets/` — credential files, activation records, server "
      "config with values. Excluded by path, and the exclusion wins even "
      "if something declares the file.")
    A("- `.env` — the live environment. `.env.example` is included; its "
      "own header carries the rule that the live file is never copied "
      "back over it.")
    A("- `.git/` and `__pycache__/` — history and build artifacts.")
    A("")
    A("## Rebuilding from this bundle")
    A("")
    A("```bash")
    A("# 1. verify the archive against its own manifest")
    A("sha256sum -c MANIFEST.sha256")
    A("")
    A("# 2. re-run both gates FROM THE EXTRACTION, not from a working tree")
    A("#    (Epic 1's archive passed in the working tree and was still wrong)")
    A("python3 scripts/22_check_cac_config.py")
    A("python3 scripts/check_secret_hygiene.py")
    A("")
    A("# 3. environment, then capability probe")
    A("cp .env.example .env    # fill it in; never copy it back")
    A("python3 scripts/00_check_capabilities.py")
    A("")
    A("# 4. generate and deploy, then test")
    A("python3 scripts/29_gen_gravitee_route_family.py")
    A("python3 scripts/05_import_gravitee_api.py")
    A("python3 tests/t01_gateway_read.py")
    A("```")
    A("")
    A("Input hashes are recorded in `evidence/gravitee-route-family.json`, "
      "so T-12's *\"redeploy from code to a clean target yields the same "
      "configuration\"* is checkable rather than asserted.")
    A("")
    A("## One sentence worth keeping")
    A("")
    A("> A perimeter test that never observes the perimeter absent is "
      "measuring the wrong thing.")
    A("")
    A("Every control in this bundle has a run in which it was switched "
      "off and seen to stop working. That is what makes the evidence "
      "worth taking to an ARB — and it is why the test count went up and "
      "the pass rate went down in the weeks that produced it.")
    A("")
    A(f"_Bundle id: `{stamp}`._")
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true",
                    help="run the guards and write nothing")
    ap.add_argument("--accept-unseen", metavar="REASON", default=None,
                    help="build even though some evidence reads CANNOT_SEE, "
                         "stating this REASON on the bundle README's front "
                         "page. Never applies to a FAILING check.")
    args = ap.parse_args()
    if args.accept_unseen is not None and not args.accept_unseen.strip():
        print("--accept-unseen needs a reason. The reason is the point: it "
              "is printed in the bundle, and a blank one would read as a "
              "shrug.")
        return 2

    at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    stamp = at[:10]
    print("=" * 70)
    print("Epic 2 migration bundle")
    print("=" * 70)
    print(f"  repo:  {ROOT}")
    print(f"  mode:  {'CHECK ONLY' if args.check else 'BUILD'}")
    print()

    (files, verdicts, problems, warnings, unseen_accepted,
     structural) = run_guards(args.accept_unseen)
    if STRUCTURAL_UNSEEN:
        print("-- declared structural limits ----------------------------------")
        for e in STRUCTURAL_UNSEEN:
            mark = "accepted" if e["status"] == "CONFIRMED" else "GRANTS NOTHING"
            print(f"  Task {e['task']}  {e['status']:<10} ({mark})")
            print(f"    {' '.join(e['claim'].split())}")
            if e["status"] != "CONFIRMED":
                print(f"    confirm by: {' '.join(e['how_to_confirm'].split())}")
        print()
    present = [(r, w) for r, w in files
               if (ROOT / r).is_file() and not is_excluded(r)]

    print("-- guards ------------------------------------------------------")
    print(f"  declared:   {len(files)} file(s)")
    print(f"  present:    {len(present)} file(s)")
    for w in warnings:
        print(f"  warn:       {w}")
    if problems:
        print()
        for p in problems:
            print(f"  {p}")
        print()
        print("=" * 70)
        print(f"VERDICT: REFUSED -- {len(problems)} guard failure(s)")
        print("=" * 70)
        print("Nothing was written. Fix the cause rather than the guard: a")
        print("bundle that passes because a check was relaxed is the exact")
        print("failure mode B-47 records.")
        return 1
    print("  all five guards: PASS")
    print()

    print("-- task verdicts, read from evidence ---------------------------")
    for tid, _title, status, report, _note in TASKS:
        v = verdicts.get(tid)
        if v is None:
            print(f"  {tid:<5} {status:<38} (no test)")
        else:
            if "error" in v:
                mark = "ERR "
            elif v["failed"]:
                mark = "FAIL"
            elif v["unseen"]:
                mark = "CSEE"
            else:
                mark = "PASS"
            print(f"  {tid:<5} {status:<38} {mark}  {v['actual'][:44]}")
    print()

    if args.check:
        print("=" * 70)
        print("VERDICT: GUARDS_PASS_NOTHING_WRITTEN")
        print("=" * 70)
        return 0

    DIST.mkdir(exist_ok=True)
    top = f"epic2-awoz-1227-{stamp}"
    zip_path = DIST / f"{top}.zip"

    body = readme(files, verdicts, at, stamp, unseen_accepted,
                  args.accept_unseen)

    lines = []
    for rel, _why in sorted(present):
        h = hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()
        lines.append(f"{h}  {rel}")
    manifest = "\n".join(lines) + "\n"

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"{top}/README.md", body)
        z.writestr(f"{top}/MANIFEST.sha256", manifest)
        for rel, _why in sorted(present):
            z.write(ROOT / rel, f"{top}/{rel}")

    # Re-open and verify, because a zip that was written is not a zip that
    # can be read. Hash every member back out of the archive.
    bad = []
    with zipfile.ZipFile(zip_path) as z:
        if z.testzip() is not None:
            bad.append(f"corrupt member: {z.testzip()}")
        want = {f"{top}/{rel}": h for h, rel in
                (l.split("  ", 1) for l in manifest.strip().split("\n"))}
        for name, h in want.items():
            got = hashlib.sha256(z.read(name)).hexdigest()
            if got != h:
                bad.append(f"hash differs in archive: {name}")
        n_members = len(z.namelist())

    size = zip_path.stat().st_size
    print("-- archive -----------------------------------------------------")
    print(f"  wrote:      dist/{zip_path.name}")
    print(f"  members:    {n_members}  (README + MANIFEST + {len(present)} files)")
    print(f"  size:       {size/1_048_576:.2f} MiB")
    print(f"  readback:   {'OK' if not bad else 'FAILED'}")
    for b in bad:
        print(f"    {b}")
    print()
    if bad:
        print("=" * 70)
        print("VERDICT: ARCHIVE_WRITTEN_BUT_DID_NOT_VERIFY")
        print("=" * 70)
        return 1

    (DIST / f"{top}-README.md").write_text(body)
    print("=" * 70)
    print("VERDICT: BUNDLE_BUILT_AND_VERIFIED")
    print("=" * 70)
    print("The README is also written beside the archive so it can be")
    print("read without extracting.")
    print()
    print("Next, and it is not optional: re-run both gates from inside an")
    print("EXTRACTION of this archive rather than from the working tree.")
    print("Epic 1's archive passed in the working tree and was still")
    print("wrong. That is item P-5 in docs/15 Part B.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
