#!/usr/bin/env python3
"""Generate iac/gravitee/schemas/query-body.schema.json from the route table.

E2 Task 2.4 | PC-1 | AC2 | CONOPS 2.3.2, 3.1, T-06

WHY A GENERATOR AND NOT A HAND-WRITTEN FILE
-------------------------------------------
`route-table.yaml` S8 already declares the allowed field list and
`additional_properties: false`. Typing those seven names into a JSON
file would put the same list in the repository twice, and the second
copy would be the one nobody updates. That is B-39 -- restating instead
of deriving -- which has now cost SIX defects here, and B-50 was the
seventh wearing a different hat.

So the schema is derived. If someone adds a field to S8, this script is
re-run and the schema follows; if they edit the schema by hand, the next
run overwrites it, which is the correct direction for a generated
artifact.

WHAT THIS CLOSES, AND WHAT IT DOES NOT
--------------------------------------
PC-1 recorded that class B's `json-validation` runs a permissive
fallback -- `{"type":"object","additionalProperties":true}`, a policy
that is PRESENT and validates nothing. The fallback was deliberate: an
absent policy and a permissive one are indistinguishable in a deployed
gateway, and only one of them is a decision. But it was never
superseded, because `scripts/29` only ever applied
`configuration_fallback` and never read the `configuration_source` that
policy-classes.yaml declared beside it. The declaration pointed at this
file; nothing followed the pointer. Both halves are fixed on
2026-10-27: this script writes the file, and `class_policies()` in
scripts/29 now resolves the source and inlines it.

What this does NOT do is make T-06 pass. Generating a schema is not
evidence that the gateway enforces it. T-06 is three rejections and one
acceptance measured through the edge, and until it runs, the honest
state of class B validation is "configured, unverified".

TWO THINGS DELIBERATELY NOT ENCODED
-----------------------------------
1. FIELD TYPES ARE DECLARED, NOT MEASURED. route-table.yaml carries
   them under `field_types` with
   `provenance: DELTA_SHARING_PROTOCOL_SPEC_NOT_MEASURED_HERE`. They
   come from the protocol specification, not from anything this
   repository observed. T-06 is what converts them: a body right in
   NAME and wrong in TYPE must be rejected, or the types are decorative
   and only the field names are enforced.

2. NO MUTUAL EXCLUSIVITY. The protocol treats version/timestamp and
   startingVersion/endingVersion as alternative ways to ask for the same
   thing, but §2.3.2 does not say so and nothing here measures it. A
   schema that rejected a combination the platform accepts would make
   the gateway STRICTER than the thing it fronts -- and T-01's
   faithfulness claim ("a reference client needs only the endpoint
   changed") would quietly stop being true. Being stricter than the
   upstream is a way of breaking a working client while every test
   stays green, so the exclusivity stays an open refinement for T-06
   rather than a guess shipped as enforcement.
"""

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
ROUTE_TABLE = ROOT / "iac" / "config" / "route-table.yaml"
OUT = ROOT / "iac" / "gravitee" / "schemas" / "query-body.schema.json"
EVIDENCE = ROOT / "evidence" / "query-body-schema.json"

ROUTE_ID = "S8"


def fail(msg):
    print(f"\nREFUSING TO GENERATE: {msg}")
    sys.exit(1)


def build(decl):
    """The schema, derived from one declaration.

    Raises rather than guessing on anything the route table does not
    say. A generated artifact whose gaps are filled in by the generator
    is a second source of truth wearing a disguise.
    """
    allowed = decl.get("allowed_fields") or []
    if not allowed:
        fail(f"{ROUTE_ID}.request_body.allowed_fields is empty. An empty "
             f"allow-list with additionalProperties:false would reject "
             f"EVERY body, including valid ones, and T-01's S8 row would "
             f"go red for a reason that looks like a platform fault.")

    ft = decl.get("field_types") or {}
    types = ft.get("types") or {}
    missing = [f for f in allowed if f not in types]
    extra = [f for f in types if f not in allowed]
    if missing:
        fail(f"no declared type for {missing}. Add them to "
             f"{ROUTE_ID}.request_body.field_types.types rather than "
             f"letting this script invent one -- an invented type is the "
             f"B-50 shape: an assumption about how a consumer reads a "
             f"value, never written down to be checked.")
    if extra:
        fail(f"field_types declares {extra}, which allowed_fields does "
             f"not. One of the two lists is stale; the route table must "
             f"agree with itself before it is generated from.")

    additional = decl.get("additional_properties")
    if additional is None:
        fail(f"{ROUTE_ID}.request_body.additional_properties is not "
             f"declared. It decides whether this schema constrains "
             f"anything at all, so it is not a field to default.")

    props = {}
    for name in allowed:
        t = dict(types[name])
        if t.get("type") == "array" and isinstance(t.get("items"), str):
            # `items: string` in the YAML is shorthand for the JSON
            # Schema form. Expanded here rather than asking the route
            # table to speak JSON Schema natively.
            t["items"] = {"type": t["items"]}
        props[name] = t

    return {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "title": "Delta Sharing query request body (CONOPS S8, class B)",
        "description": (
            "GENERATED by scripts/37_gen_query_body_schema.py from "
            "iac/config/route-table.yaml S8.request_body. Do not edit: "
            "the next run overwrites it. Add or change fields in the "
            "route table. Field types carry provenance "
            f"{ft.get('provenance')!r} and are verified by "
            f"{ft.get('verified_by')!r}, not by this file existing."),
        "type": "object",
        "properties": props,
        "additionalProperties": bool(additional),
    }


def main():
    if not ROUTE_TABLE.exists():
        fail(f"missing {ROUTE_TABLE}")
    table = yaml.safe_load(ROUTE_TABLE.read_text())
    rows = [r for r in (table.get("routes") or []) if r.get("id") == ROUTE_ID]
    if not rows:
        fail(f"{ROUTE_ID} is not in {ROUTE_TABLE.name}")
    decl = rows[0].get("request_body") or {}
    if not decl:
        fail(f"{ROUTE_ID} declares no request_body")

    schema = build(decl)

    print("=" * 68)
    print("Generate query-body.schema.json from route-table.yaml S8")
    print("E2 Task 2.4 | PC-1 | T-06")
    print("=" * 68)
    print()
    print(f"source:   {ROUTE_TABLE.relative_to(ROOT)}  ({ROUTE_ID})")
    print(f"fields:   {len(schema['properties'])} declared, "
          f"additionalProperties={schema['additionalProperties']}")
    for name, spec in schema["properties"].items():
        shape = spec.get("type")
        if shape == "array":
            shape = f"array<{(spec.get('items') or {}).get('type')}>"
        bound = f"  min {spec['minimum']}" if "minimum" in spec else ""
        print(f"    {name:<22} {shape}{bound}")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(schema, indent=2) + "\n")

    ft = decl.get("field_types") or {}
    EVIDENCE.parent.mkdir(exist_ok=True)
    EVIDENCE.write_text(json.dumps({
        "at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "generator": "scripts/37_gen_query_body_schema.py",
        "source": str(ROUTE_TABLE.relative_to(ROOT)),
        "route": ROUTE_ID,
        "wrote": str(OUT.relative_to(ROOT)),
        "fields": list(schema["properties"]),
        "additional_properties": schema["additionalProperties"],
        "closes": "PC-1, as CONFIGURED -- not as VERIFIED",
        "verification_still_outstanding": (
            "T-06: three rejections and one acceptance measured through "
            "the edge. A generated schema is not evidence that the "
            "gateway enforces it. Until T-06 runs, class B validation is "
            "'configured, unverified', and scripts/29 must be re-run and "
            "the family re-imported for this file to reach the gateway "
            "at all."),
        "field_types_provenance": ft.get("provenance"),
        "not_encoded": [
            "Mutual exclusivity of version/timestamp and "
            "startingVersion/endingVersion. Not stated by §2.3.2 and not "
            "measured. A gateway stricter than its upstream breaks a "
            "working client while every test stays green.",
        ],
    }, indent=2) + "\n")

    print()
    print(f"wrote:    {OUT.relative_to(ROOT)}")
    print(f"evidence: {EVIDENCE.relative_to(ROOT)}")
    print()
    print("=" * 68)
    print("VERDICT: QUERY_BODY_SCHEMA_GENERATED")
    print("=" * 68)
    print("PC-1 is closed as CONFIGURED, not as VERIFIED. The schema only")
    print("reaches the gateway after scripts/29 and scripts/05 re-run, and")
    print("only T-06 shows it is enforced.")
    print()
    print("Next: python3 scripts/29_gen_gravitee_route_family.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
