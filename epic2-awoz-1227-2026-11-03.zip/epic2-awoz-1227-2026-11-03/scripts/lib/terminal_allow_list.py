"""The terminal allow-list, in one place.

E2 Task 2.4 / B-48 / RF-1 / AI-6 / AI-7.

WHY THIS IS A MODULE AND NOT A SECOND COPY
------------------------------------------
`scripts/30_gen_gravitee_ai_route.py` built this flow for the AI route
on 2026-10-21 and T-16 verified it both ways. EPIC-ONE-TODO §3 then says
exactly how to bring it to the sharing and storage APIs:

    "The pattern to copy is terminal_allow_list() in
     scripts/30_gen_gravitee_ai_route.py. Copy the FUNCTION, not the
     patterns -- it derives them from the forwarding flows' own
     selectors. Restating them is B-39, which has now cost SIX defects
     in this repository."

Copying the function into a second generator would make it a seventh.
So it lives here and both generators call it, which is also AI-6's
stated durable fix for the three scripts that each parse
policy-classes.yaml their own way.

WHAT THE FLOW IS FOR
--------------------
Gravitee matches a context path as a PREFIX, and a request matching no
flow selector is FORWARDED, not refused. Measured live on the AI route
before this existed, with a valid caller token:

    /ai-gateway-demo/api/2.0/token/list         -> 200
    /ai-gateway-demo/api/2.0/clusters/list      -> 200
    /ai-gateway-demo/api/2.0/serving-endpoints  -> 200

The sharing APIs did not show it because their endpoint target carries a
deep base path, so a stray path is APPENDED and the upstream 404s. That
is confinement by string concatenation -- a property of how two strings
join, not a decision, and one target edit from being gone. B-48.

A WHITELIST, NOT A DENY LIST
----------------------------
A deny list must anticipate every path worth protecting and fails open
on everything it forgot. This fails closed on everything not named: the
verdict for a forgotten route is a visible 403 on a route someone
wanted, not silent reach into one nobody did.

normalizeRequestPath AND decodeEncodedSlash
-------------------------------------------
Both default to FALSE in this installation's schema, read rather than
assumed. Both are set TRUE. With them off the policy matches the raw
path while the upstream resolves a normalized one, so `/a/./b` and an
encoded variant are a different string to the filter and the same
resource upstream -- filtering the spelling instead of the resource.
Confirmed working 2026-10-27 by scripts/35_probe_deny_pair.py: with both
true, `/%64enied` was refused exactly as `/denied` was.

WHAT THIS FLOW CANNOT DO, MEASURED
----------------------------------
It refuses with a reasonless 403 and no amount of configuration changes
that. `resource-filtering`'s schema has four properties -- whitelist,
blacklist, normalizeRequestPath, decodeEncodedSlash -- and no message,
body or status field. A response-phase carrier does NOT run after an
interrupting policy refuses: measured 2026-10-27, the 403 came back
carrying the policy's own default string rather than the assigned
protocol error body. So §2.3.2's "denied in the protocol error format
(errorCode, message)" is not achievable here, and policy-classes.yaml
PC-4 records it as an accepted limit. The alternative, `mock`, is the
only policy that sets a status and a body and it fails OPEN -- on a
catch-all that is the whole perimeter (AI-9).

The consequence reaches every deny row: a named deny's reason reaches
the AUDITOR through the generated artifact, never the CALLER, because
this flow's generic selector is evaluated first and answers before the
named deny is reached.

TWO PATTERN LANGUAGES, AND THE TRANSLATION BETWEEN THEM
-------------------------------------------------------
A Gravitee selector path names its path parameters: `/shares/:share`.
A `resource-filtering` whitelist is a list of ANT patterns, in which
`:share` is five ordinary literal characters. These are different
languages, and this module is the only place that converts between
them.

The first version of this module did not convert at all -- it copied
each selector path into the whitelist verbatim. MEASURED 2026-10-27:
`/shares`, the one route carrying no parameter, returned 200 through
the gateway; all seven parameterised reads returned 403 at the gateway
while returning 200 directly. T-01 1/4,
GATEWAY_REFUSES_READS_THAT_SUCCEED_DIRECTLY. The whitelist was not
wrong about WHICH routes to admit; it was written in the wrong
language. Recorded as B-50, whose general shape is: a derivation is
only as sound as its claim about how the CONSUMER reads what was
derived, and that claim had never been written down anywhere it could
be checked.
"""

import re

# `:name` and `{name}`. The brace form is accepted because
# route-table.yaml spells protocol paths that way, so a future caller
# deriving from the route table rather than from generated selectors
# does not reintroduce B-50.
_PARAM = re.compile(r":[A-Za-z_][A-Za-z0-9_]*|\{[^/{}]+\}")


def selector_path_to_ant(path):
    """Translate one Gravitee selector path into an Ant pattern.

    Each path parameter becomes `*`, which in Ant matches within a
    single path segment and does NOT cross `/`. Single-segment is
    deliberate: `**` would admit arbitrary depth beneath the parameter,
    and the whitelist would stop constraining the thing it exists to
    constrain.

    Interaction with decodeEncodedSlash, which this flow sets TRUE: a
    parameter value carrying an encoded slash is decoded BEFORE
    matching, so it then spans two segments and `*` no longer admits
    it -- a 403. That is fail-closed, and it is the right direction for
    a value that would otherwise reach the upstream as a separator.
    """
    return _PARAM.sub("*", path)


def assert_translation_shape(patterns):
    """Refuse to generate if a pattern still carries selector syntax.

    This checks the TRANSLATION, not Gravitee's behaviour. It shows no
    parameter form survived into a whitelist entry. It does NOT show
    that Gravitee admits the live path -- only the gateway can answer
    that, and T-01's positive control is the sole evidence about it.
    Keeping those two claims apart is the whole point: B-50 was a
    translation checked against my own model of the matcher instead of
    against the matcher.
    """
    residue = [p for p in patterns if _PARAM.search(p["pattern"])]
    if residue:
        raise ValueError(
            "terminal_allow_list: %d whitelist pattern(s) still carry "
            "selector parameter syntax after translation -- e.g. %r, "
            "from selector %r. resource-filtering reads those as "
            "LITERAL characters, so such an entry admits nothing and "
            "this catch-all refuses a live route with a reasonless "
            "403. That is B-50. Extend _PARAM to cover the form above; "
            "do not remove this check."
            % (len(residue), residue[0]["pattern"],
               residue[0].get("_from_selector")))


def derive_patterns(forwarding_flows, exclude_unconfirmed=True):
    """Read the allow-list off the selectors of the flows that forward.

    Returns (patterns, excluded). Each pattern carries `_admits_flow`
    naming the flow that contributed it: an allow-list entry with no
    provenance is one nobody can safely remove later.

    `exclude_unconfirmed` drops flows whose provenance carries
    `path_unconfirmed`. That matters as of 2026-10-27: S10's path was
    MEASURED ABSENT from the sharing endpoint by
    scripts/33_probe_s10_path.py, so admitting it would whitelist a path
    that does not exist. Excluding it means S10 is refused at the edge
    rather than forwarded to a 404 upstream -- both are refusals, and
    the edge one is honest about which component decided.
    """
    patterns, excluded = [], []
    for flow in forwarding_flows:
        prov = flow.get("_provenance") or {}
        if exclude_unconfirmed and prov.get("path_unconfirmed"):
            excluded.append({
                "flow": flow.get("name"),
                "route_id": prov.get("route_id"),
                "because": "protocol_path_unconfirmed -- not admitted",
            })
            continue
        for sel in flow.get("selectors") or []:
            path = sel.get("path")
            if not path:
                continue
            op = sel.get("pathOperator") or "EQUALS"
            ant = selector_path_to_ant(path)
            entry = {"pattern": ant if op == "EQUALS"
                     else ant.rstrip("/") + "/**"}
            methods = sel.get("methods")
            if methods:
                entry["methods"] = list(methods)
            entry["_admits_flow"] = flow.get("name")
            # The selector this was translated FROM. Without it, a
            # reviewer reading `/shares/*/schemas` cannot tell whether
            # the wildcard is a translated parameter or a widening
            # somebody chose, and B-50 is invisible in the artifact.
            entry["_from_selector"] = path
            if ant != path:
                entry["_translated"] = (
                    "selector path parameter(s) -> Ant single-segment "
                    "wildcard(s); see B-50")
            patterns.append(entry)
    return patterns, excluded


def terminal_allow_list(forwarding_flows, flow_name="X-terminal-allow-list",
                        step_name="Allow only the paths the route table names",
                        step_description=None, extra_rationale=None,
                        exclude_unconfirmed=True):
    """The flow. Raises ValueError on an empty whitelist -- see below."""
    patterns, excluded = derive_patterns(forwarding_flows,
                                         exclude_unconfirmed)
    if not patterns:
        raise ValueError(
            "terminal_allow_list: no forwarding flow contributed a "
            "pattern. Refusing to generate. An EMPTY whitelist is the "
            "same trap as the empty `rules` set this flow exists to "
            "replace -- it is indistinguishable, in the artifact, from a "
            "whitelist that was never meant to constrain anything, and "
            "whether Gravitee reads it as 'allow nothing' or as 'no "
            "constraint' decides between a dead route and an open proxy. "
            "The generator must not ship a definition whose safety "
            "depends on which way that is resolved.")
    assert_translation_shape(patterns)
    rationale = {
        "risk": "B-48",
        "pattern_language": (
            "Selector paths name parameters (`/shares/:share`); a "
            "resource-filtering whitelist is ANT, where `:share` is "
            "literal. Each parameter is translated to `*`, which does "
            "not cross `/`. Copying selector paths verbatim is B-50, "
            "MEASURED 2026-10-27 as T-01 1/4: only the one route with "
            "no parameter was admitted. Every entry carries the "
            "selector it came from so the wildcard is distinguishable "
            "from a widening somebody chose."),
        "shared_module": (
            "scripts/lib/terminal_allow_list.py. Both generators call "
            "it so the patterns are derived once; restating them per "
            "generator is B-39, which has cost six defects here."),
        "whitelist_is_derived": (
            "Patterns are read off the forwarding flows' own selectors. "
            "An allow-list that drifts from the routes it admits either "
            "refuses a live route (loud, fine) or admits a path no flow "
            "claims (silent, not fine)."),
        "normalization": (
            "normalizeRequestPath and decodeEncodedSlash both default "
            "FALSE in this installation's schema and are set TRUE here. "
            "Confirmed working 2026-10-27: /%64enied refused as /denied."),
        "no_reason_carried": (
            "This flow answers with a reasonless 403 and cannot do "
            "otherwise -- resource-filtering has no message field, and a "
            "response-phase carrier does not run after an interrupting "
            "policy. Measured, PC-4. The named deny rows' reasons reach "
            "the generated artifact and the auditor, never the caller."),
        "evaluation_order": (
            "The '/' STARTS_WITH selector is the most generic, and "
            "Gravitee evaluates most generic first regardless of array "
            "position. Array position is NOT evaluation order (B-48's "
            "second retraction), which is why this flow's safety rests "
            "on its whitelist admitting every path the specific flows "
            "claim, not on where it sits."),
    }
    if excluded:
        rationale["excluded_from_whitelist"] = excluded
    if extra_rationale:
        rationale.update(extra_rationale)
    return {
        "name": flow_name,
        "enabled": True,
        "selectors": [{"type": "HTTP", "path": "/",
                       "pathOperator": "STARTS_WITH"}],
        "request": [{
            "name": step_name,
            "description": step_description or (
                "Fails closed on every path no flow claims. Without it, "
                "an unmatched path is FORWARDED, not refused."),
            "policy": "resource-filtering",
            "enabled": True,
            # No `condition` on this step, ever. AI-10: a step condition
            # that does not evaluate true causes Gravitee to omit the
            # policy silently -- PUT 200, deploy 202, no warning -- and
            # a condition is unsafe on a step that IS the refusal.
            "configuration": {
                "whitelist": [{k: v for k, v in p.items()
                               if not k.startswith("_")} for p in patterns],
                "normalizeRequestPath": True,
                "decodeEncodedSlash": True,
            },
            "_rationale": rationale,
            "_admits": [{"pattern": p["pattern"],
                         "from_flow": p.get("_admits_flow"),
                         "from_selector": p.get("_from_selector")}
                        for p in patterns],
        }],
        "response": [],
        "_provenance": {
            "route_id": "X",
            "generated": True,
            "generated_since": "2026-10-27",
            "closes": ["RF-1", "PC-4 (as an accepted limit)"],
            "policy": "resource-filtering",
            "policy_because": (
                "The only installed candidate whose failure mode is "
                "MEASURED fail-closed (scripts/34). `mock` can emit a "
                "body and fails OPEN; on a catch-all that forwards every "
                "unlisted path."),
        },
    }
