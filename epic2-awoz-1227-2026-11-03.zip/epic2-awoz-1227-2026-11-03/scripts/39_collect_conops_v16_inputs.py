#!/usr/bin/env python3
"""Collect every CONOPS v1.6 input the repository has recorded.

E2 Task 2.12 | CONOPS v1.6 | AC2

WHY THIS IS A GENERATOR AND NOT A DOCUMENT
------------------------------------------
On 2026-10-29 there were forty-odd places in this repository saying some
version of "v1.6 should", "v1.6 must", "v1.6 owes", spread across six
config files, docs/11 and docs/12. They accumulated as findings landed,
which is the right way for them to arrive and the wrong way for them to
be read: nobody drafting v1.6 is going to grep six YAML files.

A hand-written index of them would be stale the first time someone adds
a finding -- and this repository has added one most days. So the index is
derived from the sources, the way the route family is derived from the
route table. Generate, do not transcribe: B-39 has cost six defects
here, and an index that silently drifts from what it indexes is the same
failure wearing a friendlier shape.

WHAT IT LOOKS FOR, AND WHAT THAT MISSES
---------------------------------------
Any string in a config value, or any line in a markdown doc, mentioning
v1.6. That is a text search and it has a floor rather than a ceiling: a
finding whose author wrote "the next revision" or "the baselined
document" instead is invisible here. The convention is therefore to
write "v1.6" when a finding owes the document something -- stated in the
output so the next author knows the cost of departing from it.
"""

import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml

REPO = Path(__file__).resolve().parent.parent
CONFIG = REPO / "iac" / "config"
DOCS = REPO / "docs"
OUT = DOCS / "14-conops-v1.6-inputs.md"
EVIDENCE = REPO / "evidence" / "conops-v16-inputs.json"

NEEDLE = re.compile(r"v1[._]6", re.I)

# Sections the items map onto, so a drafter can work section by section
# rather than file by file. Matched against the item's own text.
SECTION_HINTS = [
    (re.compile(r"\b2\.3\.2\b"), "2.3.2 route table"),
    (re.compile(r"\b2\.3\.3\b"), "2.3.3 policy classes"),
    (re.compile(r"\b2\.3\.4\b"), "2.3.4 reference clients"),
    (re.compile(r"\b2\.3\b"), "2.3 gateway design"),
    (re.compile(r"\b2\.4\.5\b"), "2.4.5 push ingest (I-2)"),
    (re.compile(r"\b2\.4\b"), "2.4 ingress"),
    (re.compile(r"\b2\.1\b"), "2.1 channels"),
    (re.compile(r"\b2\.2\b"), "2.2 egress flow"),
    (re.compile(r"\b3\.1\b"), "3.1 AC1 perimeter"),
    (re.compile(r"\b3\.2\b"), "3.2 capability table"),
    (re.compile(r"\b3\.4\b"), "3.4 reference clients / endpoints"),
    (re.compile(r"\b3\.5\b"), "3.5 audit and trace"),
    (re.compile(r"\b5\.2\b"), "5.2 test plan"),
    (re.compile(r"\b6\.1\b"), "6.1 evidence rule"),
    (re.compile(r"\b6\.3\b|secret.hygien"), "6.3 secret hygiene"),
    (re.compile(r"\bOD-\d+\b"), "open decisions"),
]

# An item that names no section is usually not a missing section number;
# it is a finding that applies across the document -- a configuration
# constraint, an evidence rule, a method. Filing those under a guessed
# section would hide them in a section that does not need changing.
CROSS_CUTTING = "cross-cutting (the finding names no single section)"


def section_for(text):
    for rx, name in SECTION_HINTS:
        if rx.search(text):
            return name
    return CROSS_CUTTING


def walk_yaml(node, path=""):
    """Every (key path, string) in a parsed YAML document."""
    if isinstance(node, dict):
        for k, v in node.items():
            here = f"{path}.{k}" if path else str(k)
            if isinstance(v, str):
                yield here, v
            else:
                yield from walk_yaml(v, here)
    elif isinstance(node, list):
        for i, v in enumerate(node):
            here = f"{path}[{i}]"
            if isinstance(v, str):
                yield here, v
            else:
                yield from walk_yaml(v, here)


def squash(text, limit=560):
    out = " ".join(str(text).split())
    return out if len(out) <= limit else out[:limit].rstrip() + " [...]"


def collect_configs():
    items = []
    for f in sorted(CONFIG.glob("*.yaml")):
        try:
            doc = yaml.safe_load(f.read_text())
        except yaml.YAMLError as exc:
            items.append({"source": str(f.relative_to(REPO)),
                          "locator": "FILE DID NOT PARSE",
                          "text": f"{exc}"[:300], "kind": "error"})
            continue
        for keypath, val in walk_yaml(doc):
            if NEEDLE.search(val) or NEEDLE.search(keypath):
                items.append({
                    "source": str(f.relative_to(REPO)),
                    "locator": keypath,
                    "text": squash(val),
                    "kind": "config",
                    "section": section_for(f"{keypath} {val}"),
                })
    return items


def collect_markdown():
    """Markdown lines mentioning v1.6, with a little surrounding text.

    Deliberately NOT the whole paragraph: docs/11 runs to 170 KB and
    whole paragraphs would bury the index in the thing it indexes. The
    locator is a line number so the original is one jump away.
    """
    items = []
    targets = sorted(DOCS.glob("*.md")) + sorted((DOCS / "epics").glob("*.md"))
    for f in targets:
        if f.resolve() == OUT.resolve():
            continue  # never index our own output
        lines = f.read_text().splitlines()
        for i, line in enumerate(lines, 1):
            if not NEEDLE.search(line):
                continue
            window = " ".join(lines[max(0, i - 2):i + 1])
            items.append({
                "source": str(f.relative_to(REPO)),
                "locator": f"line {i}",
                "text": squash(window),
                "kind": "markdown",
                "section": section_for(window),
            })
    return items


def main():
    items = collect_configs() + collect_markdown()
    # Dedupe on (source, text): docs/11 repeats some findings in a
    # summary table and again in the entry.
    seen, unique = set(), []
    for it in items:
        key = (it["source"], it["text"][:160])
        if key in seen:
            continue
        seen.add(key)
        unique.append(it)

    by_section = {}
    for it in unique:
        by_section.setdefault(it.get("section", CROSS_CUTTING), []).append(it)

    at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    lines = [
        "# CONOPS v1.6 inputs, collected from the repository",
        "",
        f"**GENERATED** by `scripts/39_collect_conops_v16_inputs.py` at "
        f"{at}. Do not edit: the next run overwrites it. To add an item, "
        f"write it where the finding lives -- in the config row or the "
        f"blocker entry it came from -- and mention v1.6 there.",
        "",
        f"{len(unique)} item(s) across {len(by_section)} section(s), from "
        f"{len({i['source'] for i in unique})} file(s).",
        "",
        "## How to read this",
        "",
        "Each item is a place where the prototype measured something the "
        "baselined document does not say, or says differently. The text "
        "is quoted from its source and the locator points back at it; "
        "nothing here is a new claim. An item is an INPUT, not a decision "
        "-- several of them are alternatives that v1.6 has to choose "
        "between, and the ones that need a decision rather than an edit "
        "say so in their own words.",
        "",
        "**What this search cannot find.** It matches the literal string "
        "`v1.6`. A finding whose author wrote \"the next revision\" "
        "instead is invisible here, so the convention is to write `v1.6` "
        "when a finding owes the document something. That convention is "
        "the only thing keeping this index complete.",
        "",
    ]
    # Cross-cutting last: a drafter works section by section and then
    # reads the rules that apply to all of them.
    ordered = sorted(k for k in by_section if k != CROSS_CUTTING)
    if CROSS_CUTTING in by_section:
        ordered.append(CROSS_CUTTING)
    for section in ordered:
        rows = by_section[section]
        lines += [f"## §{section}" if section[0].isdigit()
                  else f"## {section}", "",
                  f"{len(rows)} item(s).", ""]
        for it in rows:
            lines += [f"- **`{it['source']}`** — {it['locator']}",
                      f"  > {it['text']}", ""]

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(lines) + "\n")

    EVIDENCE.parent.mkdir(exist_ok=True)
    EVIDENCE.write_text(json.dumps({
        "at": at,
        "generator": "scripts/39_collect_conops_v16_inputs.py",
        "wrote": str(OUT.relative_to(REPO)),
        "item_count": len(unique),
        "sections": {k: len(v) for k, v in sorted(by_section.items())},
        "sources": sorted({i["source"] for i in unique}),
        "items": unique,
        "method_limit": (
            "A literal search for 'v1.6'. Findings phrased another way "
            "are invisible, so the index is as complete as the "
            "convention is kept."),
    }, indent=2) + "\n")

    print("=" * 68)
    print("CONOPS v1.6 inputs, collected")
    print("=" * 68)
    print()
    for section in ordered:
        print(f"  {len(by_section[section]):>3}  {section}")
    print()
    print(f"  {len(unique)} item(s) from "
          f"{len({i['source'] for i in unique})} file(s)")
    print(f"\nwrote:    {OUT.relative_to(REPO)}")
    print(f"evidence: {EVIDENCE.relative_to(REPO)}")
    print()
    print("=" * 68)
    print("VERDICT: V16_INPUTS_COLLECTED")
    print("=" * 68)
    print("An index, not a decision list. Several items are alternatives "
          "v1.6 must choose between.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
