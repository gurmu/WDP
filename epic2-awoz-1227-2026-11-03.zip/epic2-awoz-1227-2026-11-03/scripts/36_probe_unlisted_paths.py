#!/usr/bin/env python3
"""Does route X still refuse what it is supposed to refuse?

E2 Task 2.3 / Task 2.4 | B-48 | B-50 | PC-2 | PC-4 | RF-5 | AC1, AC2
CONOPS 2.3.2 ("Routes not listed are denied"), 3.2

WHY THIS EXISTS
---------------
T-01 measures the perimeter being PERMISSIVE: every listed protocol path
returns 200 through the edge with a body identical to the direct read.
On 2026-10-27 it went green at 3/4 after B-50 was fixed.

That is one half of the claim and the less important half. A whitelist
that admits everything would also make T-01 green. The repository's own
rule is that a perimeter test which never observes the perimeter ABSENT
is measuring the wrong thing -- so until an unlisted path is measured
being refused, B-48 is not closed, it is only untested in the other
direction.

The need is sharper after B-50. Before the fix the whitelist was a list
of literals that matched almost nothing, so it refused nearly every
path, and "can it refuse?" was not a question. The fix replaced each
path parameter with `*`. Whether `*` in this installation's Ant matcher
stays inside one segment -- rather than behaving like `**` -- is the
property the entire translation rests on, and it has never been
measured. If `*` crossed `/`, the whitelist would be far more
permissive than it reads, T-01 would still be green, and nothing in the
suite would say a word.

WHAT IS PROBED, AND WHY EACH ONE
--------------------------------
Every probe runs against the EDGE, on a context path that is deployed,
with a credential proven live in the same run.

  1-2  /api/2.0/token/list, /api/2.0/clusters/list
       The exact family measured reaching through on the AI route before
       route X existed (B-48). The sharing routes never showed it
       because their endpoint target carries a deep base path, so a
       stray path is APPENDED and the upstream 404s -- confinement by
       string concatenation, one target edit from being gone.

  3    S10's temporary-table-credentials path
       MEASURED ABSENT from the sharing endpoint by scripts/33, so it is
       deliberately EXCLUDED from the whitelist. A 403 here shows the
       exclusion is real and the refusal is the EDGE's. A 404 would mean
       it was forwarded and the upstream declined -- which is the
       reading PC-2 warns about, where a catch-all refusal and an absent
       path look identical from outside.

  4    /iceberg/v1/config
       RF-5, now route S11, an explicit deny. The rewritten credential's
       `icebergEndpoint` points at this family, so it is reachable by a
       client that follows the credential rather than the documentation.

  5    .../tables/{table}/metadata/extra
       THE DEPTH CHECK. `/shares/*/schemas/*/tables/*/metadata` is
       whitelisted. One segment deeper must be refused, or `*` is
       crossing `/` and the translation in
       scripts/lib/terminal_allow_list.py is wrong in the permissive
       direction. This is the single most important row here.

  6    /shares/{share}/schemas/{schema}/views
       The sibling check. `.../schemas/*/tables` is whitelisted; a
       different literal tail at the same depth must not be.

  7    POST-only path reached with GET
       The whitelist carries `methods` per entry, derived from each
       flow's selector. Nothing has ever measured whether that field
       constrains anything. S8's query path is whitelisted for POST; a
       GET to it must be refused.

HOW AN ANSWER IS ATTRIBUTED
---------------------------
By the BODY, not the status. The first version of this probe read 403 as
"the edge refused" from the status code alone, which is wrong for a
reason this repository has already measured: Databricks also answers 403
when the caller's address is not on a recipient's IP access list -- that
is precisely the t02-iplist row in T-01. A status-only reading would
have credited route X with a refusal the platform made, which is B-44.

So attribution rests on the responder's own voice:

  resource-filtering's default strings, MEASURED on this installation
  (CE 4.12.23) on 2026-10-27:
      403 "You're not allowed to access this resource"
            -> the path matched no whitelist entry
      405 "Method not allowed while accessing this resource"
            -> the path DID match an entry and the method was not in
               that entry's `methods` list

  A JSON body carrying `errorCode` is Delta Sharing's shape, so the
  request was FORWARDED and the upstream answered.

  Anything else is recorded as unattributed rather than forced into a
  bucket.

The 405 case is worth reading twice. It is a refusal, and it is also
evidence the TRANSLATION works: a 405 means the Ant pattern matched the
live path, because a pattern that did not match would have produced the
403 instead. That is confirmation of the B-50 fix at the pattern level
rather than only end-to-end through T-01. It also settles something
nothing had measured -- whether the per-entry `methods` field
constrains anything. It does.

THE LIMIT THIS PROBE CANNOT CLOSE
---------------------------------
Task 2.3's Verify line asks that "an unlisted path returns the protocol
error format and not a Gravitee 404". This probe can settle the second
half and NOT the first. `resource-filtering` has four configuration
properties -- whitelist, blacklist, normalizeRequestPath,
decodeEncodedSlash -- and no message, body or status field, and a
response-phase carrier does not run after an interrupting policy
(measured, scripts/35, recorded as PC-4). So the refusal is a reasonless
403. Closing Task 2.3 on this probe means closing it with that half
stated as an accepted limit, not quietly.
"""

import importlib.util
import json
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
SECRETS = REPO / "_secrets"
FAMILY = REPO / "gravitee" / "generated" / "route-family.json"
EVIDENCE = REPO / "evidence" / "unlisted-path-probe.json"

# Reuse scripts/33's credential handling rather than writing a fourth
# copy of it. Restating is B-39, which has cost six defects here, and
# pick_live_profile() in particular encodes something learned the hard
# way: psp7-demo-recipient's token has a 24-hour window set at birth, so
# a probe that selects a credential by NAME is asserting something it
# has not checked.
def _load(filename, modname):
    spec = importlib.util.spec_from_file_location(
        modname, REPO / "scripts" / filename)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[modname] = mod
    spec.loader.exec_module(mod)
    return mod


P33 = _load("33_probe_s10_path.py", "p36_p33")
call = P33.call
parse_json = P33.parse_json
load_profiles = P33.load_profiles
pick_live_profile = P33.pick_live_profile

# The tightest spike-arrest on the family is 1 request/second (class C).
# T-01 tripped its own throttle on 2026-10-27 and reported the 429 as a
# policy refusal, which is the measuring instrument producing the
# finding. 1.1s clears every class with margin.
PACE = 1.1


def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def load_env():
    env = REPO / ".env"
    if not env.exists():
        sys.exit(f"Missing {env}.")
    for line in env.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        if not v.strip():
            continue
        os.environ.setdefault(k, v)


def edge_base():
    """The gateway's own base, never the Delta Sharing path on it.

    GRAVITEE_GATEWAY_EDGE_URL in .env has carried a trailing
    /delta-sharing in the past, which would prefix every probe with a
    path that is itself a route and make every result meaningless.
    """
    explicit = os.environ.get("GRAVITEE_EDGE_BASE")
    if explicit:
        return explicit.rstrip("/"), "ENV_EXPLICIT"
    raw = os.environ.get("GRAVITEE_GATEWAY_EDGE_URL",
                         "http://localhost:8082").rstrip("/")
    for tail in ("/delta-sharing", "/opensharing-demo"):
        if raw.endswith(tail):
            return raw[:-len(tail)], f"ENV_STRIPPED_{tail}"
    return raw, "ENV_AS_IS"


# resource-filtering's own default response strings, read off this
# installation on 2026-10-27 rather than taken from documentation. The
# value is the failure mode each one reports.
EDGE_VOICE = {
    "You're not allowed to access this resource": "PATH_NOT_WHITELISTED",
    "Method not allowed while accessing this resource":
        "METHOD_NOT_IN_WHITELIST_ENTRY",
}


def attribute(status, body):
    """Who answered, and what that means for the perimeter.

    Decided on the body, because 403 alone does not identify the
    responder -- Databricks returns 403 for an address that is not on a
    recipient's IP access list. See the module docstring.
    """
    text = (body or "").strip().strip('"')
    if text in EDGE_VOICE:
        mode = EDGE_VOICE[text]
        if mode == "METHOD_NOT_IN_WHITELIST_ENTRY":
            return ("EDGE_REFUSED_METHOD", True,
                    "The edge refused, in resource-filtering's own voice, "
                    "because the method is not in the matched entry's "
                    "`methods` list. Note what this ALSO shows: the Ant "
                    "pattern MATCHED the live path, or the answer would "
                    "have been the path-not-whitelisted 403. So the "
                    "per-entry `methods` field constrains, and the B-50 "
                    "translation is confirmed at the pattern level.")
        return ("EDGE_REFUSED_PATH", True,
                "The edge refused, in resource-filtering's own voice: the "
                "path matched no whitelist entry. The 403 carries no "
                "reason and cannot (PC-4).")
    doc, _ = parse_json(body, "response")
    if isinstance(doc, dict) and doc.get("errorCode"):
        return (f"FORWARDED_UPSTREAM_{status}", False,
                "FORWARDED. The body is Delta Sharing's shape, carrying "
                "errorCode, so the edge let this path through and the "
                "UPSTREAM answered. Whatever stopped it was not route X; "
                "on the sharing routes a stray path is appended to a deep "
                "base path and misses, which is confinement by string "
                "concatenation rather than a decision -- B-48 exactly.")
    if status == 200:
        return ("FORWARDED_AND_SUCCEEDED", False,
                "FORWARDED AND IT WORKED. An unlisted path reached the "
                "platform and returned data. The worst outcome available.")
    if status == 429:
        return ("CANNOT_SEE_THROTTLED", None,
                "429 is the gateway declining to ask the question, not an "
                "answer about whether the path is permitted. Re-run.")
    if status is None:
        return ("CANNOT_SEE_TRANSPORT_ERROR", None,
                "No answer reached this probe, so nothing was observed.")
    return (f"CANNOT_SEE_UNATTRIBUTED_{status}", None,
            "Neither the edge's measured voice nor an upstream errorCode "
            "body, so WHO refused is unknown. Recorded rather than forced "
            "into a bucket: a verdict naming a component the evidence "
            "never reached is B-44. Add the string to EDGE_VOICE only "
            "after confirming it is the gateway's.")


def control(prefix, token, label):
    """GET /shares through the edge. Must be 200 or nothing else counts."""
    st, raw = call(prefix, token, "/shares", "GET", timeout=60)
    ok = st == 200
    print(f"    control ({label}) /shares -> {st}  "
          f"{'OK' if ok else 'NO CONTROL'}")
    return {"when": label, "status": st, "ok": ok,
            "body_head": (raw or "")[:200]}


def main():
    load_env()
    base, base_how = edge_base()

    print("=" * 68)
    print("Unlisted-path probe: does route X still refuse?")
    print("E2 Task 2.3 / 2.4 | B-48, B-50, PC-2, PC-4, RF-5")
    print("=" * 68)
    print()

    if not FAMILY.exists():
        sys.exit(f"Missing {FAMILY}. Run scripts/29 first.")
    family = json.loads(FAMILY.read_text())
    members = family.get("family") or []
    if not members:
        sys.exit(f"{FAMILY} names no members under 'family'.")

    print(f"edge base:   {base}  ({base_how})")

    print("\nselecting a live credential:")
    profiles = load_profiles()
    live, tried = pick_live_profile(profiles)
    if not live:
        print("\nVERDICT: CANNOT_SEE_NO_LIVE_CREDENTIAL")
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps(
            {"at": now(), "verdict": "CANNOT_SEE_NO_LIVE_CREDENTIAL",
             "credentials_tried": tried}, indent=2))
        return 1
    cred_name, direct_endpoint, token = live

    # Which member does this credential belong to? Matched on the
    # credential filename rather than assumed, because the whole point
    # of T-01b is that the host is bound to the recipient.
    member = None
    for m in members:
        slug = m.get("slug") or ""
        recip = m.get("recipient") or ""
        if (slug and slug in cred_name) or (recip and recip in cred_name):
            member = m
            break
    if member is None:
        print(f"\nVERDICT: CANNOT_SEE_CREDENTIAL_NOT_IN_FAMILY")
        print(f"  {cred_name} matches no member of {FAMILY.name}, so the "
              f"edge path to probe is unknown.")
        return 1

    prefix = base + member["edge_path"]
    print(f"credential:  {cred_name}")
    print(f"edge path:   {member['edge_path']}")
    print(f"probing:     {prefix}")

    # Real names, discovered against the DIRECT endpoint. A probe built
    # on invented share/schema/table names would be refused for the
    # wrong reason and the result would say nothing about route X.
    print("\ndiscovering real share/schema/table names (direct):")
    triple, disc_err = P33.discover(direct_endpoint, token)
    if not triple or not all(triple):
        print("\nVERDICT: CANNOT_SEE_NO_DISCOVERY")
        print(f"  {disc_err or f'discovery returned {triple!r}'}")
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps(
            {"at": now(), "verdict": "CANNOT_SEE_NO_DISCOVERY",
             "why": disc_err, "credential": cred_name}, indent=2))
        return 1
    share, schema, table = triple
    print(f"    share={share}  schema={schema}  table={table}")

    tbl = f"/shares/{share}/schemas/{schema}/tables/{table}"
    probes = [
        {"id": "U1", "method": "GET", "path": "/api/2.0/token/list",
         "because": "B-48's measured reach-through family on the AI route"},
        {"id": "U2", "method": "GET", "path": "/api/2.0/clusters/list",
         "because": "same family, second path"},
        {"id": "U3", "method": "POST",
         "path": f"{tbl}/temporary-table-credentials",
         "because": "S10, deliberately excluded from the whitelist (PC-2)"},
        {"id": "U4", "method": "GET", "path": "/iceberg/v1/config",
         "because": "RF-5 / S11 explicit deny; the credential's "
                    "icebergEndpoint points at this family"},
        {"id": "U5", "method": "GET", "path": f"{tbl}/metadata/extra",
         "because": "DEPTH: one segment below a whitelisted path. Refusal "
                    "here is what proves `*` does not cross `/`"},
        {"id": "U6", "method": "GET",
         "path": f"/shares/{share}/schemas/{schema}/views",
         "because": "SIBLING: a different literal tail at a whitelisted "
                    "depth"},
        {"id": "U7", "method": "GET", "path": f"{tbl}/query",
         "because": "METHOD: whitelisted for POST only. Tests whether the "
                    "per-entry `methods` field constrains anything"},
    ]

    print("\n--- control before")
    ctl_before = control(prefix, token, "before")

    rows = []
    print("\n--- unlisted paths (each expected to be REFUSED BY THE EDGE)")
    for p in probes:
        time.sleep(PACE)
        st, raw = call(prefix, token, p["path"], p["method"], timeout=60)
        label, refused, why = attribute(st, raw)
        doc, _ = parse_json(raw, p["id"])
        rows.append({**p, "status": st, "attribution": label,
                     "refused_by_the_edge": refused, "why": why,
                     "body_head": (raw or "")[:300],
                     "upstream_error_code": (doc or {}).get("errorCode")})
        mark = {True: "REFUSED", False: "LET THROUGH",
                None: "CANNOT SEE"}[refused]
        print(f"    {p['id']}  {p['method']:<4} {st!s:<5} {label:<28} {mark}")

    print("\n--- control after")
    time.sleep(PACE)
    ctl_after = control(prefix, token, "after")

    # ------------------------------------------------------------------
    # Verdict. Worst-first, because a perimeter is graded by what it lets
    # through, not by what it stops.
    # ------------------------------------------------------------------
    if not (ctl_before["ok"] and ctl_after["ok"]):
        verdict = "CANNOT_SEE_NO_CONTROL"
        why = ("The same route did not return 200 before and after, so a "
               "refusal on an unlisted path is not attributable to the "
               "allow-list. B-40, in both directions: this is the shape "
               "T-03 uses and the reason it arms and then restores.")
    elif any(r["refused_by_the_edge"] is False for r in rows):
        through = [r["id"] for r in rows if r["refused_by_the_edge"] is False]
        verdict = "PERIMETER_LETS_UNLISTED_PATHS_THROUGH"
        why = (f"{', '.join(through)} were forwarded rather than refused. "
               f"Whatever stopped them was not route X.")
    elif any(r["refused_by_the_edge"] is None for r in rows):
        unseen = [r["id"] for r in rows if r["refused_by_the_edge"] is None]
        verdict = "PARTIAL_SOME_PROBES_OBSERVED_NOTHING"
        why = (f"{', '.join(unseen)} returned no attributable answer. The "
               f"rest were refused at the edge.")
    else:
        verdict = "PERIMETER_REFUSES_EVERY_UNLISTED_PATH_PROBED"
        why = ("Every probed unlisted path was refused by the edge, with "
               "the same route returning 200 immediately before and "
               "after. Depth (U5), sibling (U6) and method (U7) all held, "
               "so `*` stays inside one path segment and the per-entry "
               "`methods` field constrains. This is the half of B-48 that "
               "T-01 cannot see.")

    out = {
        "at": now(),
        "probe": "scripts/36_probe_unlisted_paths.py",
        "verdict": verdict,
        "why": why,
        "edge_base": base,
        "edge_base_resolution": base_how,
        "edge_path": member["edge_path"],
        "credential": cred_name,
        "credentials_tried": tried,
        "discovered": {"share": share, "schema": schema, "table": table},
        "control_before": ctl_before,
        "control_after": ctl_after,
        "probes": rows,
        "accepted_limit": (
            "Task 2.3's Verify asks for 'the protocol error format and "
            "not a Gravitee 404'. This probe settles the second half "
            "only. resource-filtering has no message, body or status "
            "field and a response-phase carrier does not run after an "
            "interrupting policy (PC-4, measured by scripts/35), so the "
            "refusal is a reasonless 403. Task 2.3 closes with that "
            "stated, not with it quietly dropped."),
        "what_this_does_not_show": (
            "Seven paths were probed, not every unlisted path. A "
            "whitelist is fail-closed by construction, so the argument "
            "for the rest is structural rather than measured -- and the "
            "structural argument is only as good as the Ant semantics "
            "U5 tests. If U5 ever flips, every untested path flips with "
            "it."),
    }
    EVIDENCE.parent.mkdir(exist_ok=True)
    EVIDENCE.write_text(json.dumps(out, indent=2))
    try:
        EVIDENCE.chmod(0o600)
    except OSError:
        pass

    print(f"\nWrote evidence: {EVIDENCE.relative_to(REPO)}  [0600]")
    print()
    print("=" * 68)
    print(f"VERDICT: {verdict}")
    print("=" * 68)
    print(why)
    return 0 if verdict == "PERIMETER_REFUSES_EVERY_UNLISTED_PATH_PROBED" else 1


if __name__ == "__main__":
    sys.exit(main())
