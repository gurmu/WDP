#!/usr/bin/env python3
"""E2 Task 2.4 / PC-4 / RF-1: which policy can be route X's terminal deny?

iac/config/policy-classes.yaml records PC-4: "The terminal-deny policy
shape is unconfirmed on this installation", with the consequence "the
deny class emits with `generated: false`". gravitee/generated/
route-family.json records the same thing as RF-1, and adds the sentence
that matters:

    "Unmatched paths fail closed because nothing matches them -- right
     outcome, by accident not decision."

That is the whole of B-48 in miniature. A path is refused because no
flow claims it, not because a flow refuses it, so there is no record of
a decision and nothing to point an auditor at. §2.3.2 asks for more than
a refusal: "Everything else -- not forwarded -- denied in the protocol
error format (errorCode, message)."

WHAT ROUTE X ACTUALLY NEEDS, AND WHY IT IS TWO REQUIREMENTS
-----------------------------------------------------------
  1. It must REFUSE, and fail CLOSED when its own configuration is
     wrong. docs/11 AI-9 is the precedent: the `mock` policy was the
     reason-carrier and it fails OPEN -- the empty-`rules` deny shipped
     as a working control with an open proxy behind it. The enforcer
     must be the policy whose failure mode is refusal.
  2. It must emit a BODY in the protocol's shape. A reasonless 403 is
     what the terminal allow-list already gives on the AI route, and
     AI-9 records the cost: the caller is told nothing, and M3's stated
     reason never arrives.

Those two may not live in the same policy. If they do not, route X is a
PAIR -- an enforcer that fails closed, plus a response transformation
that dresses its refusal -- and the ORDER matters, because whichever
answers first is the one the caller sees. This probe reports which
policies exist and what each one's schema can actually set, so that
choice is made from the installation's own schemas rather than from
Gravitee's documentation, which policy-classes.yaml already notes can
differ: "A policy id that is right in Gravitee's documentation and wrong
in 4.12.23 imports as an API with a silently missing policy -- the API
starts, returns 200, and enforces nothing."

This probe makes no change. It reads schemas and writes evidence.
"""
import json
import os
import sys
import urllib.error
import urllib.request
from base64 import b64encode
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
EVIDENCE = REPO / "evidence" / "deny-policy-probe.json"

# Candidates, with what each is being asked to do. A candidate list
# without a reason per entry is a list of guesses.
# (id, why it is asked about, failure mode when its own config is wrong)
#
# The failure mode is carried per candidate and is NOT inferred from the
# schema, because it cannot be: a schema says what a policy accepts, not
# what it does when the policy is absent or its expression does not
# match. Both values below marked _MEASURED come from docs/11 AI-9 and
# AI-10, where they were observed rather than assumed.
CANDIDATES = [
    ("resource-filtering",
     "already the terminal allow-list on the AI route. Refuses with no "
     "body (AI-9).", "CLOSED_MEASURED"),
    ("mock",
     "emits a status and a body, which is what the protocol error format "
     "needs -- but it is the reason-carrier that shipped as a no-op deny "
     "(AI-9).", "OPEN_MEASURED"),
    ("request-validation",
     "refuses on a rule; may allow a custom status and payload.",
     "UNKNOWN"),
    ("transform-headers",
     "already used for T-07; listed to confirm it cannot set a body.",
     "UNKNOWN"),
    ("policy-assign-content",
     "response-body assignment, if present on this install.", "UNKNOWN"),
    ("json-validation",
     "already class B's validator; its error body is configurable, which "
     "is the capability route X needs.", "UNKNOWN"),
    ("groovy",
     "last resort: can set status and body, at the cost of a script in "
     "the perimeter. Recorded so the trade-off is explicit.", "UNKNOWN"),
]

# Schema field names that indicate the capability being asked about.
#
# "response" was in BODY_HINTS in the first version and matched
# json-validation's `responseStatusCode`, which is a STATUS field -- so
# the probe reported a policy as body-capable on the strength of a
# substring. A key that matches a status hint is therefore never also
# counted as a body field. The looser hint is gone: a probe that
# over-reports a capability is worse than one that misses it, because
# the over-report is what gets built on.
STATUS_HINTS = ("status", "statuscode", "httpstatus", "responsestatus")
BODY_HINTS = ("body", "content", "payload")


def require_env(name, what):
    val = (os.environ.get(name) or "").strip()
    if not val:
        raise SystemExit(
            f"Refusing to run: ${name} is unset.\n  It names {what}.\n"
            "  No default: a default would probe a gateway you did not "
            "choose and report its schemas as yours.")
    return val


def load_env():
    env = REPO / ".env"
    if not env.exists():
        raise SystemExit(f"Missing {env}.")
    for line in env.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        if v.strip():
            os.environ.setdefault(k, v)


def get(url, auth, timeout=30):
    req = urllib.request.Request(url, headers={"Authorization": auth})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read().decode(errors="replace")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode(errors="replace")
    except Exception as exc:  # noqa: BLE001
        return None, repr(exc)


def walk_keys(node, out):
    """Every property name anywhere in a JSON schema, lowercased."""
    if isinstance(node, dict):
        for k, v in node.items():
            if k == "properties" and isinstance(v, dict):
                out.update(n.lower() for n in v)
            walk_keys(v, out)
    elif isinstance(node, list):
        for v in node:
            walk_keys(v, out)
    return out


def main():
    load_env()
    base_root = require_env(
        "GRAVITEE_MGMT_API_URL",
        "the Gravitee management API whose schemas are being read").rstrip("/")
    user = os.environ.get("GRAVITEE_MGMT_USER", "admin")
    pwd = os.environ.get("GRAVITEE_MGMT_PASSWORD", "admin")
    auth = "Basic " + b64encode(f"{user}:{pwd}".encode()).decode()
    envbase = (f"{base_root}/management/v2/organizations/DEFAULT"
               "/environments/DEFAULT")

    print("=" * 70)
    print("Terminal-deny policy probe -- E2 Task 2.4 / PC-4 / RF-1")
    print("=" * 70)
    print(f"target: {base_root}\n")

    # --- control: credentials and base URL, before anything else -------
    #
    # scripts/05 reaches /apis under exactly this base and has done for
    # weeks, so it is the one call that separates "wrong credentials or
    # wrong host" from "wrong catalogue path". The first version of this
    # probe had no such control: it guessed one catalogue path, got a
    # 500, and reported CANNOT_SEE_POLICY_CATALOGUE_UNREADABLE -- a
    # verdict that names the catalogue when the evidence did not reach
    # that far. Same shape as B-44, in my own tooling.
    st, _ = get(f"{envbase}/apis?perPage=1", auth)
    print(f"[control] GET .../environments/DEFAULT/apis -> {st}")
    if st != 200:
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps({
            "task": "E2 Task 2.4 / PC-4",
            "verdict": "CANNOT_SEE_MANAGEMENT_API_UNREACHABLE",
            "control_status": st,
            "what_this_does_not_prove": (
                "Nothing about any policy or any catalogue path. The "
                "management API itself did not answer on the base that "
                "scripts/05 uses, so this is credentials, host or a "
                "stopped stack."),
        }, indent=2) + "\n")
        print("\nVERDICT: CANNOT_SEE_MANAGEMENT_API_UNREACHABLE")
        print("The management API did not answer on the base scripts/05 "
              "uses. Check GRAVITEE_MGMT_API_URL and that the stack is up.")
        return 1
    print("          management API answers; credentials and base are "
          "right\n")

    # --- discover where this install keeps the plugin catalogue --------
    #
    # Gravitee moved plugin endpoints between 4.x minors, and
    # policy-classes.yaml already records the lesson for policy IDS: a
    # value that is right in the documentation and wrong in 4.12.23
    # produces an API that starts and enforces nothing. The same caution
    # applies to the endpoint that LISTS them, so the path is found
    # rather than assumed, and the one that worked is recorded.
    candidates = [
        ("v2 env-scoped", f"{envbase}/plugins/policies"),
        ("v2 org-scoped",
         f"{base_root}/management/v2/organizations/DEFAULT/plugins/policies"),
        ("v2 root", f"{base_root}/management/v2/plugins/policies"),
        ("v2 root, typed",
         f"{base_root}/management/v2/plugins?type=POLICY"),
        ("v1 env-scoped",
         f"{base_root}/management/organizations/DEFAULT"
         "/environments/DEFAULT/policies"),
    ]
    print("locating the policy catalogue:")
    cat_url, body, tried = None, None, []
    for label, url in candidates:
        st, b = get(url, auth)
        tried.append({"label": label, "url": url.replace(base_root, ""),
                      "status": st,
                      "body_head": (b or "")[:160] if st != 200 else None})
        print(f"  {label:<18} {str(st):<6} {url.replace(base_root, '')}")
        if st == 200:
            cat_url, body = url, b
            break
    if cat_url is None:
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps({
            "task": "E2 Task 2.4 / PC-4",
            "verdict": "CANNOT_SEE_NO_CATALOGUE_PATH_ANSWERED",
            "management_api_control": "PASSED",
            "paths_tried": tried,
            "what_this_does_not_prove": (
                "Nothing about any policy. The management API answers, so "
                "this is the catalogue path alone. The body_head of each "
                "refusal is recorded so the next attempt starts from what "
                "the server said rather than from another guess."),
        }, indent=2) + "\n")
        print("\nVERDICT: CANNOT_SEE_NO_CATALOGUE_PATH_ANSWERED")
        print("The management API answers but no candidate catalogue path "
              "did. See evidence for what each returned.")
        return 1
    print(f"  -> using {cat_url.replace(base_root, '')}\n")

    try:
        catalogue = json.loads(body)
    except ValueError:
        catalogue = []
    installed = sorted({
        p.get("id") for p in (
            catalogue.get("data") if isinstance(catalogue, dict) else catalogue
        ) or [] if isinstance(p, dict) and p.get("id")
    })
    print(f"[control] policy catalogue readable -- {len(installed)} policies "
          "installed\n")

    results = []
    for pid, why, failure_mode in CANDIDATES:
        present = pid in installed
        row = {"policy": pid, "asked_because": why,
               "failure_mode_when_misconfigured": failure_mode,
               "installed": present}
        if not present:
            row["verdict"] = "NOT_INSTALLED"
            print(f"[{pid}]\n    NOT INSTALLED on this gateway")
            results.append(row)
            continue
        st, sch = get(f"{cat_url}/{pid}/schema", auth)
        row["schema_status"] = st
        if st != 200:
            row["verdict"] = f"SCHEMA_UNREADABLE_{st}"
            print(f"[{pid}]\n    installed, schema -> {st}")
            results.append(row)
            continue
        try:
            parsed = json.loads(sch)
            keys = sorted(walk_keys(parsed, set()))
            # The full schema, not just its property names. Property
            # names say a policy CAN set a body; they do not say what
            # shape the config takes, and a flow cannot be written from
            # a list of nouns. policy-classes.yaml already records that
            # every field name in it was "confirmed against THIS
            # installation's own schema endpoints" -- this is that
            # confirmation kept rather than summarised away.
            row["schema"] = parsed
        except ValueError:
            keys = []
            parsed = None
            row["schema_not_json"] = (sch or "")[:200]
        can_status = [k for k in keys if any(h in k for h in STATUS_HINTS)]
        can_body = [k for k in keys
                    if any(h in k for h in BODY_HINTS) and k not in can_status]
        row.update({
            "schema_properties": keys,
            "can_set_status": can_status,
            "can_set_body": can_body,
            "verdict": ("CAN_SET_STATUS_AND_BODY" if can_status and can_body
                        else "CAN_SET_STATUS_ONLY" if can_status
                        else "CAN_SET_BODY_ONLY" if can_body
                        else "NEITHER_STATUS_NOR_BODY"),
        })
        print(f"[{pid}]\n    installed, schema 200, {len(keys)} properties")
        print(f"    status fields: {can_status or 'none'}")
        print(f"    body fields:   {can_body or 'none'}")
        print(f"    -> {row['verdict']}")
        results.append(row)

    both = [r for r in results
            if r.get("verdict") == "CAN_SET_STATUS_AND_BODY"]
    record = {
        "task": "E2 Task 2.4 / PC-4 / RF-1",
        "settles": "iac/config/policy-classes.yaml PC-4; "
                   "gravitee/generated/route-family.json RF-1",
        "target": base_root,
        "catalogue_url": cat_url.replace(base_root, ""),
        "catalogue_paths_tried": tried,
        "policies_installed": len(installed),
        "candidates": results,
        "what_this_does_not_prove": (
            "A schema is not a behaviour. That a policy DECLARES a status "
            "and a body field does not establish that it refuses, that it "
            "fails closed when misconfigured, or that it is reached before "
            "a narrower flow. Those are the next three questions and each "
            "needs a run against a live route, with the control observed "
            "absent -- the policy switched off and the path seen to open "
            "again, as T-16 does for the AI route's allow-list."),
    }
    # A policy that can set a status and a body is NOT thereby an
    # enforcer. The first version of this probe recommended `mock` on
    # exactly that reasoning -- the policy AI-9 records as failing OPEN,
    # which is the no-op deny that shipped as a working control. So the
    # enforcer must be fail-closed, and "can emit the body" is a separate
    # question answered by a separate policy if necessary.
    fail_closed = [r for r in results
                   if r.get("failure_mode_when_misconfigured")
                   == "CLOSED_MEASURED" and r.get("installed")]
    enforcer = fail_closed[0] if fail_closed else None
    reason_carrier = [r for r in both
                      if not enforcer or r["policy"] != enforcer["policy"]]
    record["enforcer"] = {
        "policy": enforcer["policy"] if enforcer else None,
        "chosen_because": (
            "the only installed candidate whose failure mode is MEASURED "
            "as fail-closed. Capability to emit a body is deliberately "
            "not a criterion here: AI-9 is what happens when the "
            "reason-carrier is asked to be the enforcer."
            if enforcer else
            "NONE -- no installed candidate has a measured fail-closed "
            "mode. Do not build route X until one is established by "
            "switching a candidate off and watching the path reopen."),
    }
    record["reason_carrier_candidates"] = [r["policy"] for r in reason_carrier]
    record["ordering_note"] = (
        "AI-9: whichever policy answers first is the one the caller sees. "
        "The enforcer fails closed and must answer; the reason-carrier "
        "fails open and must not be the only thing between a caller and "
        "the upstream. If route X is a pair, the enforcer is reached "
        "first and the carrier only dresses what it already refused. "
        "Note also B-48's second retraction: array position is not "
        "evaluation order -- Gravitee runs the most generic selector "
        "first, so route X's own ordering is a property of its selector, "
        "not of where it sits in the flows array.")
    record["verdict"] = (
        "DENY_SHAPE_AVAILABLE" if enforcer and both
        else "ENFORCER_AVAILABLE_BODY_NEEDS_A_SECOND_POLICY" if enforcer
        else "NO_MEASURED_FAIL_CLOSED_ENFORCER")

    EVIDENCE.parent.mkdir(exist_ok=True)
    EVIDENCE.write_text(json.dumps(record, indent=2) + "\n")
    print("\n" + "=" * 70)
    print(f"VERDICT: {record['verdict']}")
    print(f"Evidence: evidence/{EVIDENCE.name}")
    print("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(main())
