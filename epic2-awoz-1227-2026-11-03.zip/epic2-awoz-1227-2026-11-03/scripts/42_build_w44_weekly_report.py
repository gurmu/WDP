#!/usr/bin/env python3
"""Build reports/2026-W44-weekly-report.docx -- Epic 2 (T04-11, AC2).

Same shape as scripts/40 and for the same reason: a report nobody can
regenerate is a report nobody can correct. Week 43's figures were revised
four times.

This one goes further in one respect. Every FIGURE it prints is read out
of the evidence files at build time -- gate counts, test verdicts, how
many §3.2 rows carry an observation -- and the narrative around them is
the only part written by hand. If a figure cannot be read, the report
says so in the cell rather than carrying a number nobody can trace. That
is the difference between a status report and a status claim.

The docx helpers are duplicated from scripts/40 on purpose rather than
shared through scripts/lib/. A report that has been issued should not
change because a shared helper changed next month; each week's builder
owns its own formatting.

Verify after running:
    soffice --headless --convert-to pdf --outdir /tmp \\
        reports/2026-W44-weekly-report.docx
    pdfinfo /tmp/2026-W44-weekly-report.pdf | grep Pages    # expect: 2
"""

import json
import re
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "reports" / "2026-W44-weekly-report.docx"

ACCENT = RGBColor(0x1F, 0x3B, 0x5C)
RED = RGBColor(0x9B, 0x22, 0x26)
MUTED = RGBColor(0x5A, 0x5A, 0x5A)
LABEL_FILL = "EEF2F7"
ALERT_FILL = "FBECEC"


# --------------------------------------------------------------------------
# Figures, read rather than typed
# --------------------------------------------------------------------------
UNREAD = "[unreadable -- see the evidence file]"


def ev(rel):
    f = ROOT / rel
    if not f.is_file():
        return None
    try:
        return json.loads(f.read_text())
    except json.JSONDecodeError:
        return None


def test_state(rel):
    """(label, verdict) with CANNOT_SEE kept as a third state (B-46)."""
    doc = ev(rel)
    if doc is None:
        return UNREAD, UNREAD
    rows = doc if isinstance(doc, list) else [doc]
    rows = [r for r in rows if isinstance(r, dict)]
    if not rows:
        return UNREAD, UNREAD
    unseen = [r for r in rows
              if str(r.get("actual", "")).upper().startswith("CANNOT_SEE")]
    failed = [r for r in rows if r.get("passed") is not True and r not in unseen]
    verdict = str(rows[-1].get("actual", UNREAD))
    if failed:
        return f"{len(failed)} of {len(rows)} FAILING", verdict
    if unseen:
        return f"{len(rows) - len(unseen)} of {len(rows)} pass, " \
               f"{len(unseen)} CANNOT_SEE", verdict
    return f"{len(rows)} of {len(rows)} pass", verdict


def cac_counts():
    """Total and failed static checks, however scripts/22 happens to
    record them. Returns a sentence, never an invented number."""
    doc = ev("evidence/cac-config-check.json")
    if doc is None:
        return UNREAD
    if isinstance(doc, dict):
        total = next((doc[k] for k in
                      ("check_count", "total", "checks", "total_checks",
                       "count") if isinstance(doc.get(k), int)), None)
        failed = next((doc[k] for k in
                       ("failed", "failures", "failed_count", "fail_count")
                       if isinstance(doc.get(k), int)), None)
        if total is None and isinstance(doc.get("checks"), list):
            total = len(doc["checks"])
            failed = sum(1 for c in doc["checks"]
                         if isinstance(c, dict) and c.get("ok") is False)
        if total is not None and failed is not None:
            v = doc.get("verdict")
            return (f"{total} checks / {failed} failed"
                    + (f" ({v})" if isinstance(v, str) else ""))
    if isinstance(doc, list):
        failed = sum(1 for c in doc if isinstance(c, dict) and c.get("ok") is False)
        return f"{len(doc)} checks / {failed} failed"
    return UNREAD


def hygiene_state():
    doc = ev("evidence/secret-hygiene.json")
    if not isinstance(doc, dict):
        return UNREAD
    clean = doc.get("clean")
    n = doc.get("files_scanned")
    at = str(doc.get("at", ""))[:10]
    if clean is True:
        return f"clean, {n} files scanned, last run {at}"
    return (f"NOT CLEAN -- {doc.get('violation_count', '?')} violation(s), "
            f"last run {at}")


def capability_rows():
    """How many of §3.2's seven rows carry an observation, counted from the
    package itself rather than asserted here."""
    f = ROOT / "docs" / "epics" / "E2-arb-package.md"
    if not f.is_file():
        return UNREAD
    # An earlier version counted bolded cells and got 7 of 7 -- because a
    # cell reading "**Not applicable until OD-5 decides.**" is bold and is
    # not an observation. No text heuristic can tell an observation from a
    # stated reason it cannot be answered, so read the sentence the package
    # maintains beside its own table. One origin; edit the package and this
    # follows it.
    m = re.search(r"\*\*Seven rows: (.+?)\.\*\*", f.read_text(), re.S)
    if not m:
        return UNREAD
    return " ".join(m.group(1).split())


def blockers_this_week():
    f = ROOT / "docs" / "11-environment-baseline.md"
    if not f.is_file():
        return UNREAD, UNREAD
    # Only the RANGE is derived. A count of "closed this week" is not:
    # not every closure is marked in its heading (B-50's is not), so a
    # derived count would read low and look authoritative. Where a figure
    # cannot be derived honestly, this report does not derive it.
    text = f.read_text()
    heads = re.findall(r"^### (B-\d+)\b", text, re.M)
    last = max((int(h.split("-")[1]) for h in heads), default=0)
    openers = [h for h in heads
               if re.search(rf"^### {h}\b[^\n]*\bOPEN\b", text, re.M)]
    return (f"B-1 to B-{last}",
            ("open: " + ", ".join(sorted(set(openers),
                                         key=lambda x: int(x.split("-")[1])))
             if openers else "none marked OPEN in a heading"))


# --------------------------------------------------------------------------
# docx helpers (duplicated from scripts/40 deliberately)
# --------------------------------------------------------------------------
def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    el = OxmlElement("w:shd")
    el.set(qn("w:val"), "clear")
    el.set(qn("w:fill"), fill)
    tcPr.append(el)


def fixed_grid(table, widths_in):
    table.autofit = False
    tblPr = table._tbl.tblPr
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tblPr.append(layout)
    grid = table._tbl.find(qn("w:tblGrid"))
    if grid is None:
        grid = OxmlElement("w:tblGrid")
        table._tbl.insert(1, grid)
    for gc in list(grid):
        grid.remove(gc)
    for w in widths_in:
        gc = OxmlElement("w:gridCol")
        gc.set(qn("w:w"), str(int(w * 1440)))
        grid.append(gc)
    for row in table.rows:
        for cell, w in zip(row.cells, widths_in):
            cell.width = Inches(w)


def run(p, text, *, size=10, bold=False, italic=False, color=None):
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.italic = italic
    if color is not None:
        r.font.color.rgb = color
    return r


def para(doc, *, before=0, after=4, spacing=1.08, align=None):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.line_spacing = spacing
    if align is not None:
        pf.alignment = align
    return p


def heading(doc, text):
    p = para(doc, before=9, after=3)
    run(p, text, size=11.5, bold=True, color=ACCENT)
    return p


def body(doc, text, **kw):
    p = para(doc, **kw)
    run(p, text)
    return p


def bullet(doc, lead, rest):
    p = doc.add_paragraph(style="List Bullet")
    pf = p.paragraph_format
    pf.space_after = Pt(3)
    pf.line_spacing = 1.06
    run(p, lead, bold=True)
    run(p, " " + rest)
    return p


def kv_table(doc, rows, *, widths=(1.05, 5.7), red_labels=()):
    t = doc.add_table(rows=0, cols=2)
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.LEFT
    for label, value in rows:
        cells = t.add_row().cells
        shade(cells[0], LABEL_FILL)
        lp = cells[0].paragraphs[0]
        lp.paragraph_format.space_after = Pt(1)
        lp.paragraph_format.line_spacing = 1.0
        run(lp, label, size=9.5, bold=True,
            color=RED if label in red_labels else ACCENT)
        vp = cells[1].paragraphs[0]
        vp.paragraph_format.space_after = Pt(1)
        vp.paragraph_format.line_spacing = 1.03
        run(vp, value, size=9.5)
    fixed_grid(t, list(widths))
    return t


# --------------------------------------------------------------------------
def build():
    t01_state, _t01_v = test_state("evidence/t01-report.json")
    t05_state, t05_v = test_state("evidence/t05-report.json")
    t07_state, _t07_v = test_state("evidence/t07-report.json")
    t24_state, _t24_v = test_state("evidence/t24-report.json")
    gates = cac_counts()
    hygiene = hygiene_state()
    caps = capability_rows()
    brange, bclosed = blockers_this_week()

    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Calibri"
    st.font.size = Pt(10)
    for s in doc.sections:
        s.top_margin = s.bottom_margin = Inches(0.7)
        s.left_margin = s.right_margin = Inches(0.85)

    p = para(doc, after=1)
    run(p, "Weekly Report — Week 44", size=19, bold=True, color=ACCENT)
    p = para(doc, after=1)
    run(p, "CONOPS AWOZ-1227 v1.5  ·  OpenSharing + Gravitee API Gateway"
           "  ·  INC17", size=10, color=MUTED)
    p = para(doc, after=8)
    run(p, "Week ending Friday 30 October 2026  ·  Epic 2 (T04-11, AC2)"
           "  ·  Prepared by the CONOPS owner", size=9, color=MUTED)

    # ---- action required ----
    t = doc.add_table(rows=1, cols=1)
    t.style = "Table Grid"
    cell = t.rows[0].cells[0]
    shade(cell, ALERT_FILL)
    cp = cell.paragraphs[0]
    cp.paragraph_format.space_after = Pt(2)
    cp.paragraph_format.line_spacing = 1.04
    run(cp, "Decision taken, and it needs leadership on the record. ",
        size=9.5, bold=True, color=RED)
    run(cp, "The milestone cannot be delivered from the client environment "
            "on the original schedule; the escalation is written. The "
            "commitment now standing is that the work is completed on "
            "COMPANY infrastructure for 20 December 2026 and migrated as a "
            "finished package, with the client-side remainder "
            "pre-registered so it drops in rather than being discovered. "
            "This week produced the register that makes that auditable — "
            "docs/15: eleven deferred items, each naming the client "
            "resource it waits on, and seven owed HERE before anything "
            "migrates. Separately, one credential from last week's "
            "exposure (the GitHub fine-grained token) still needs its "
            "rotation confirmed; the clobbered template is verified gone "
            "from disk.", size=9.5)
    fixed_grid(t, [6.75])
    para(doc, after=2)

    heading(doc, "The week in one paragraph")
    body(doc,
         "Epic 2 is closed on everything this environment can measure. Nine "
         "of twelve tasks closed outright, one closed on its measurable half, "
         "one is partial and one is deferred — each of the last three "
         "naming the client resource it waits on rather than carrying a "
         "status. The week's value is not the closures: it is that four "
         "controls which read green were found to be narrower than they "
         "read, and each was narrowed in writing instead of being left to be "
         "discovered by an ARB reviewer. The sharpest one arrived by "
         "accident on the last day — a throttle test captured a refusal "
         "whose headers carried the exact header this epic spent days "
         "removing, because a request-phase refusal never reaches the "
         "response phase that removes it.", after=5)

    heading(doc, "Status")
    kv_table(doc, [
        ("Tasks", "12 total. 9 closed; 2.6 closed on its edge half with "
                  "clause 2.5 deferred; 2.10 partial (injection confirmed, "
                  "serving endpoint deferred); 2.9 deferred."),
        ("AC2", "Four of five clauses evidenced. Clause 2.5 is measured in "
                "mechanism and NOT in claim — both throttles fire and "
                "clear where configured, and nothing shows the edge tripping "
                "BEFORE Databricks. That needs system.access.audit."),
        ("§3.2 table", "Against CE 4.12.23: " + caps
                        + ". Two cells moved this week."),
        ("Tests", f"T-01 {t01_state}. T-05 {t05_state} — {t05_v}. "
                  f"T-07 {t07_state}. T-24 {t24_state}."),
        ("Gates", f"Config consistency {gates}. Secret hygiene: {hygiene}."),
        ("Blockers", f"Register now spans {brange} ({bclosed}). Recorded "
                     f"this week: a whitelist written in the wrong pattern "
                     f"language and then the wrong scope; three gateway "
                     f"headers no policy could remove; the gateway "
                     f"reporting nothing with no test asking; forwarded "
                     f"path traversal; and B-55."),
        ("Deliverable", "A migration bundle builder that refuses to write an "
                        "archive when a task declared closed cites evidence "
                        "that could not see."),
    ])

    heading(doc, "What moved")
    bullet(doc, "The throttle is measured, and it is not the shape the "
                "document describes.",
           "The gateway's own refusal body says it: a limit configured as "
           "5 per second is enforced as 1 per 200 ms. Ten requests inside "
           "0.2s produced one 200 and nine 429s, first refusal at request "
           "TWO rather than six. Five requests spread across a second pass; "
           "the same five inside 100 ms do not. The per-minute limit, by "
           "contrast, trips exactly at request 61. Neither 429 carries any "
           "retry indication — no Retry-After, no rate-limit header — "
           "so the reference clients need a backoff of their own and v1.6 "
           "must say so rather than implying the gateway tells them.")
    bullet(doc, "Header sanitization was found to cover successes only.",
           "B-55. The remove-list works and the step that applies it runs "
           "in the response phase, which a request-phase refusal never "
           "reaches — so every 400, 405, 409, 413, 415 and 429 the "
           "perimeter raises goes out unsanitized, while refusals from "
           "Databricks are sanitized normally. What leaks is a product name "
           "and an opaque caller id: low severity, and the correction is to "
           "the CLAIM, which read total. The test's reasoning was sound and "
           "its sample was one-sided — every probe drove a successful "
           "read. A phase that measures refusals is now committed.")
    bullet(doc, "Path traversal was being forwarded to Databricks, and the "
                "401 that came back proved nothing.",
           "B-54, found and fixed the same afternoon by the test written to "
           "look for it. Two of three traversal forms reached the upstream. "
           "Databricks checks the credential before resolving the path, so "
           "the 401 says only \"no credential\" — the escape was "
           "unmeasurable while nothing authenticates, which is exactly the "
           "state in which it looks harmless. Fixed with a character "
           "allow-list rather than a deny list of escapes, which covers the "
           "double-encoded form nobody had thought of.")
    bullet(doc, "Two requirements were found to have been enforced by nothing.",
           "§2.3.3's metadata-only logging sat unimplemented with no "
           "test failing, because no test asked the gateway whether it "
           "reported (B-53); route X's whitelist shipped twice in the wrong "
           "pattern language and then the wrong scope (B-50). A requirement "
           "nothing tests is a requirement nothing enforces.")

    heading(doc, "What leadership needs from this week")
    for lead, rest in [
        ("Acknowledge the company-side delivery commitment and the register "
         "behind it.",
         "docs/15's second list — what is owed HERE before migration "
         "— is the one that matters: it exists so the deferred list "
         "cannot become a parking space."),
        ("Chase one resource ahead of all others: system.access.audit.",
         "It is the only thing standing between AC2 clause 2.5 and an "
         "evidenced claim, and clause 2.5 is the compute-protection "
         "argument the ARB will ask about first. Everything else deferred "
         "this week is a capability we can describe; this one is a sentence "
         "we cannot write."),
        ("Note that OD-1 is recommended for deferral, not decision.",
         "T-08 is not runnable here: F1's upstream host exists only inside "
         "a pre-signed URL and Free Edition storage is Databricks-managed, "
         "so neither half of the test has a subject. Option (b) is the "
         "working assumption — the only branch not depending on a "
         "rewrite nobody has demonstrated."),
        ("One credential still needs its rotation confirmed.",
         "Two Databricks tokens and the open-source provider token were "
         "rotated. The GitHub fine-grained token from the same exposure has "
         "not been confirmed rotated. The clobbered template is verified "
         "gone from disk; that is containment, not rotation."),
    ]:
        p = para(doc, after=3, spacing=1.06)
        run(p, lead, bold=True)
        run(p, " " + rest)

    heading(doc, "Carried into next week")
    kv_table(doc, [
        ("Open red", "B-55. Header sanitization does not reach perimeter "
                     "refusals. Not fixable by a policy; needs a gateway "
                     "setting or a component in front of the gateway. Same "
                     "owner as the response-header allow-list, which is "
                     "likewise enforced by the test rather than the gateway."),
        ("Blocking", "The perimeter tests must be re-run on refreshed "
                     "credentials before the bundle is built. T-01's last "
                     f"run reads {t01_state} — two credentials had "
                     "expired and one check found the edge forwarding to the "
                     "wrong upstream. A bundle built today would ship that "
                     "behind a sentence reading as though the control was "
                     "measured, so the builder refuses. docs/15 item P-7."),
        ("Watch", "Recipient tokens expire 24 hours after activation against "
                  "a configured 7 days, measured on three recipients for "
                  "three. Mitigated this week by a one-command refresh, not "
                  "fixed. AC4's self-service portal inherits a daily "
                  "re-activation step nobody has costed."),
        ("Watch", "Push ingest has no content scanning and OD-9 leaves it "
                  "without an owner. Six passing edge refusals check the "
                  "SHAPE of a request and say nothing about what is inside "
                  "a permitted file."),
        ("Next", "Epic 3 (data governance). Epic 2's remainder is "
                 "pre-registered, so it resumes on a named resource rather "
                 "than on a reminder."),
    ], red_labels=("Open red", "Blocking"))

    heading(doc, "One sentence worth keeping")
    p = para(doc, after=3)
    run(p, "A control is only measured on the responses the test provokes.",
        italic=True, color=ACCENT)
    body(doc,
         "Last week's sentence was that a perimeter test which never "
         "observes the perimeter absent is measuring the wrong thing; this "
         "is its sharper cousin. T-07 was correct about everything it "
         "measured, and every probe it ran succeeded — so it measured "
         "the easy half of a control and read green for two days. For any "
         "response-phase control, ask which responses never reach that "
         "phase, then probe those on purpose.", after=8)

    p = para(doc, after=0, align=WD_ALIGN_PARAGRAPH.LEFT)
    run(p, "Supporting detail: docs/epics/E2-arb-package.md · "
           "docs/15-deferred-to-client-environment.md · "
           "docs/11-environment-baseline.md §11.7 · evidence/ · "
           "bundle: scripts/41_build_epic2_bundle.py", size=8.5, color=MUTED)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)

    print("=" * 70)
    print("Week 44 report")
    print("=" * 70)
    print("  figures read from evidence, not typed:")
    for label, value in [("T-01", t01_state), ("T-05", f"{t05_state} / {t05_v}"),
                         ("T-07", t07_state), ("T-24", t24_state),
                         ("static gate", gates), ("hygiene", hygiene),
                         ("§3.2 rows", caps), ("blockers", f"{brange}; {bclosed}")]:
        flag = "  <-- UNREADABLE" if UNREAD in str(value) else ""
        print(f"    {label:<14} {value}{flag}")
    print()
    print(f"wrote {OUT.relative_to(ROOT)}")
    print()
    print("Verify the page count before sending:")
    print("  soffice --headless --convert-to pdf --outdir /tmp \\")
    print(f"      {OUT.relative_to(ROOT)}")
    print(f"  pdfinfo /tmp/{OUT.stem}.pdf | grep Pages")


if __name__ == "__main__":
    build()
