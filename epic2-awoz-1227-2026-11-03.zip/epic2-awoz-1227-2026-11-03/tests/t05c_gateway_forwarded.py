#!/usr/bin/env python3
"""T-05, gateway-side half: how many requests did the edge FORWARD?

E2 Task 2.6 | AC2 requirement row 2.5 | CONOPS 2.3.3 | docs/15 A-1
"The Gravitee limit is set below the Databricks-side limit on the same
route so the edge trips first."

THE ARGUMENT FOR ASKING THE GATEWAY INSTEAD OF THE UPSTREAM
-----------------------------------------------------------
Row 2.5 is "to protect compute resources". The assertion that carries it
is that the edge trips BEFORE Databricks. Until now we have tried to
settle it from the upstream's side -- "how many did you see?" -- which
needs an audit surface. `tests/t05b_edge_trips_first.py` established
that this workspace's audit table is readable and does not record Delta
Sharing reads at all, so that route is blocked here on a resource only
the client can supply.

But the gateway is the component that DECIDES whether to forward. A
request interrupted by a request-phase policy is never forwarded, by
construction -- that is what "interrupt" means in this engine, and it is
the same mechanism behind PC-4 and B-55, where a response-phase step
could not act on an interrupted request because the response phase never
ran. The gateway records, per request, whether a backend was called.

So the same claim is answerable as "how many did you forward?", from the
one component that knows for certain.

HOW STRONG IS THIS, HONESTLY
----------------------------
Weaker than an independent upstream count: it is the gateway attesting
to its own behaviour, and a gateway that mis-reports its own forwarding
would mis-report it here too. Stronger than inferring from a 429, which
is what the package has today: a 429 is consistent with the upstream
never being called AND with the gateway forwarding and refusing
afterwards, and cannot separate them.

What this adds, specifically: for every refused request it shows that no
backend call was recorded, and it names the policy that interrupted it.
The upstream count would corroborate this. It would not replace it, and
the evidence file says so rather than letting the reader assume
otherwise.

THE CONTROL THIS TEST IS BUILT AROUND
-------------------------------------
The discriminator is a field meaning "a backend was called". If that
field is absent on EVERY document -- wrong field name on this version,
analytics configured without it, the metrics index not populated -- then
every request looks un-forwarded and the burst reads as perfect
protection. Same trap as t05b's blind audit table, in a different store.

So the positive control runs FIRST and the test refuses to continue
without it: a request that is known to have SUCCEEDED must be found in
the store carrying the upstream marker. Only once a known-forwarded
request has been seen to look forwarded does an un-forwarded one mean
anything.

Run:
    python3 tests/t05c_gateway_forwarded.py
    python3 tests/t05c_gateway_forwarded.py --fields   # discovery only
"""

import json
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests
import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tests"))

from common import Report, load_env  # noqa: E402
from t01_gateway_read import edge_base, http  # noqa: E402

import importlib.util  # noqa: E402
import os  # noqa: E402

POLICY_CLASSES = ROOT / "iac" / "config" / "policy-classes.yaml"
FAMILY = ROOT / "gravitee" / "generated" / "route-family.json"
EVIDENCE = ROOT / "evidence" / "t05c-gateway-forwarded.json"
REPORT = ROOT / "evidence" / "t05c-report.json"


def _load(rel, modname):
    spec = importlib.util.spec_from_file_location(modname, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[modname] = mod
    spec.loader.exec_module(mod)
    return mod


P33 = _load("scripts/33_probe_s10_path.py", "t05c_p33")

# Request indices only. scripts/06 measured why this matters: the store
# also holds gravitee-monitor-*, which is JVM and OS telemetry and
# dominates by volume, so searching gravitee-* and sampling the newest
# document returns node telemetry and tells you nothing about requests.
REQUEST_INDICES = "gravitee-v4-log-*,gravitee-v4-metrics-*,gravitee-request-*"

# Candidate fields meaning "a backend was actually called". Ordered by
# how directly they say it. Which one EXISTS is discovered at runtime and
# recorded in the evidence -- never assumed, because a field name that
# silently does not exist would make every request look un-forwarded.
UPSTREAM_MARKERS = [
    "endpoint",
    "endpoint-response-time-ms",
    "api-response-time-ms",
    "upstream-response-time-ms",
    "endpoint_response_time_ms",
]

# Fields that name WHY a request was interrupted. Not required for the
# verdict; they turn "it was not forwarded" into "it was not forwarded
# because this policy interrupted it", which is the difference between a
# count and an explanation.
REASON_FIELDS = ["error-key", "error-component-name", "error-component-type",
                 "error_key", "error-message"]

SETTLE_S = 12          # the store is not synchronous with the response


def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def es_url():
    return os.environ.get("ELASTICSEARCH_URL",
                          "http://localhost:9200").rstrip("/")


def es_search(body, size=200):
    """(hits, error). Never raises: every failure here is a CANNOT_SEE."""
    try:
        r = requests.post(f"{es_url()}/{REQUEST_INDICES}/_search",
                          json={**body, "size": size}, timeout=20)
    except requests.exceptions.RequestException as exc:
        return None, (f"{es_url()} did not answer ({type(exc).__name__}). "
                      f"In this compose file elasticsearch is published on "
                      f"127.0.0.1:9200; if that was only just added the "
                      f"container needs `docker compose up -d "
                      f"elasticsearch`. MISSING OBSERVATION, not a result.")
    if r.status_code != 200:
        return None, f"search returned {r.status_code}: {r.text[:300]}"
    try:
        return (r.json().get("hits") or {}).get("hits") or [], None
    except ValueError:
        return None, f"search did not return JSON: {r.text[:200]}"


def window_query(since_dt, path_fragment):
    """Documents for our route since a moment, newest first."""
    return {
        "query": {"bool": {"filter": [
            {"range": {"@timestamp": {
                "gte": since_dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")}}},
        ], "must": [
            {"query_string": {
                # The fragment is a path, not a UUID. scripts/06's trap --
                # query_string reading a leading '-' as NOT -- applies to
                # id-shaped terms; a quoted path is safe and the quoting
                # is what keeps it so.
                "query": f'"{path_fragment}"', "default_field": "*"}},
        ]}},
        "sort": [{"@timestamp": {"order": "desc"}}],
    }


def marker_of(src, marker):
    v = src.get(marker)
    if v in (None, "", 0, "0"):
        return None
    return v


def main():
    load_env()
    base = edge_base()[0]

    print("=" * 70)
    print("T-05 (gateway half): how many requests did the edge FORWARD?")
    print("E2 Task 2.6 | AC2 row 2.5 | CONOPS 2.3.3 | docs/15 A-1")
    print("=" * 70)
    print()
    print("  A request interrupted by a request-phase policy is never")
    print("  forwarded, by construction. So the gateway can answer the")
    print("  question the upstream audit table could not.")
    print()

    out = {"test": "T-05-gateway-half", "at": now(), "edge_base": base,
           "conops": "2.3.3 / AC2 row 2.5", "register_item": "A-1",
           "log_store": es_url(), "indices": REQUEST_INDICES, "phases": {}}

    def finish(verdict, why, passed=False):
        out["verdict"] = verdict
        out["why"] = why
        out["standing_of_this_evidence"] = (
            "The gateway attesting to its own forwarding. Weaker than an "
            "independent upstream count -- a gateway that mis-reported "
            "forwarding would mis-report it here too -- and stronger than "
            "inferring from a 429, which cannot separate 'never called' "
            "from 'called, then refused'. The upstream count corroborates "
            "this; it does not replace it.")
        rep = Report()
        rep.record(
            "T-05 (gateway half)",
            "the edge does not forward what it refuses",
            "a request known to have SUCCEEDED is first seen in the log "
            "store carrying an upstream marker, and then no refused "
            "request in the burst window carries one",
            verdict, passed, str(EVIDENCE.relative_to(ROOT)))
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps(out, indent=2) + "\n")
        try:
            EVIDENCE.chmod(0o600)
        except OSError:
            pass
        rep.write(REPORT)
        rep.summary()
        print()
        print("=" * 70)
        print(f"T-05 (gateway half) VERDICT: {verdict}")
        print("=" * 70)
        print(why)
        return 0 if passed else 1

    # ---- a live credential and its route --------------------------
    print("--- selecting a live credential")
    live, tried = P33.pick_live_profile(P33.load_profiles())
    if not live:
        return finish("CANNOT_SEE_NO_LIVE_CREDENTIAL",
                      "No recipient credential is live. Refresh with "
                      "scripts/43_refresh_credentials.py --all.")
    cred_name, _endpoint, token = live
    family = json.loads(FAMILY.read_text()).get("family") or []
    member = next((m for m in family
                   if (m.get("recipient") or "") in cred_name
                   or (m.get("slug") or "zzz") in cred_name), None)
    if member is None:
        return finish("CANNOT_SEE_CREDENTIAL_NOT_IN_FAMILY",
                      "The live credential has no route in the family.")
    edge_path = member["edge_path"]
    url = f"{base}{edge_path}/shares"
    print(f"    {cred_name} -> {edge_path}/shares  (S1, class A)")
    out["credential"] = cred_name
    out["route"] = f"{edge_path}/shares"
    out["credentials_tried"] = tried

    # ---- phase 1: is the store reporting requests at all? ---------
    print("\n--- phase 1: does the log store hold REQUEST documents?")
    hits, err = es_search({"query": {"match_all": {}},
                           "sort": [{"@timestamp": {"order": "desc"}}]},
                          size=1)
    if hits is None:
        return finish("CANNOT_SEE_LOG_STORE_UNREACHABLE", err)
    if not hits:
        return finish(
            "CANNOT_SEE_GATEWAY_NOT_REPORTING_REQUESTS",
            "The request indices are empty. The gateway is not reporting, "
            "so there is nothing to count. That is B-53's condition -- a "
            "requirement nothing tests is a requirement nothing enforces "
            "-- and it must be fixed before this question can be asked.")
    fields = sorted((hits[0].get("_source") or {}))
    print(f"    yes. newest document carries {len(fields)} field(s)")
    print(f"    {fields}")
    out["phases"]["store"] = {"document_fields": fields}

    marker = next((m for m in UPSTREAM_MARKERS if m in fields), None)
    reasons = [f for f in REASON_FIELDS if f in fields]
    print(f"\n    upstream marker available: {marker or 'NONE'}")
    print(f"    reason fields available:   {reasons or 'none'}")
    out["phases"]["store"]["upstream_marker"] = marker
    out["phases"]["store"]["reason_fields"] = reasons
    out["phases"]["store"]["markers_looked_for"] = UPSTREAM_MARKERS

    if "--fields" in sys.argv:
        print("\n(--fields: discovery only, nothing measured)")
        return finish("FIELD_DISCOVERY_ONLY",
                      "Ran with --fields. No measurement attempted.")

    if not marker:
        return finish(
            "CANNOT_SEE_NO_UPSTREAM_MARKER_FIELD",
            f"No field naming an upstream call is present. Looked for "
            f"{UPSTREAM_MARKERS}; the documents carry {fields}.\n\n"
            f"Without one, every request looks un-forwarded and the burst "
            f"would read as perfect compute protection -- the same shape "
            f"as t05b's blind audit table, in a different store. Refusing "
            f"to count is the only honest option. If this version names "
            f"the field differently, add it to UPSTREAM_MARKERS; the list "
            f"is in this file precisely so the fix is one line.")

    # ---- phase 2: THE POSITIVE CONTROL ----------------------------
    print("\n--- phase 2: POSITIVE CONTROL -- does a request KNOWN to "
          "have succeeded look forwarded?")
    print("    Without this, a field that is always empty would make every")
    print("    request look un-forwarded and the burst read as a pass.")
    t0 = datetime.now(timezone.utc) - timedelta(seconds=5)
    st, _, _ = http(url, token)
    print(f"    one read through the edge -> {st}")
    if st != 200:
        return finish("CANNOT_SEE_CONTROL_READ_DID_NOT_SUCCEED",
                      f"The control read returned {st}, so there is no "
                      f"request known to have been forwarded.")
    time.sleep(SETTLE_S)
    hits, err = es_search(window_query(t0, edge_path))
    if hits is None:
        return finish("CANNOT_SEE_LOG_STORE_UNREACHABLE", err)
    ok_docs = [h.get("_source") or {} for h in hits
               if str((h.get("_source") or {}).get("status")) == "200"]
    forwarded_control = [d for d in ok_docs if marker_of(d, marker)]
    print(f"    documents for this route since the control: {len(hits)}")
    print(f"    of which status 200: {len(ok_docs)}, "
          f"carrying {marker}: {len(forwarded_control)}")
    out["phases"]["positive_control"] = {
        "status": st, "documents": len(hits), "status_200": len(ok_docs),
        "carrying_marker": len(forwarded_control), "marker": marker,
        "example": {k: v for k, v in (forwarded_control[0].items()
                                      if forwarded_control else [])
                    if k in (marker, "status", "uri", "path", *reasons)},
    }
    if not ok_docs:
        return finish(
            "CANNOT_SEE_SUCCESSFUL_REQUEST_NOT_IN_THE_STORE",
            f"A read that returned 200 produced no matching document "
            f"within {SETTLE_S}s. Either reporting lags further than that, "
            f"or the path filter does not match how this version records "
            f"the URI. Counting a burst against a store that did not "
            f"record a request we watched succeed would be measuring "
            f"nothing.")
    if not forwarded_control:
        return finish(
            "CANNOT_SEE_MARKER_EMPTY_ON_A_SUCCESSFUL_REQUEST",
            f"A request that demonstrably reached Databricks and returned "
            f"200 carries no value in `{marker}`. So that field does not "
            f"mean 'a backend was called' on this version, and a burst "
            f"counted with it would report every request as un-forwarded "
            f"-- a perfect pass, manufactured.\n\n"
            f"This is the result the control exists to catch.")
    print("    control satisfied: a known-forwarded request looks forwarded")

    # ---- phase 3: the burst ---------------------------------------
    pc = yaml.safe_load(POLICY_CLASSES.read_text())
    rate = {}
    for step in (pc.get("classes", {}).get("A", {}).get("request") or []):
        if step.get("policy") == "rate-limit":
            rate = (step.get("configuration") or {}).get("rate") or {}
    limit = int(rate.get("limit") or 60)
    n_send = limit + 8

    print(f"\n--- phase 3: waiting 65s for the window to clear, then "
          f"bursting {n_send} (limit {limit}/min)")
    time.sleep(65)
    t1 = datetime.now(timezone.utc) - timedelta(seconds=2)
    sent = throttled = 0
    for _ in range(n_send):
        s, _, _ = http(url, token)
        sent += 1
        if s == 429:
            throttled += 1
        time.sleep(0.25)        # above the measured 1-per-200ms spike gate
    print(f"    sent {sent}, refused at the edge {throttled}")
    if not throttled:
        return finish("CANNOT_SEE_EDGE_NEVER_THROTTLED",
                      f"None of {sent} requests was refused, so there is "
                      f"no refusal whose forwarding could be examined.")

    print(f"    waiting {SETTLE_S}s for the store to settle")
    time.sleep(SETTLE_S)
    hits, err = es_search(window_query(t1, edge_path), size=500)
    if hits is None:
        return finish("CANNOT_SEE_LOG_STORE_UNREACHABLE", err)

    docs = [h.get("_source") or {} for h in hits]
    refused = [d for d in docs if str(d.get("status")) == "429"]
    served = [d for d in docs if str(d.get("status")) == "200"]
    refused_forwarded = [d for d in refused if marker_of(d, marker)]
    served_forwarded = [d for d in served if marker_of(d, marker)]

    why_refused = {}
    for d in refused:
        for f in reasons:
            if d.get(f):
                why_refused.setdefault(f, {})
                why_refused[f][str(d[f])] = why_refused[f].get(str(d[f]), 0) + 1

    print(f"    documents in the burst window: {len(docs)}")
    print(f"      status 200: {len(served)}, of which forwarded: "
          f"{len(served_forwarded)}")
    print(f"      status 429: {len(refused)}, of which forwarded: "
          f"{len(refused_forwarded)}")
    if why_refused:
        print(f"      refusal attributed to: "
              f"{json.dumps(why_refused, sort_keys=True)}")

    out["phases"]["burst"] = {
        "sent": sent, "throttled_at_edge": throttled,
        "documents": len(docs), "status_200": len(served),
        "status_429": len(refused),
        "served_carrying_marker": len(served_forwarded),
        "refused_carrying_marker": len(refused_forwarded),
        "refusal_attribution": why_refused,
        "marker": marker, "since": t1.isoformat(),
    }

    # ---- verdict ---------------------------------------------------
    if not refused:
        return finish(
            "CANNOT_SEE_REFUSALS_NOT_IN_THE_STORE",
            f"{throttled} requests were refused at the edge and the store "
            f"holds none of them for this window. The gateway is not "
            f"recording its own refusals, so what it did with them cannot "
            f"be read here.")

    if refused_forwarded:
        return finish(
            "EDGE_REFUSED_BUT_FORWARDED_ANYWAY",
            f"{len(refused_forwarded)} of {len(refused)} refused requests "
            f"carry `{marker}`, meaning a backend was called before the "
            f"refusal was returned. The caller is throttled and compute is "
            f"NOT protected. That is the opposite of what §2.3.3 claims, "
            f"and it would be a finding rather than a tuning note: every "
            f"edge-side measurement would still look correct.")

    return finish(
        "EDGE_DID_NOT_FORWARD_WHAT_IT_REFUSED",
        f"In the burst window the store holds {len(docs)} documents for "
        f"this route: {len(served)} served, of which "
        f"{len(served_forwarded)} record a backend call, and "
        f"{len(refused)} refused, of which **none** records one.\n\n"
        f"So the edge did not forward what it refused. Combined with the "
        f"edge half -- both throttles firing and clearing where "
        f"configured -- that is CONOPS 2.3.3's assertion measured: the "
        f"edge trips first, and Databricks was not called for the "
        f"refused requests.\n\n"
        f"The positive control is what makes this readable: a request "
        f"known to have been forwarded was first seen carrying "
        f"`{marker}`, so its absence on the refusals is a measurement "
        f"rather than an empty field."
        + (f"\n\nThe refusals are attributed to "
           f"{json.dumps(why_refused, sort_keys=True)}, which names the "
           f"interrupting policy rather than leaving the 429 anonymous."
           if why_refused else ""),
        passed=True)


if __name__ == "__main__":
    sys.exit(main())
