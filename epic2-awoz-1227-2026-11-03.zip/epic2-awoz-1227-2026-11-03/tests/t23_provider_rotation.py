#!/usr/bin/env python3
"""T-23 (rotation half): rotate the D2O provider credential, and prove the
old one stops working.

CONOPS §5.2 T-23: "Rotate the provider credential; drop the catalog and
provider -> New file works, old file fails after the overlap; access
removed on drop." This module covers the FIRST clause only. The drop half
belongs with the Databricks-side provider object and is not built here;
the verdict says so by name rather than letting a passing first half
imply a passing test.

WHY THIS EXISTS AS A TEST AND NOT AS A NOTE
-------------------------------------------
The rotation it checks was performed by hand on 2026-10-25, and it took
four attempts to land -- not because the mechanics are hard, but because
every signal available during those attempts was positive while nothing
had changed:

  - scripts/11_probe_oss_provider.py passed, because it reads the
    CURRENT profile. It passes identically whether or not a rotation
    occurred.
  - scripts/10_setup_oss_provider.py printed "using OSS_PROVIDER_TOKEN
    from .env", a sentence that cannot distinguish the token you just
    set from the token that was already there.
  - check_secret_hygiene.py reported Clean, because its token scan
    covers files OUTSIDE _secrets/ and both artifacts here live inside
    it.

Three green checks, no rotation. That is this repository's recurring
defect -- a report describing a real outcome about a subject nobody
examined (docs/11 B-44, and confirm_properties_landed's docstring in
scripts/05). The only observation that settles it is the OLD credential
being REFUSED, which is the perimeter observed absent.

THE POSITIVE CONTROL IS NOT OPTIONAL
------------------------------------
A 401 on the old token proves nothing on its own: a stopped container, a
wrong port, a corrupted config and a successful rotation all produce
refusals. So the ladder below reads the NEW credential first and will
not report the refusal as a finding unless that read returned 200 in the
same run, against the same endpoint. This is B-40 -- the control must be
the same path as the subject -- applied to a credential rather than to a
route.

WHAT THIS MEASURED THAT THE CONOPS DOES NOT SAY
-----------------------------------------------
The Delta Sharing reference server's config carries
`authorization.bearerToken` as a SINGLE string. There is no second slot.
A Databricks recipient holds at most two tokens, active plus rotated,
and §3.1.1 is written around that overlap. A self-hosted open-protocol
provider has NO overlap: the old credential dies the instant the
container restarts with the new config, so a D2O rotation is a hard
cutover with a consumer-visible gap. §2.4.3's "a new file replaces the
old one in the vault" is true here and materially incomplete -- it does
not say the consumer breaks between those two events. Recorded as
`no_overlap_window` below.
"""
import hashlib
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import ROOT, Report, load_env  # noqa: E402

CURRENT = ROOT / "_secrets" / "oss-provider-credential.json"
EVIDENCE = ROOT / "evidence" / "t23-provider-rotation.json"
REPORT = ROOT / "evidence" / "t23-report.json"


def fingerprint(token):
    """Twelve hex characters of SHA-256. Enough to tell two tokens apart,
    not enough to be one. The evidence rule (CONOPS 5.1) is metadata
    only, and a token is exactly what it forbids -- but 'the token
    changed' is a metadata claim, so it has to be expressible without
    the value. This is that expression."""
    return hashlib.sha256(token.encode()).hexdigest()[:12]


def read_profile(path):
    doc = json.loads(path.read_text())
    return doc["endpoint"], doc["bearerToken"]


def probe(endpoint, token):
    """GET /shares with this bearer token. Returns an HTTP status.

    Redirects are NOT followed. scripts/32 recorded why: urllib follows
    them by default, so a 200 can describe a different URL than the one
    asked about, and the mislabel is invisible. Here it would be worse
    than invisible -- a redirect to an unauthenticated path would read
    as the old credential still working."""

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *_a, **_k):
            return None

    opener = urllib.request.build_opener(NoRedirect)
    req = urllib.request.Request(
        endpoint.rstrip("/") + "/shares",
        headers={"Authorization": "Bearer " + token},
    )
    try:
        with opener.open(req, timeout=15) as resp:
            return resp.status
    except urllib.error.HTTPError as exc:
        return exc.code
    except Exception as exc:  # noqa: BLE001
        return f"UNREACHABLE: {exc!r}"


def main():
    load_env()
    rep = Report()

    previous = sorted(
        (ROOT / "_secrets").glob("oss-provider-credential.json.pre-rotation-*")
    )
    if not previous:
        print(
            "No pre-rotation profile found.\n"
            "  Before rotating, copy the live profile aside:\n"
            "    cp _secrets/oss-provider-credential.json \\\n"
            "       _secrets/oss-provider-credential.json.pre-rotation-$(date +%F)\n"
            "    chmod 0600 _secrets/oss-provider-credential.json.pre-rotation-*\n"
            "  Without it only half of T-23 is observable, and it is the "
            "half that carries the finding."
        )
        return 2
    prior = previous[-1]

    cur_endpoint, cur_token = read_profile(CURRENT)
    old_endpoint, old_token = read_profile(prior)
    cur_fp, old_fp = fingerprint(cur_token), fingerprint(old_token)

    detail = {
        "test_id": "T-23",
        "clause": "rotate the provider credential (first clause only)",
        "channel": "I-1 ingress, D2O",
        "provider": "self-hosted open-protocol (Delta Sharing reference server)",
        "endpoint": cur_endpoint,
        "prior_profile": prior.name,
        "fingerprints": {
            "current": cur_fp,
            "previous": old_fp,
            "method": "sha256(token)[:12] -- the value is never read, "
                      "printed or stored",
        },
        "no_overlap_window": {
            "finding": "The reference server config declares "
                       "authorization.bearerToken as a single string. "
                       "There is no second slot, so there is no overlap.",
            "contrast": "A Databricks recipient holds at most two tokens "
                        "(active plus rotated), which is the model "
                        "CONOPS 3.1.1 is written around.",
            "consequence": "A D2O rotation is a hard cutover. The old "
                           "credential dies when the container restarts "
                           "with the new config, so there is a "
                           "consumer-visible gap between issuing the new "
                           "profile and the consumer adopting it.",
            "conops_change": "2.4.3 says a new file replaces the old one "
                             "in the vault. True, and incomplete: it does "
                             "not say the consumer breaks in between.",
        },
    }

    # --- Rung 1: are these two different credentials at all? -----------
    differs = cur_fp != old_fp
    rep.record(
        "T-23a",
        "the live profile holds a different token than the pre-rotation copy",
        "two different sha256 fingerprints",
        f"current={cur_fp} previous={old_fp} -> "
        + ("DIFFERENT" if differs else "IDENTICAL"),
        differs,
        f"evidence/{EVIDENCE.name}",
    )
    if not differs:
        detail["verdict"] = "NOT_ROTATED_PROFILE_UNCHANGED"
        detail["what_this_means"] = (
            "The rendered profile still carries the previous token. "
            "Editing .env does not rotate anything on its own: "
            "scripts/10_setup_oss_provider.py is the only writer of "
            "_secrets/delta-sharing-server-config.yaml and "
            "_secrets/oss-provider-credential.json, and the server reads "
            "its config only at startup. Set the new value in .env, re-run "
            "scripts/10 WITHOUT --force, then restart the container."
        )
        finish(rep, detail)
        return 1

    # --- Rung 2: POSITIVE CONTROL, before any claim about the old one --
    cur_status = probe(cur_endpoint, cur_token)
    control_ok = cur_status == 200
    rep.record(
        "T-23b",
        "positive control: the CURRENT credential reads through the provider",
        "200 from GET /shares",
        f"{cur_status}",
        control_ok,
        f"evidence/{EVIDENCE.name}",
    )
    if not control_ok:
        detail["verdict"] = "CANNOT_SEE_POSITIVE_CONTROL_DID_NOT_READ"
        detail["what_this_does_not_prove"] = (
            "Nothing is claimed about the old credential. A refusal is "
            "only attributable to the rotation if the new credential "
            "succeeds against the same endpoint in the same run. With the "
            "control failing, a 401 on the old token is equally explained "
            "by a stopped container, a wrong port or a config the server "
            "could not parse."
        )
        detail["current_status"] = cur_status
        finish(rep, detail)
        return 1

    # --- Rung 3: the finding -- the old credential is refused ----------
    old_status = probe(old_endpoint, old_token)
    refused = old_status == 401
    rep.record(
        "T-23c",
        "the PRE-ROTATION credential is refused by the same endpoint",
        "401 from GET /shares",
        f"{old_status}",
        refused,
        f"evidence/{EVIDENCE.name}",
    )

    detail["current_status"] = cur_status
    detail["previous_status"] = old_status
    if refused:
        detail["verdict"] = "ROTATED_AND_THE_OLD_CREDENTIAL_IS_REFUSED"
    elif old_status == 200:
        detail["verdict"] = "PROFILE_ROTATED_BUT_THE_SERVER_STILL_ACCEPTS_THE_OLD_TOKEN"
        detail["what_this_means"] = (
            "The profile on disk was re-rendered but the running server "
            "was not restarted, so it is still serving the previous "
            "config. The files and the process disagree, and only the "
            "files were being read. Restart delta_sharing_server."
        )
    else:
        detail["verdict"] = f"UNEXPECTED_STATUS_ON_THE_OLD_CREDENTIAL_{old_status}"
        detail["what_this_means"] = (
            "Not a refusal and not a success. Recorded rather than "
            "rounded to the nearer of the two (B-46)."
        )

    detail["not_covered_by_this_module"] = {
        "clause": "drop the catalog and provider; access removed on drop",
        "why": "That half acts on the Databricks-side provider object "
               "created from this profile, not on the provider itself. "
               "It is unbuilt, and a passing first clause must not be "
               "read as a passing T-23.",
        "note": "A provider imported from the PREVIOUS profile still "
                "holds the old token. SHOW PROVIDERS will list it "
                "happily -- the import never contacts the endpoint "
                "(docs/10 D-6) -- so verify with a SELECT, not a SHOW.",
    }
    finish(rep, detail)
    return 0 if refused else 1


def finish(rep, detail):
    EVIDENCE.parent.mkdir(exist_ok=True)
    EVIDENCE.write_text(json.dumps(detail, indent=2) + "\n")
    rep.write(REPORT)
    rep.summary()
    print(f"\nVERDICT: {detail['verdict']}")
    print(f"Detail:  evidence/{EVIDENCE.name}")


if __name__ == "__main__":
    sys.exit(main())
