#!/usr/bin/env python3
"""T-05, upstream half: does the EDGE trip BEFORE Databricks?

E2 Task 2.6 | AC2 requirement row 2.5 | docs/15 A-1 and P-3
CONOPS 2.3.3: "The Gravitee limit is set below the Databricks-side limit
on the same route so the edge trips first."

WHY THIS FILE EXISTS, AND WHY IT IS EXPECTED TO RETURN CANNOT_SEE
-----------------------------------------------------------------
T-05's edge half is measured and passing: both throttles fire where
configured, both clear, neither carries a retry indication. That is the
MECHANISM.

It is not the CLAIM. AC2's requirement row 2.5 is "to protect compute
resources", and the sentence that carries it is §2.3.3's: the edge trips
first. **A 429 at the edge is consistent with the upstream never being
called and does not demonstrate it.** The gateway could equally be
forwarding every request and refusing afterwards; from outside, the two
are the same observation. Settling it needs a count of the requests that
actually reached Databricks, which means `system.access.audit`.

This workspace tier does not expose that table, so this test will return
CANNOT_SEE here. It is written anyway, deliberately, and the reason is
the repository's own standard: **a test that returns CANNOT_SEE for a
stated reason is a deliverable; a missing test is a task.** When the
client environment has the system catalog enabled, this runs as one
command instead of someone commissioning a test under schedule pressure
and inventing the method on the spot.

THE TRAP THIS TEST IS BUILT AROUND
----------------------------------
The obvious implementation is: burst, count the audit rows, assert the
count is lower than what was sent. That implementation has a failure
mode that looks exactly like a perfect pass.

If `system.access.audit` does not record Delta Sharing reads at all --
because the action names differ on this tier, because the rows land in
another table, because propagation takes longer than the window -- then
the query returns ZERO rows. Zero upstream requests against sixty-eight
sent reads as **total compute protection**. It is the strongest possible
result and it would be an artefact of the table being blind.

So the positive control comes FIRST and the test refuses to proceed
without it: make one read that is known to succeed through the edge,
wait, and confirm THAT read appears in the audit table. Only once the
table has been seen recording a request we know was made does a lower
count afterwards mean anything.

This is B-40's rule -- a same-path positive control in the same run --
applied to an upstream counter rather than to a refusal.

Run:
    python3 tests/t05b_edge_trips_first.py
    python3 tests/t05b_edge_trips_first.py --warehouse <id>
"""

import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tests"))

from common import Report, load_env  # noqa: E402
from t01_gateway_read import edge_base, http  # noqa: E402

import importlib.util  # noqa: E402
import os  # noqa: E402

POLICY_CLASSES = ROOT / "iac" / "config" / "policy-classes.yaml"
FAMILY = ROOT / "gravitee" / "generated" / "route-family.json"
EVIDENCE = ROOT / "evidence" / "t05b-edge-trips-first.json"
REPORT = ROOT / "evidence" / "t05b-report.json"


def _load(rel, modname):
    spec = importlib.util.spec_from_file_location(modname, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[modname] = mod
    spec.loader.exec_module(mod)
    return mod


P33 = _load("scripts/33_probe_s10_path.py", "t05b_p33")

# The action names a Delta Sharing read produces, as recorded in
# scripts/06_trace_correlation.py's Databricks-half query. Kept in one
# place so the two agree.
SHARING_ACTIONS = ("deltaSharingQueryTable", "deltaSharingListTable",
                   "deltaSharingListShares", "deltaSharingListSchemas",
                   "deltaSharingListAllTables", "deltaSharingGetShare",
                   "deltaSharingGetTableMetadata",
                   "deltaSharingGetTableVersion")

AUDIT_LAG_S = 90      # audit rows are not synchronous; wait before counting
POLL_EVERY_S = 15


def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


# ---------------------------------------------------------------------
# Databricks SQL, over the Statement Execution API.
#
# No helper for this existed in the repository, because nothing until now
# needed to run SQL. It is deliberately small: one call, one poll loop,
# and every failure returns a REASON rather than raising, because every
# one of them is a legitimate CANNOT_SEE rather than a crash.
# ---------------------------------------------------------------------
def dbx(path, token, host, method="GET", body=None, timeout=60):
    url = f"https://{host.rstrip('/').removeprefix('https://')}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", "replace")
        try:
            return e.code, json.loads(raw)
        except json.JSONDecodeError:
            return e.code, {"raw": raw[:400]}
    except Exception as e:  # noqa: BLE001
        return 0, {"error_code": type(e).__name__, "message": str(e)[:300]}


def pick_warehouse(token, host, explicit=None):
    """(warehouse_id, note) or (None, why-not)."""
    if explicit:
        return explicit, "supplied with --warehouse"
    st, body = dbx("/api/2.0/sql/warehouses", token, host)
    if st != 200:
        return None, f"listing warehouses returned {st}: {str(body)[:200]}"
    whs = body.get("warehouses") or []
    if not whs:
        return None, ("no SQL warehouse exists in this workspace, and the "
                      "audit table can only be read through one")
    running = [w for w in whs if str(w.get("state", "")).upper() == "RUNNING"]
    chosen = (running or whs)[0]
    return chosen.get("id"), (
        f"{chosen.get('name')} ({chosen.get('state')}); "
        f"{len(whs)} warehouse(s) visible")


def run_sql(sql, token, host, warehouse_id, timeout_s=120):
    """(rows, error-or-None). Rows are lists of strings."""
    st, body = dbx("/api/2.0/sql/statements", token, host, method="POST",
                   body={"statement": sql, "warehouse_id": warehouse_id,
                         "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"})
    if st != 200:
        return None, f"statement POST returned {st}: {str(body)[:300]}"

    deadline = time.time() + timeout_s
    while True:
        state = (body.get("status") or {}).get("state")
        if state in ("SUCCEEDED", "FAILED", "CANCELED", "CLOSED"):
            break
        if time.time() > deadline:
            return None, f"statement did not finish within {timeout_s}s"
        time.sleep(3)
        sid = body.get("statement_id")
        st, body = dbx(f"/api/2.0/sql/statements/{sid}", token, host)
        if st != 200:
            return None, f"statement poll returned {st}: {str(body)[:300]}"

    if state != "SUCCEEDED":
        err = (body.get("status") or {}).get("error") or {}
        return None, (f"statement {state}: "
                      f"{err.get('error_code', '')} "
                      f"{str(err.get('message', ''))[:300]}")
    return (body.get("result") or {}).get("data_array") or [], None


def count_sharing_reads(token, host, wh, since_iso, recipient_hint=None):
    """How many Delta Sharing read events the audit table holds since
    `since_iso`. (count, sql, error)."""
    actions = ", ".join(f"'{a}'" for a in SHARING_ACTIONS)
    where_recipient = ""
    if recipient_hint:
        safe = recipient_hint.replace("'", "''")
        where_recipient = (f"  AND lower(to_json(request_params)) LIKE "
                           f"'%{safe.lower()}%'\n")
    sql = (f"SELECT count(*) FROM system.access.audit\n"
           f"WHERE service_name = 'unityCatalog'\n"
           f"  AND action_name IN ({actions})\n"
           f"{where_recipient}"
           f"  AND event_time > TIMESTAMP '{since_iso}'")
    rows, err = run_sql(sql, token, host, wh)
    if err:
        return None, sql, err
    try:
        return int(rows[0][0]), sql, None
    except (IndexError, TypeError, ValueError):
        return None, sql, f"unexpected result shape: {str(rows)[:200]}"


# ---------------------------------------------------------------------
def main():
    load_env()
    explicit_wh = None
    if "--warehouse" in sys.argv:
        i = sys.argv.index("--warehouse")
        if i + 1 < len(sys.argv):
            explicit_wh = sys.argv[i + 1]

    base, base_how = edge_base()[0], edge_base()[1]
    host = os.environ.get("DATABRICKS_HOST", "")
    token = os.environ.get("DATABRICKS_TOKEN", "")

    print("=" * 70)
    print("T-05 (upstream half): does the EDGE trip BEFORE Databricks?")
    print("E2 Task 2.6 | AC2 row 2.5 | CONOPS 2.3.3 | docs/15 A-1")
    print("=" * 70)
    print()
    print("  The edge half is already measured and passing. This asks the")
    print("  other question, and it is the one the requirement actually")
    print("  makes: a 429 at the edge is consistent with the upstream")
    print("  never being called and does not demonstrate it.")
    print()
    print(f"  edge base: {base}  ({base_how})")
    print()

    out = {"test": "T-05-upstream", "at": now(), "edge_base": base,
           "conops": "2.3.3 / AC2 row 2.5", "register_item": "A-1",
           "phases": {}}

    def finish(verdict, why, passed=False):
        out["verdict"] = verdict
        out["why"] = why
        rep = Report()
        rep.record(
            "T-05 (upstream half)",
            "the edge trips before Databricks sees the burst",
            "the audit table is first seen recording a read that is known "
            "to have happened, and then records FEWER requests than were "
            "sent during a burst that the edge throttled",
            verdict, passed, str(EVIDENCE.relative_to(ROOT)))
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps(out, indent=2) + "\n")
        try:
            EVIDENCE.chmod(0o600)
        except OSError:
            pass
        rep.write(REPORT)
        rep.summary()
        print()
        print("=" * 70)
        print(f"T-05 (upstream half) VERDICT: {verdict}")
        print("=" * 70)
        print(why)
        return 0 if passed else 1

    if not host or not token:
        return finish(
            "CANNOT_SEE_NO_WORKSPACE_CREDENTIAL",
            "DATABRICKS_HOST and DATABRICKS_TOKEN must be set to query the "
            "audit table. This is a workspace credential, not a recipient "
            "credential -- the audit table belongs to the provider side.")

    # ---- precondition 1: a warehouse ------------------------------
    print("--- precondition 1: a SQL warehouse to read the audit table")
    wh, note = pick_warehouse(token, host, explicit_wh)
    print(f"    {note}")
    out["phases"]["warehouse"] = {"id": wh, "note": note}
    if not wh:
        return finish(
            "CANNOT_SEE_NO_SQL_WAREHOUSE",
            f"The audit table is only readable through a SQL warehouse and "
            f"none is available: {note}. Owner: client platform. This is "
            f"A-1's named resource showing up as its first obstacle.")

    # ---- precondition 2: is the table there at all? ---------------
    print("\n--- precondition 2: is system.access.audit readable?")
    rows, err = run_sql("SELECT 1 FROM system.access.audit LIMIT 1",
                        token, host, wh)
    out["phases"]["audit_readable"] = {"ok": err is None, "error": err}
    if err:
        print(f"    NO: {err}")
        return finish(
            "CANNOT_SEE_AUDIT_TABLE_NOT_AVAILABLE",
            f"system.access.audit could not be read: {err}\n\n"
            f"This is the expected outcome on a tier without the system "
            f"catalog enabled, and it is exactly what docs/15 A-1 names. "
            f"Clause 2.5's mechanism stays measured by T-05's edge half; "
            f"its CLAIM stays unevidenced. Nothing in this environment "
            f"can close that, and no amount of edge-side measurement "
            f"substitutes for it.")
    print("    yes")

    # ---- a live recipient credential to drive the route -----------
    print("\n--- selecting a live credential")
    live, tried = P33.pick_live_profile(P33.load_profiles())
    if not live:
        return finish(
            "CANNOT_SEE_NO_LIVE_CREDENTIAL",
            "No recipient credential is live, so no request can be driven "
            "through the edge. Recipient tokens expire 24h from creation; "
            "refresh with scripts/43_refresh_credentials.py --all.")
    cred_name, _endpoint, rtoken = live
    family = json.loads(FAMILY.read_text()).get("family") or []
    member = next((m for m in family
                   if (m.get("recipient") or "") in cred_name
                   or (m.get("slug") or "zzz") in cred_name), None)
    if member is None:
        return finish("CANNOT_SEE_CREDENTIAL_NOT_IN_FAMILY",
                      "The live credential has no route in the generated "
                      "family, so there is no edge path to drive.")
    url = f"{base}{member['edge_path']}/shares"
    print(f"    {cred_name} -> {member['edge_path']}/shares  (S1, class A)")
    out["credential"] = cred_name
    out["route"] = f"{member['edge_path']}/shares"
    out["credentials_tried"] = tried

    # ---- THE POSITIVE CONTROL -------------------------------------
    # Without this, zero audit rows reads as perfect compute protection.
    print("\n--- phase 1: POSITIVE CONTROL -- can the audit table see a "
          "read we know happened?")
    print("    Without this, zero upstream rows would read as total")
    print("    protection when it may only mean the table is blind.")
    t0 = datetime.now(timezone.utc).replace(microsecond=0)
    t0_iso = t0.strftime("%Y-%m-%d %H:%M:%S")
    time.sleep(1)
    st, _, _ = http(url, rtoken)
    print(f"    one read through the edge -> {st}")
    if st != 200:
        return finish(
            "CANNOT_SEE_CONTROL_READ_DID_NOT_SUCCEED",
            f"The control read returned {st}, so there is no request known "
            f"to have reached the upstream and nothing to look for in the "
            f"audit table.")

    seen = None
    waited = 0
    sql = None
    while waited <= AUDIT_LAG_S:
        time.sleep(POLL_EVERY_S)
        waited += POLL_EVERY_S
        n, sql, err = count_sharing_reads(token, host, wh, t0_iso)
        print(f"    +{waited:>3}s  audit rows since the control read: "
              f"{n if n is not None else 'query error: ' + str(err)}")
        if n:
            seen = n
            break
    out["phases"]["positive_control"] = {
        "control_read_status": st, "since": t0_iso,
        "rows_seen": seen, "waited_s": waited,
        "sql": sql,
    }
    if not seen:
        return finish(
            "CANNOT_SEE_AUDIT_DOES_NOT_RECORD_THESE_READS",
            f"A read that demonstrably succeeded through the edge produced "
            f"no row in system.access.audit within {AUDIT_LAG_S}s. The "
            f"table is readable and is not recording this traffic -- the "
            f"action names may differ on this tier, the rows may land "
            f"elsewhere, or propagation may be slower than the window.\n\n"
            f"This is the result the test exists to catch. Had the burst "
            f"been counted without this control, the answer would have "
            f"been 'zero upstream requests' and would have read as perfect "
            f"compute protection. It would have been an artefact of a "
            f"blind table, and it would have been the strongest claim in "
            f"the package.")
    print(f"    control satisfied: the table recorded {seen} row(s)")

    # ---- phase 2: the burst ---------------------------------------
    pc = yaml.safe_load(POLICY_CLASSES.read_text())
    rate = {}
    for step in (pc.get("classes", {}).get("A", {}).get("request") or []):
        if step.get("policy") == "rate-limit":
            rate = (step.get("configuration") or {}).get("rate") or {}
    limit = int(rate.get("limit") or 60)
    n_send = limit + 8

    print(f"\n--- phase 2: burst {n_send} requests (limit is {limit}/min) "
          f"and count what reached Databricks")
    print("    waiting 65s first so the control read's own budget clears")
    time.sleep(65)

    t1 = datetime.now(timezone.utc).replace(microsecond=0)
    t1_iso = t1.strftime("%Y-%m-%d %H:%M:%S")
    time.sleep(1)
    sent = throttled = 0
    for _ in range(n_send):
        s, _, _ = http(url, rtoken)
        sent += 1
        if s == 429:
            throttled += 1
        time.sleep(0.25)          # above the measured 1-per-200ms gate
    print(f"    sent {sent}, of which {throttled} were refused at the edge")

    if not throttled:
        return finish(
            "CANNOT_SEE_EDGE_NEVER_THROTTLED",
            f"None of {sent} requests was refused at the edge, so there is "
            f"no throttle whose effect on the upstream could be measured. "
            f"Check that the class A rate limit is deployed on this route.")

    print(f"    waiting {AUDIT_LAG_S}s for audit rows to land")
    time.sleep(AUDIT_LAG_S)
    landed, sql2, err2 = count_sharing_reads(token, host, wh, t1_iso)
    print(f"    audit rows for the burst window: "
          f"{landed if landed is not None else 'query error: ' + str(err2)}")

    out["phases"]["burst"] = {
        "sent": sent, "throttled_at_edge": throttled,
        "expected_upstream_at_most": sent - throttled,
        "audit_rows": landed, "since": t1_iso, "sql": sql2, "error": err2,
    }
    if landed is None:
        return finish("CANNOT_SEE_AUDIT_QUERY_FAILED_AFTER_BURST",
                      f"The burst ran but the audit count failed: {err2}")

    # ---- verdict ---------------------------------------------------
    allowed_through = sent - throttled
    if landed > sent:
        return finish(
            "CANNOT_SEE_AUDIT_COUNT_EXCEEDS_WHAT_WAS_SENT",
            f"The audit table reports {landed} reads against {sent} sent, "
            f"so the query is capturing traffic this test did not "
            f"generate. Narrow it by recipient before drawing any "
            f"conclusion -- a count that includes somebody else's reads "
            f"cannot answer this question.")

    out["margin"] = {"sent": sent, "throttled": throttled,
                     "allowed_through": allowed_through, "landed": landed}
    if landed <= allowed_through:
        return finish(
            "EDGE_TRIPS_FIRST_UPSTREAM_SAW_FEWER",
            f"{sent} requests were sent, {throttled} were refused at the "
            f"edge, and Databricks recorded {landed} -- no more than the "
            f"{allowed_through} the edge let through. The throttle is "
            f"protecting compute and not merely answering 429 after the "
            f"fact.\n\nThe positive control is what makes this readable: "
            f"the table was first seen recording a read known to have "
            f"happened, so a low count here is a measurement and not a "
            f"blind spot. AC2 row 2.5 is evidenced.",
            passed=True)

    return finish(
        "EDGE_REFUSED_BUT_THE_UPSTREAM_SAW_THEM_ANYWAY",
        f"{throttled} of {sent} requests were refused at the edge, and "
        f"Databricks recorded {landed} reads -- more than the "
        f"{allowed_through} the edge admitted. The gateway is answering "
        f"429 AFTER forwarding, so the caller is throttled and compute is "
        f"not protected. That is the opposite of what §2.3.3 claims and it "
        f"would be a finding, not a tuning note: clause 2.5's purpose "
        f"fails while every edge-side measurement looks correct.")


if __name__ == "__main__":
    sys.exit(main())
