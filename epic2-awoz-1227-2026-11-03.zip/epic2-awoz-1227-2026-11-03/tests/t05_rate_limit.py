#!/usr/bin/env python3
"""T-05 (edge half): the throttle response, observed verbatim.

E2 Task 2.6 | AC2 clause 2.5 | R9 | CONOPS 2.3.3, 3.1, 3.2

WHAT THIS DOES AND DOES NOT CLAIM
---------------------------------
Task 2.6 makes three assertions. Only the first needs the client
environment, and this test deliberately does not pretend otherwise.

  1. "The edge trips before Databricks." Burst above the limit and
     confirm the Databricks side logged FEWER requests than were sent.
     That is the actual content of clause 2.5 and the one assertion
     configuration cannot satisfy. It needs system.access.audit, which
     needs the system catalog enabled on the metastore. NOT MEASURED
     HERE, and reported as such rather than inferred from the edge
     returning 429.

  2. "The throttle response is recorded as observed." §3.2 wants 429
     with a retry indication and names "record the actual response" as
     the fallback; R9 is the risk that CE does not emit `Retry-After`.
     MEASURED HERE, verbatim: status, every response header, and the
     body.

  3. "Spike arrest and rate limit are distinguishable." Two bursts --
     one fast and small, one slow and large. Task 2.6: "If both produce
     the same response with no way to tell them apart, that is a finding
     worth recording, because operators will need to tell them apart."
     MEASURED HERE.

So this closes two of three, and §3.2's "429 with a retry indication"
row stops reading Unknown. Clause 2.5 stays a named gap.

THE TWO POLICIES ARE NOT KEYED THE SAME WAY
-------------------------------------------
Read off policy-classes.yaml rather than assumed:

    class A   rate-limit     60/min   key = Authorization header
    class A   spike-arrest    5/s     key = NONE

§2.3.3 says "Class settings are per consumer". The rate limit is keyed
per credential; the spike arrest is not keyed at all, so it is one
bucket for the whole API. On this route family that is softened by
accident rather than by design: the family is one API per recipient
(B-42 / D-9 forced that), so a recipient's burst can only exhaust its
own API's bucket. The requirement is met by the ROUTE SHAPE, not by the
key -- which matters because any future consolidation onto a shared
route would silently reintroduce one caller throttling another. Recorded
in the verdict, not left as a comment here.

WHY THE PHASES ARE SPACED THE WAY THEY ARE
------------------------------------------
Both policies count the same requests, so a burst that trips the spike
arrest also spends minute-budget. Phase 1 would otherwise contaminate
phase 2 and the rate-limit trip point would come early for the wrong
reason. Each phase therefore waits out BOTH windows first, and the wait
is recorded so a reader can see the measurement was not rushed.

Phase 2 paces at 0.8s -- 1.25 requests/second, comfortably under the
5/s spike limit -- so that the only limit it can trip is the per-minute
one. A phase that trips both proves nothing about either.
"""

import json
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tests"))

from common import Report, load_env  # noqa: E402
from t01_gateway_read import edge_base, http, scrub  # noqa: E402

import importlib.util  # noqa: E402

POLICY_CLASSES = ROOT / "iac" / "config" / "policy-classes.yaml"
FAMILY = ROOT / "gravitee" / "generated" / "route-family.json"
EVIDENCE = ROOT / "evidence" / "t05-throttle.json"
REPORT = ROOT / "evidence" / "t05-report.json"


def _load(rel, modname):
    spec = importlib.util.spec_from_file_location(modname, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[modname] = mod
    spec.loader.exec_module(mod)
    return mod


P33 = _load("scripts/33_probe_s10_path.py", "t05_p33")

RETRY_HINTS = ("retry-after", "x-ratelimit-reset", "x-rate-limit-reset",
               "ratelimit-reset", "x-ratelimit-remaining",
               "x-ratelimit-limit", "ratelimit-limit", "ratelimit-remaining")


def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def limits_for(pc, cls):
    """The configured limits, read from the CaC source."""
    out = {}
    for step in (pc.get("classes", {}).get(cls, {}).get("request") or []):
        if step.get("policy") not in ("rate-limit", "spike-arrest"):
            continue
        cfg = step.get("configuration") or {}
        inner = cfg.get("rate") or cfg.get("spike") or {}
        out[step["policy"]] = {
            "limit": inner.get("limit"),
            "period": inner.get("periodTime"),
            "unit": inner.get("periodTimeUnit"),
            "key": inner.get("key"),
        }
    return out


def capture(status, body, headers):
    """Everything about one throttle answer, recorded rather than judged."""
    hdrs = {str(k).lower(): v for k, v in (headers or {}).items()}
    retry = {k: v for k, v in hdrs.items()
             if any(h in k for h in RETRY_HINTS)}
    return {
        "status": status,
        "body": scrub(body or "")[:400],
        "body_length": len(body or ""),
        "all_response_headers": sorted(hdrs),
        "retry_indication_headers": retry,
        "has_retry_indication": bool(retry),
    }


def main():
    load_env()
    base, base_how = edge_base()[0], edge_base()[1]

    print("=" * 70)
    print("T-05 (edge half): the throttle response, observed verbatim")
    print("E2 Task 2.6 | AC2 clause 2.5 | R9 | CONOPS 2.3.3, 3.2")
    print("=" * 70)
    print()

    pc = yaml.safe_load(POLICY_CLASSES.read_text())
    lim = limits_for(pc, "A")
    rate = lim.get("rate-limit") or {}
    spike = lim.get("spike-arrest") or {}
    if not (rate.get("limit") and spike.get("limit")):
        print("VERDICT: CANNOT_SEE_NO_LIMITS_DECLARED")
        return 1

    print(f"edge base:    {base}  ({base_how})")
    print(f"class A rate: {rate['limit']}/{rate['period']} "
          f"{rate['unit']}  key={rate['key']}")
    print(f"class A spike:{spike['limit']}/{spike['period']} "
          f"{spike['unit']}  key={spike['key']}")
    if not spike.get("key"):
        print("              ^ spike-arrest is UNKEYED -- one bucket for "
              "the whole API, not per consumer")

    print("\nselecting a live credential:")
    live, tried = P33.pick_live_profile(P33.load_profiles())
    if not live:
        print("\nVERDICT: CANNOT_SEE_NO_LIVE_CREDENTIAL")
        print("  Recipient tokens expire 24h after activation here.")
        return 1
    cred_name, _endpoint, token = live

    family = json.loads(FAMILY.read_text()).get("family") or []
    member = next((m for m in family
                   if (m.get("recipient") or "") in cred_name
                   or (m.get("slug") or "zzz") in cred_name), None)
    if member is None:
        print("\nVERDICT: CANNOT_SEE_CREDENTIAL_NOT_IN_FAMILY")
        return 1
    url = f"{base}{member['edge_path']}/shares"   # S1, class A
    print(f"credential:   {cred_name}")
    print(f"route:        {member['edge_path']}/shares  (S1, class A)")

    out = {"test": "T-05-edge", "at": now(), "edge_base": base,
           "route": f"{member['edge_path']}/shares", "class": "A",
           "credential": cred_name, "credentials_tried": tried,
           "configured_limits": lim, "phases": {}}

    def one():
        return http(url, token)

    # ---- phase 0: positive control --------------------------------
    print("\n--- phase 0: the route answers before anything is burst")
    st, body, hdrs = one()
    out["phases"]["control_before"] = capture(st, body, hdrs)
    print(f"    GET -> {st}")
    if st != 200:
        print("\nVERDICT: CANNOT_SEE_NO_POSITIVE_CONTROL")
        print("    The route did not answer 200, so a 429 later would "
              "not be attributable to a throttle.")
        out["verdict"] = "CANNOT_SEE_NO_POSITIVE_CONTROL"
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps(out, indent=2) + "\n")
        return 1

    # ---- phase 1: spike arrest ------------------------------------
    n_spike = int(spike["limit"]) + 5
    print(f"\n--- phase 1: spike arrest ({spike['limit']}/s) -- "
          f"{n_spike} requests as fast as possible")
    spike_hits, first_spike = [], None
    t0 = time.time()
    for i in range(1, n_spike + 1):
        st, body, hdrs = one()
        spike_hits.append({"n": i, "status": st,
                           "elapsed_s": round(time.time() - t0, 3)})
        if st == 429 and first_spike is None:
            first_spike = capture(st, body, hdrs)
            first_spike["tripped_at_request"] = i
            first_spike["elapsed_s"] = round(time.time() - t0, 3)
    burst_s = round(time.time() - t0, 2)
    codes = {}
    for h in spike_hits:
        codes[h["status"]] = codes.get(h["status"], 0) + 1
    print(f"    {n_spike} requests in {burst_s}s -> {codes}")
    if first_spike:
        print(f"    first 429 at request "
              f"{first_spike['tripped_at_request']} "
              f"({first_spike['elapsed_s']}s)")
        print(f"    retry indication: "
              f"{first_spike['retry_indication_headers'] or 'NONE'}")
    else:
        print("    no 429 -- the burst did not trip the spike arrest")
    out["phases"]["spike"] = {"requests": spike_hits,
                              "burst_seconds": burst_s,
                              "status_counts": {str(k): v for k, v in
                                                codes.items()},
                              "first_429": first_spike}

    # ---- wait out both windows ------------------------------------
    wait = 65
    print(f"\n--- waiting {wait}s so BOTH windows clear")
    print("    Phase 1's requests also spent minute-budget. Without this "
          "wait, phase 2 would trip early and the trip point would mean "
          "nothing.")
    time.sleep(wait)
    out["phases"]["wait_between_s"] = wait

    # ---- phase 2: rate limit --------------------------------------
    rl = int(rate["limit"])
    pace = 0.8          # 1.25/s -- under the 5/s spike limit
    n_rate = rl + 8
    print(f"\n--- phase 2: rate limit ({rl}/min) -- up to {n_rate} "
          f"requests paced at {pace}s ({round(1/pace, 2)}/s, under the "
          f"{spike['limit']}/s spike limit)")
    rate_hits, first_rate = [], None
    t0 = time.time()
    for i in range(1, n_rate + 1):
        if i > 1:
            time.sleep(pace)
        st, body, hdrs = one()
        rate_hits.append({"n": i, "status": st,
                          "elapsed_s": round(time.time() - t0, 2)})
        if st == 429 and first_rate is None:
            first_rate = capture(st, body, hdrs)
            first_rate["tripped_at_request"] = i
            first_rate["elapsed_s"] = round(time.time() - t0, 2)
            break
        if i % 20 == 0:
            print(f"    {i}/{n_rate} ... ({round(time.time()-t0)}s)")
    if first_rate:
        print(f"    first 429 at request "
              f"{first_rate['tripped_at_request']} "
              f"({first_rate['elapsed_s']}s)")
        print(f"    retry indication: "
              f"{first_rate['retry_indication_headers'] or 'NONE'}")
    else:
        print(f"    no 429 in {n_rate} requests -- the per-minute limit "
              f"was not reached")
    out["phases"]["rate"] = {"requests": rate_hits, "pace_s": pace,
                             "first_429": first_rate}

    # ---- phase 3: distinguishable? --------------------------------
    print("\n--- phase 3: can an operator tell the two apart?")
    if first_spike and first_rate:
        same_body = first_spike["body"] == first_rate["body"]
        same_hdrs = (first_spike["retry_indication_headers"]
                     == first_rate["retry_indication_headers"])
        same_status = first_spike["status"] == first_rate["status"]
        identical = same_body and same_hdrs and same_status
        print(f"    same status: {same_status}   same body: {same_body}   "
              f"same retry headers: {same_hdrs}")
        print(f"    -> {'INDISTINGUISHABLE' if identical else 'DISTINGUISHABLE'}")
        out["phases"]["distinguishable"] = {
            "identical": identical, "same_status": same_status,
            "same_body": same_body, "same_retry_headers": same_hdrs,
            "spike_body": first_spike["body"],
            "rate_body": first_rate["body"],
        }
    else:
        print("    CANNOT_SEE -- one of the two did not trip")
        out["phases"]["distinguishable"] = {"verdict": "CANNOT_SEE"}

    # ---- phase 4: recovery ----------------------------------------
    print(f"\n--- phase 4: recovery -- waiting {wait}s, then one request")
    print("    A throttle that does not clear is an outage, not a "
          "throttle. This is the control in the other direction.")
    time.sleep(wait)
    st, body, hdrs = one()
    out["phases"]["control_after"] = capture(st, body, hdrs)
    print(f"    GET -> {st}")

    # ---- phase 5: does the rate-limit KEY separate? ----------------
    #
    # §3.2 claims "rate-limit key from the Authorization header" and
    # §2.3.3 says class settings are per consumer. Phase 2 proves the key
    # is READ and the window counts. It does not prove the key SEPARATES
    # -- a policy keyed on a header that nonetheless shared one bucket
    # would look identical from a single client.
    #
    # The obvious experiment -- two real recipients on one route -- is
    # impossible on this family and that is not a scheduling problem.
    # The platform binds the sharing host to the recipient, so a second
    # recipient's credential is REFUSED on the first's route (T-01b
    # measured exactly that). There is no route on which two legitimate
    # credentials both succeed.
    #
    # So this measures the thing the claim actually asserts: that the
    # bucket is keyed on the Authorization VALUE. A second, deliberately
    # invalid bearer is a different key value. The rate limiter runs in
    # the request phase, before anything is forwarded, so it counts the
    # request regardless of whether the token would authenticate -- which
    # is precisely why an invalid token is a usable probe here and would
    # be useless for anything else.
    #
    # Read the result narrowly. It answers "is the bucket per key?" It
    # does NOT answer "are two consumers isolated on a shared route?",
    # because this family has no shared route. That question stays
    # carried by the route shape, and the route shape stays load-bearing.
    print("\n--- phase 5: does the rate-limit key separate? (\u00a73.2 row)")
    print("    Two REAL consumers on one route is impossible here: the "
          "host/token binding refuses a foreign credential (T-01b). So "
          "the probe is a second KEY VALUE, not a second consumer.")

    other = "t05p5-distinct-key-" + uuid.uuid4().hex
    gate = 0.25          # above the measured 1-per-200ms spike gate

    # re-fill this key's bucket: phase 4 waited out the window
    print(f"    re-filling the bucket for the live key "
          f"({n_rate} requests at {gate}s)...")
    filled = False
    for i in range(n_rate):
        st, body, hdrs = one()
        if st == 429 and "Rate limit" in (body or ""):
            filled = True
            print(f"    bucket full at request {i + 1}")
            break
        time.sleep(gate)

    if not filled:
        print("    CANNOT_SEE -- the bucket did not fill, so a 429 on the "
              "other key would not be attributable to a shared bucket")
        out["phases"]["key_separation"] = {
            "verdict": "CANNOT_SEE_BUCKET_NOT_FULL"}
        key_verdict = "CANNOT_SEE_BUCKET_NOT_FULL"
    else:
        time.sleep(gate)
        st_a1, b_a1, h_a1 = one()                      # control: A still full
        time.sleep(gate)
        st_b, b_b, h_b = http(url, other)              # the probe
        time.sleep(gate)
        st_a2, b_a2, h_a2 = one()                      # control: A still full

        a_both_throttled = st_a1 == 429 and st_a2 == 429
        b_throttled = st_b == 429 and "Rate limit" in (b_b or "")
        print(f"    live key   -> {st_a1}   (control: its bucket is full)")
        print(f"    other key  -> {st_b}")
        print(f"    live key   -> {st_a2}   (control: still full after)")

        if not a_both_throttled:
            key_verdict = "CANNOT_SEE_CONTROL_KEY_NOT_THROTTLED"
            print("    CANNOT_SEE -- the live key stopped being throttled "
                  "mid-probe, so the other key's result is unattributable")
        elif b_throttled:
            key_verdict = "KEY_DOES_NOT_SEPARATE_ONE_BUCKET_PER_API"
            print("    -> the other key was throttled too. The bucket is "
                  "NOT per key, and \u00a73.2's row is false as written.")
        else:
            key_verdict = "KEY_SEPARATES_PER_AUTHORIZATION_VALUE"
            print("    -> the other key was NOT throttled while this one "
                  "was. The bucket is per Authorization value.")

        out["phases"]["key_separation"] = {
            "verdict": key_verdict,
            "control_live_key_before": capture(st_a1, b_a1, h_a1),
            "other_key": capture(st_b, b_b, h_b),
            "control_live_key_after": capture(st_a2, b_a2, h_a2),
            "other_key_is_a_value_not_a_consumer": (
                "The second bearer is syntactically distinct and not "
                "valid. That is deliberate: the rate limiter is a "
                "request-phase policy and counts before forwarding, so "
                "validity is irrelevant to the bucket and a real second "
                "credential is unobtainable on this route anyway."),
            "what_this_does_not_measure": (
                "Two legitimate consumers isolated on a SHARED route. "
                "This family has no shared route -- one API per "
                "recipient (B-42/D-9) -- so that question cannot be "
                "asked here at all. It is not deferred for want of "
                "effort; it has no subject in this topology."),
        }

    # ---- verdict ---------------------------------------------------
    recovered = out["phases"]["control_after"]["status"] == 200
    both_tripped = bool(first_spike and first_rate)
    any_retry = bool((first_spike or {}).get("has_retry_indication")
                     or (first_rate or {}).get("has_retry_indication"))

    if not recovered:
        verdict = "THROTTLE_DID_NOT_CLEAR"
        why = ("The route still refused after the window elapsed. A "
               "throttle that does not clear is an outage, and clause "
               "2.5's purpose is to protect compute, not to remove the "
               "route.")
    elif not both_tripped:
        missing = []
        if not first_spike:
            missing.append("spike arrest")
        if not first_rate:
            missing.append("rate limit")
        verdict = "PARTIAL_ONE_LIMIT_DID_NOT_TRIP"
        why = (f"{' and '.join(missing)} did not produce a 429, so the "
               f"throttle response was only partly observed. Either the "
               f"policy is not running or the burst did not reach the "
               f"limit; the request log in this evidence file shows "
               f"which.")
    elif not any_retry:
        verdict = "THROTTLED_WITH_NO_RETRY_INDICATION"
        why = ("Both limits trip and both clear, and NEITHER 429 carries "
               "a retry indication -- no Retry-After and no rate-limit "
               "headers. That is R9 realised, and §3.2's fallback is "
               "exactly this: record the actual response. A client "
               "cannot know when to retry, so the reference clients "
               "need a backoff of their own and v1.6 should say so "
               "rather than implying the gateway tells them.")
    else:
        verdict = "THROTTLED_WITH_A_RETRY_INDICATION"
        why = ("Both limits trip, both clear, and the 429 carries a "
               "retry indication, so §3.2's row is answered in the "
               "affirmative and R9 does not apply on this version.")

    out["verdict"] = verdict
    out["why"] = why
    out["clause_2_5_not_measured"] = (
        "Clause 2.5 is 'to protect compute resources', and the assertion "
        "that carries it is that the EDGE trips BEFORE Databricks -- "
        "measurable only by comparing the Databricks-side request count "
        "with the number sent. That needs system.access.audit, which "
        "needs the system catalog enabled on the metastore. A 429 at the "
        "edge is consistent with compute being protected and does not "
        "establish it: the gateway could be refusing after forwarding. "
        "NOT MEASURED. Owner: E2 in the client environment.")
    out["key_separation_finding"] = out["phases"].get(
        "key_separation", {}).get("verdict", "NOT_RUN")
    out["per_consumer_finding"] = (
        "§2.3.3 says 'Class settings are per consumer'. rate-limit is "
        "keyed on the Authorization header; spike-arrest is UNKEYED, so "
        "it is one bucket for the whole API. On this family that is "
        "softened by accident and not by design -- one API per recipient "
        "(B-42/D-9) means a recipient can only exhaust its own bucket. "
        "Any future consolidation onto a shared route reintroduces one "
        "caller throttling another, and the route shape is then load-"
        "bearing for a requirement nobody would look for there.")
    out["tuned_values_still_open"] = (
        "Task 2.6 also asks for 'the values the test actually supports, "
        "written back to policy-classes.yaml'. This run does not supply "
        "them and does not invent them: tuning needs the expected "
        "concurrency and payload profile of real consumers, which no "
        "agency has given. The starting values stay labelled as §2.3's "
        "proposals. Writing a tuned number from a single-client burst on "
        "a laptop would be a figure with a provenance nobody could use.")

    rep = Report()
    rep.record("T-05 (edge half)",
               "the throttle response is observed verbatim and the two "
               "limits are distinguishable",
               "both limits produce a 429 whose status, headers and body "
               "are recorded as observed; the route answers 200 before "
               "and after, so a 429 is attributable to a throttle and not "
               "to a broken route",
               verdict,
               verdict in ("THROTTLED_WITH_A_RETRY_INDICATION",
                           "THROTTLED_WITH_NO_RETRY_INDICATION"),
               "evidence/t05-throttle.json")

    EVIDENCE.parent.mkdir(exist_ok=True)
    EVIDENCE.write_text(json.dumps(out, indent=2) + "\n")
    try:
        EVIDENCE.chmod(0o600)
    except OSError:
        pass
    rep.write(REPORT)
    rep.summary()

    print()
    print("=" * 70)
    print(f"T-05 (edge half) VERDICT: {verdict}")
    print("=" * 70)
    print(why)
    print()
    print("Clause 2.5 itself is NOT measured here -- see "
          "clause_2_5_not_measured in the evidence file.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
