#!/usr/bin/env python3
"""T-06: does the gateway enforce the class B request body schema?

E2 Task 2.4 | PC-1 | AC2 | CONOPS 2.3.2 (S8), 2.3.3 (class B), 3.1

WHAT THIS HAS TO SHOW, AND WHY THE OBVIOUS TEST DOES NOT SHOW IT
----------------------------------------------------------------
`scripts/37_gen_query_body_schema.py` generates the schema and
`scripts/29` inlines it into class B's `json-validation` policy. Neither
of those is evidence that the GATEWAY rejects a bad body. A generated
artifact is a claim; this is the measurement.

The obvious test -- post a bad body through the edge and check for 400 --
does not work here, and the reason is the same one that has cost this
repository most of its blockers. Databricks ALSO answers 400 on a
request it dislikes: T-01's S6 row is a direct 400, and T-01b's crossed
route answers 400. So a 400 through the edge identifies nothing on its
own. Reading it as "the schema rejected this" would be B-44 for the
fourth time in this epic.

So every candidate body is sent TWICE in the same run, with the same
credential, seconds apart:

    direct 200  +  gateway 400   -> the GATEWAY rejected a body the
                                    PLATFORM accepts. Attributable, and
                                    the strongest form available: one
                                    variable, and the variable is the
                                    edge.
    direct 400  +  gateway 400   -> both dislike it. Attribution then
                                    rests on the VOICE of the gateway's
                                    body, never on the status.
    gateway 200                  -> not rejected. The schema is inlined
                                    and not enforced, which is worse
                                    than the permissive fallback it
                                    replaced, because the artifact now
                                    claims validation that is not
                                    happening.

ATTRIBUTION BY VOICE
--------------------
A JSON body carrying `errorCode` is Delta Sharing's shape and means the
request was FORWARDED. Anything else, on a 400, is the edge's. The
gateway's own json-validation string is not asserted here from
documentation -- it is RECORDED on first sight and printed, so the next
reader can see what answered rather than trusting this file. That is the
correction scripts/36 needed: its first version read 403 as "the edge
refused" from the status alone, which is wrong because Databricks
returns 403 for an address off a recipient's IP access list.

WHAT THE THREE REJECTIONS ARE FOR
---------------------------------
  R1  an undeclared field          -> additionalProperties: false
  R2  a declared field, wrong
      scalar type (limitHint
      as a string)                 -> whether TYPES are enforced
  R3  a declared field, wrong
      container type
      (predicateHints as a
      string instead of an
      array)                       -> whether NESTED types are enforced

R2 and R3 are the ones that matter for honesty. route-table.yaml carries
the field types with
`provenance: DELTA_SHARING_PROTOCOL_SPEC_NOT_MEASURED_HERE` -- they come
from the protocol specification, not from anything measured here. If R2
and R3 are accepted while R1 is rejected, then only the field NAMES are
enforced, the types are decorative, and the route table must say so
instead of implying a check it does not get.

THE ACCEPTANCES
---------------
  A1  {}                  -- T-01's own body, already known to return
                             200. Included so this test carries its own
                             positive control rather than depending on
                             another test having run.
  A2  {"limitHint": 10}   -- a declared field with its declared type.
                             Stronger than A1: it shows a NAMED, TYPED
                             field passes, so a rejection in R1-R3 is
                             about what was wrong with that body and not
                             about the schema refusing everything.

An over-strict schema is a real risk and not a hypothetical one: it
would make the gateway stricter than the platform it fronts, which
breaks a working reference client while every perimeter test stays
green, and quietly falsifies §3.4.1's promise that only the endpoint
changes. A1 and A2 are what stop that going unnoticed.

NOT TESTED HERE
---------------
Mutual exclusivity of version/timestamp against
startingVersion/endingVersion. The protocol treats them as alternatives;
§2.3.2 does not say so and the generated schema deliberately does not
encode it (see scripts/37). Testing a rule the schema does not claim
would measure nothing.
"""

import importlib.util
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tests"))

from common import Report  # noqa: E402

EVIDENCE = ROOT / "evidence" / "t06-body-schema.json"
REPORT = ROOT / "evidence" / "t06-report.json"
SCHEMA = ROOT / "iac" / "gravitee" / "schemas" / "query-body.schema.json"

PACE = 1.1  # class B spike-arrest is 2/s; T-01 tripped its own throttle


def _load(rel, modname):
    spec = importlib.util.spec_from_file_location(modname, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[modname] = mod
    spec.loader.exec_module(mod)
    return mod


# scripts/36 already resolves the edge base and matches a credential to
# its member of the route family; scripts/33 already picks a credential
# by "answers 200" rather than by name. Copying either would be B-39.
P36 = _load("scripts/36_probe_unlisted_paths.py", "t06_p36")
P33 = P36.P33
call = P33.call


def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def attribute(direct_status, gw_status, gw_body):
    """Who rejected this body, decided on the gateway's voice."""
    doc, _ = P33.parse_json(gw_body, "gateway")
    upstream_shaped = isinstance(doc, dict) and bool(doc.get("errorCode"))

    if gw_status == 200:
        return ("NOT_REJECTED", False,
                "The gateway accepted this body. If it was meant to be "
                "refused, the inlined schema is not being enforced -- "
                "which is worse than the permissive fallback it replaced, "
                "because the generated artifact now claims a validation "
                "that is not happening.")
    if gw_status == 429:
        return ("CANNOT_SEE_THROTTLED", None,
                "429 is the gateway declining to ask the question.")
    if gw_status in (0, None):
        return ("CANNOT_SEE_TRANSPORT_ERROR", None,
                "No answer reached this test.")
    if upstream_shaped:
        return (f"FORWARDED_UPSTREAM_{gw_status}", False,
                "The gateway's body is Delta Sharing's shape, carrying "
                "errorCode, so this body was FORWARDED and the upstream "
                "refused it. json-validation did not stop it.")
    if direct_status == 200:
        return ("EDGE_REJECTED_PLATFORM_ACCEPTED", True,
                "The strongest form available: the same credential, same "
                "path, same body, seconds apart -- accepted directly and "
                "refused through the edge, and the refusal is not in the "
                "upstream's error vocabulary. One variable, and it is the "
                "gateway.")
    return ("EDGE_REJECTED_BUT_PLATFORM_ALSO_REFUSES", True,
            "The gateway refused in its own voice rather than the "
            "upstream's, so json-validation is the most likely refuser -- "
            "but the platform refuses this body too, so this row is "
            "weaker evidence than one where the direct read succeeds. "
            "Recorded as attributable with that caveat, not as equal to "
            "an EDGE_REJECTED_PLATFORM_ACCEPTED row.")


def main():
    P36.load_env()
    base, base_how = P36.edge_base()

    print("=" * 68)
    print("T-06: the gateway enforces the class B request body schema")
    print("E2 Task 2.4 | PC-1 | AC2 | CONOPS 2.3.2, 2.3.3, 3.1")
    print("=" * 68)
    print()

    if not SCHEMA.exists():
        print(f"VERDICT: CANNOT_SEE_NO_SCHEMA")
        print(f"  {SCHEMA.relative_to(ROOT)} does not exist. Run "
              f"scripts/37_gen_query_body_schema.py, then scripts/29 and "
              f"scripts/05, or this test measures the permissive fallback "
              f"and calls it a result.")
        return 1
    schema = json.loads(SCHEMA.read_text())
    declared = sorted(schema.get("properties") or {})
    print(f"schema:    {SCHEMA.relative_to(ROOT)}")
    print(f"           {len(declared)} fields, "
          f"additionalProperties={schema.get('additionalProperties')}")
    print(f"edge base: {base}  ({base_how})")

    family = json.loads((ROOT/"gravitee"/"generated"/"route-family.json")
                        .read_text()).get("family") or []

    print("\nselecting a live credential:")
    live, tried = P33.pick_live_profile(P33.load_profiles())
    if not live:
        print("\nVERDICT: CANNOT_SEE_NO_LIVE_CREDENTIAL")
        print("  Every credential on disk was refused. Recipient tokens "
              "expire 24h after activation on this platform, measured -- "
              "rotate with scripts/27 --rotate-token <name> "
              "--rotate-overlap-seconds 0 then scripts/28 --recipient "
              "<name> --activate.")
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps(
            {"at": now(), "verdict": "CANNOT_SEE_NO_LIVE_CREDENTIAL",
             "credentials_tried": tried}, indent=2) + "\n")
        return 1
    cred_name, direct_endpoint, token = live

    member = next((m for m in family
                   if (m.get("recipient") or "") in cred_name
                   or (m.get("slug") or "zzz") in cred_name), None)
    if member is None:
        print("\nVERDICT: CANNOT_SEE_CREDENTIAL_NOT_IN_FAMILY")
        return 1
    prefix = base + member["edge_path"]
    print(f"credential: {cred_name}")
    print(f"edge path:  {member['edge_path']}")

    print("\ndiscovering a real share/schema/table (direct):")
    triple, err = P33.discover(direct_endpoint, token)
    if not triple or not all(triple):
        print(f"\nVERDICT: CANNOT_SEE_NO_DISCOVERY\n  {err}")
        return 1
    share, sch, table = triple
    print(f"    share={share}  schema={sch}  table={table}")
    path = f"/shares/{share}/schemas/{sch}/tables/{table}/query"

    cases = [
        {"id": "A1", "expect": "accept", "body": {},
         "because": "T-01's own body. This test's own positive control, so "
                    "it does not depend on T-01 having run."},
        {"id": "A2", "expect": "accept", "body": {"limitHint": 10},
         "because": "a declared field with its declared type -- shows a "
                    "named, typed field passes"},
        {"id": "R1", "expect": "reject", "body": {"notAField": 1},
         "because": "undeclared field; tests additionalProperties:false"},
        {"id": "R2", "expect": "reject", "body": {"limitHint": "ten"},
         "because": "declared field, wrong SCALAR type; tests whether the "
                    "declared types are enforced at all"},
        {"id": "R3", "expect": "reject",
         "body": {"predicateHints": "not-an-array"},
         "because": "declared field, wrong CONTAINER type; tests whether "
                    "nested types are enforced"},
    ]

    rows = []
    print(f"\n--- POST {path}")
    print("    (each body sent DIRECT and through the EDGE, same run)")
    voices = {}
    for i, c in enumerate(cases):
        if i:
            time.sleep(PACE)
        d_st, d_raw = call(direct_endpoint, token, path, "POST", c["body"])
        time.sleep(PACE)
        g_st, g_raw = call(prefix, token, path, "POST", c["body"])
        label, rejected, why = attribute(d_st, g_st, g_raw)

        if label.startswith("EDGE_REJECTED"):
            voices.setdefault(str(g_st), (g_raw or "")[:160])

        ok = (c["expect"] == "accept" and g_st == 200) or \
             (c["expect"] == "reject" and rejected is True)
        rows.append({**c, "direct_status": d_st, "gateway_status": g_st,
                     "attribution": label, "edge_rejected": rejected,
                     "why": why, "as_expected": ok,
                     "gateway_body_head": (g_raw or "")[:300],
                     "direct_body_head": (d_raw or "")[:200]})
        print(f"    {c['id']}  expect {c['expect']:<6} "
              f"direct {d_st!s:<4} gateway {g_st!s:<4} "
              f"{label:<34} {'OK' if ok else 'NOT AS EXPECTED'}")

    if voices:
        print("\n    gateway refusal voice, recorded on first sight:")
        for st, v in sorted(voices.items()):
            print(f"      {st}  {v!r}")

    accepts = [r for r in rows if r["expect"] == "accept"]
    rejects = [r for r in rows if r["expect"] == "reject"]
    n_rej = sum(1 for r in rejects if r["edge_rejected"] is True)
    types_enforced = all(r["edge_rejected"] is True
                         for r in rejects if r["id"] in ("R2", "R3"))
    names_enforced = any(r["edge_rejected"] is True
                         for r in rejects if r["id"] == "R1")

    if any(r["gateway_status"] != 200 for r in accepts):
        verdict = "SCHEMA_IS_OVER_STRICT"
        why = ("A body the schema declares valid was refused through the "
               "edge. The gateway is now stricter than the platform it "
               "fronts, which breaks a working reference client while "
               "every perimeter test stays green and falsifies §3.4.1's "
               "promise that only the endpoint changes. This is worse "
               "than no validation.")
    elif any(r["edge_rejected"] is None for r in rejects):
        verdict = "PARTIAL_SOME_ROWS_OBSERVED_NOTHING"
        why = "At least one rejection row produced no attributable answer."
    elif n_rej == len(rejects):
        verdict = "BODY_SCHEMA_ENFORCED_NAMES_AND_TYPES"
        why = ("Three rejections and two acceptances, each body sent "
               "direct and through the edge in the same run. Undeclared "
               "fields, wrong scalar types and wrong container types are "
               "all refused at the edge, and both valid bodies pass. The "
               "field types in route-table.yaml were declared with "
               "provenance DELTA_SHARING_PROTOCOL_SPEC_NOT_MEASURED_HERE; "
               "R2 and R3 are what convert them to measured.")
    elif names_enforced and not types_enforced:
        verdict = "BODY_SCHEMA_ENFORCES_NAMES_ONLY_TYPES_ARE_DECORATIVE"
        why = ("The undeclared field was refused, so additionalProperties "
               "is enforced -- but a declared field with the wrong type "
               "was accepted. The types in route-table.yaml therefore do "
               "NOT constrain, and the route table must say so rather "
               "than implying a check it does not get. PC-1 cannot close "
               "as fully verified on this result.")
    else:
        verdict = "BODY_SCHEMA_NOT_ENFORCED"
        why = ("Bodies the schema forbids were accepted through the edge. "
               "The schema is inlined and inert, which is worse than the "
               "permissive fallback it replaced: the artifact claims a "
               "validation that is not happening.")

    rep = Report()
    rep.record(
        "T-06", "the gateway rejects a request body the schema forbids",
        "three forbidden bodies refused at the edge and both valid bodies "
        "accepted, each sent direct and through the gateway in the same "
        "run with the same credential -- the direct call being the "
        "same-path positive control B-40 requires",
        verdict, verdict == "BODY_SCHEMA_ENFORCED_NAMES_AND_TYPES",
        "evidence/t06-body-schema.json")

    EVIDENCE.parent.mkdir(exist_ok=True)
    EVIDENCE.write_text(json.dumps({
        "at": now(), "test": "T-06", "verdict": verdict, "why": why,
        "schema": str(SCHEMA.relative_to(ROOT)),
        "schema_fields": declared,
        "additional_properties": schema.get("additionalProperties"),
        "edge_base": base, "edge_path": member["edge_path"],
        "credential": cred_name, "credentials_tried": tried,
        "protocol_path": path,
        "gateway_refusal_voices_recorded": voices,
        "names_enforced": names_enforced,
        "types_enforced": types_enforced,
        "cases": rows,
        "attribution_rule": (
            "Decided on the gateway's VOICE, not its status. Databricks "
            "also answers 400 (T-01's S6 row, T-01b's crossed route), so "
            "a 400 through the edge identifies nothing on its own. A JSON "
            "body carrying errorCode is Delta Sharing's shape and means "
            "the body was forwarded."),
        "not_tested": (
            "Mutual exclusivity of version/timestamp against "
            "startingVersion/endingVersion. The generated schema does not "
            "encode it, so testing it would measure nothing."),
    }, indent=2) + "\n")
    try:
        EVIDENCE.chmod(0o600)
    except OSError:
        pass
    rep.write(REPORT)
    rep.summary()

    print()
    print("=" * 68)
    print(f"T-06 VERDICT: {verdict}")
    print("=" * 68)
    print(why)
    return 0 if verdict == "BODY_SCHEMA_ENFORCED_NAMES_AND_TYPES" else 1


if __name__ == "__main__":
    sys.exit(main())
