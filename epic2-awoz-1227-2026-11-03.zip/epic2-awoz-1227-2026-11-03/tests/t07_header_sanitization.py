#!/usr/bin/env python3
"""T-07: internal headers do not reach the client.

E2 Task 2.6 | AC2 | CONOPS 2.1 step 5, 2.3.2 (S7 passthrough), 2.3.3, 3.1

THE OBSERVATION THIS TEST STARTS FROM
-------------------------------------
Every T-01 run since the route family was built has reported:

    headers leaked through the edge (T-07 input):
        x-gravitee-request-id, x-gravitee-transaction-id

And yet `policy-classes.yaml` common.response ALREADY carries a
`transform-headers` step, `enabled: true`, whose `removeHeaders` list
names `X-Gravitee-Request-Id` and `X-Gravitee-Transaction-Id`
explicitly, and the generated definition carries that step on every
flow. So the configuration says these headers are removed and the wire
says they are not. One of those is wrong and the point of this test is
to find out which, rather than to re-assert either.

Three candidate causes, and the test is built to separate them:

  H1  The policy does not run at all.
  H2  `removeHeaders` matches header names CASE-SENSITIVELY. The config
      spells them `X-Gravitee-Request-Id`; the gateway emits them
      lowercase. Note that someone already suspected this -- the same
      list carries `x-request-id` and `server-timing` in lowercase while
      its other entries are capitalised, which is a list that has been
      guessed at more than once.
  H3  The gateway stamps these headers AFTER the response policy chain
      has run, in which case no policy can remove them and this is a
      platform limit of the same kind as PC-4, not a misconfiguration.

WHY A HEADER'S ABSENCE IS NOT EVIDENCE OF REDACTION
---------------------------------------------------
This is the trap that makes the naive version of this test worthless. If
the upstream never sends `X-Databricks-Org-Id` on a given route, then
that header is absent through the edge whatever the policy does, and
counting it as a redaction would credit the sanitizer with work nobody
did. The remove-list has eight entries and most of them would pass that
way.

So every header is read BOTH directly and through the edge in the same
run, with the same credential, and classified on the pair:

    direct present, edge absent    -> REDACTED (measured)
    direct present, edge present   -> SURVIVED_FROM_UPSTREAM (a leak)
    direct absent,  edge present   -> GATEWAY_ORIGIN_SURVIVED (a leak,
                                      and the gateway put it there)
    direct absent,  edge absent    -> CANNOT_SEE_UPSTREAM_NEVER_SENT_IT

Only the first is evidence that the sanitizer works. H1 is settled by
whether ANY header reaches REDACTED: a policy that removes nothing it
was asked to remove is a policy that is not running.

THE CONFIGURATION IS DERIVED, NOT RESTATED
------------------------------------------
The remove-list, the must-not-remove list and S7's passthrough headers
are all read out of `policy-classes.yaml` and `route-table.yaml` at run
time. Typing them here would put them in the repository twice and the
copy nobody updates would be the test -- which would then pass while the
config said something else. B-39, which has cost six defects here.

THE OTHER HALF OF §2.3.2, WHICH IS EASY TO FORGET
-------------------------------------------------
§2.3.2 requires `delta-sharing-capabilities` to PASS THROUGH on S7, and
`policy-classes.yaml` records why beside the remove-list:

    "The sanitizer and the passthrough requirement meet on that one
     route, and a remove-list written as 'strip everything
     unrecognised' takes this one with it. Allow-list the removals,
     never deny-list them."

A sanitizer that strips the capability header passes a naive leak test
and breaks the protocol. So phase 3 checks that header SURVIVES, and a
failure there is a failure of this test, not a footnote.

PHASE 4 MUTATES THE LIVE API
----------------------------
Separating H2 from H3 cannot be done by observation alone: both produce
"the header is still there". So phase 4 adds the lowercase spellings to
the remove-list on the live definition, re-measures, and puts the
original back -- the arm / measure / restore shape T-03 established,
with the pre-change definition written to disk first as a restore source
for a crash. If the headers vanish, it was H2 and the fix is a config
edit. If they persist with both spellings present, it is H3 and belongs
in the register as an accepted limit with a named consequence.
"""

import json
import sys
import time
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tests"))

from common import Report, load_env  # noqa: E402
# Imported, not copied -- same reason t03 gives for doing it.
from t01_gateway_read import edge_base, http, scrub  # noqa: E402
from t03_ip_refusal import deploy, find_api, mgmt, put_api  # noqa: E402

import importlib.util  # noqa: E402

EVIDENCE = ROOT / "evidence" / "t07-header-sanitization.json"
REPORT = ROOT / "evidence" / "t07-report.json"
SNAPSHOT = ROOT / "evidence" / "t07-api-snapshot-before.json"
POLICY_CLASSES = ROOT / "iac" / "config" / "policy-classes.yaml"
ALLOWLIST = ROOT / "iac" / "config" / "response-header-allowlist.yaml"

# The two verdicts that are a pass. The second carries a refusal residue
# that the allow-list config declares accepted (B-55 / A-5): the control
# is complete on everything it can reach, and what it cannot reach is a
# named, non-closable deferral rather than a defect. The acceptance is an
# exact set -- a refusal carrying anything outside it produces
# REFUSALS_LEAK_BEYOND_THE_DECLARED_RESIDUE and fails.
PASSING_VERDICTS = {
    "INTERNAL_HEADERS_REMOVED_AND_PASSTHROUGH_PRESERVED",
    "INTERNAL_HEADERS_REMOVED_WITH_A_NAMED_REFUSAL_RESIDUE",
}
ROUTE_TABLE = ROOT / "iac" / "config" / "route-table.yaml"
FAMILY_FILE = ROOT / "gravitee" / "generated" / "route-family.json"

PACE = 1.1  # class C spike-arrest is 1/s; T-01 tripped its own throttle

# Headers that are internal by nature. Used ONLY to notice names the
# configured remove-list does not mention -- never to decide whether a
# configured removal worked.
INTERNAL_HINTS = ("x-gravitee", "x-request-id", "x-correlation",
                  "server-timing", "via", "x-databricks", "x-envoy",
                  "x-powered-by",
                  # Used only by the gateway-config experiment: if the
                  # handlers.request.*.header env var takes effect, the
                  # renamed header shows up here, which is the positive
                  # control proving the env var path is right at all. A
                  # config change that is silently ignored and a config
                  # change that does not help look identical without it.
                  "x-probe")


def _load(rel, modname):
    spec = importlib.util.spec_from_file_location(modname, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[modname] = mod
    spec.loader.exec_module(mod)
    return mod


P33 = _load("scripts/33_probe_s10_path.py", "t07_p33")


def declared_config():
    """The remove-list, the must-not-remove list and S7's passthrough
    headers, read from the CaC source rather than typed here."""
    pc = yaml.safe_load(POLICY_CLASSES.read_text())
    remove, must_keep, steps = [], [], []
    for row in (pc.get("common", {}).get("response") or []):
        if row.get("policy") != "transform-headers":
            continue
        cfg = row.get("configuration") or row.get("configuration_fallback") or {}
        remove += list(cfg.get("removeHeaders") or [])
        must_keep += list(row.get("must_not_remove") or [])
        steps.append({"name": row.get("name"),
                      "enabled": row.get("enabled")})

    rt = yaml.safe_load(ROUTE_TABLE.read_text())
    passthrough = {}
    for r in (rt.get("routes") or []):
        ph = r.get("passthrough_headers")
        if ph:
            passthrough[r["id"]] = list(ph)
            must_keep += list(ph)

    # The allow-list (Task 2.8, PC-5/RF-4). `transform-headers` cannot
    # express "keep only these" and no installed policy can, so the
    # allow-list is enforced HERE instead of at the edge -- stated in
    # the file itself rather than implied.
    allowed, added = [], []
    if ALLOWLIST.exists():
        al = yaml.safe_load(ALLOWLIST.read_text()) or {}
        for group in (al.get("allowed") or {}).values():
            allowed += [h.lower() for h in (group.get("headers") or [])]
        added = [h.lower() for h in
                 ((al.get("allowed") or {}).get("deliberate_exception")
                  or {}).get("headers") or []]

    return {"remove": remove, "must_keep": sorted(set(must_keep)),
            "passthrough_by_route": passthrough, "steps": steps,
            "allowed": sorted(set(allowed)),
            "must_be_present": sorted(set(added)),
            "allowlist_file": (str(ALLOWLIST.relative_to(ROOT))
                               if ALLOWLIST.exists() else None)}


def lower_keys(hdrs):
    return {str(k).lower(): v for k, v in (hdrs or {}).items()}


def classify(name, direct, gw):
    """Classify one configured removal on the DIRECT/EDGE pair."""
    n = name.lower()
    d_has, g_has = n in direct, n in gw
    if d_has and not g_has:
        return ("REDACTED", True,
                "Present directly and absent through the edge, same "
                "credential and same run. The only pairing that is "
                "evidence the sanitizer did something.")
    if d_has and g_has:
        return ("SURVIVED_FROM_UPSTREAM", False,
                "The upstream sent it and it reached the client. The "
                "remove-list names it, so this is a leak.")
    if g_has and not d_has:
        return ("GATEWAY_ORIGIN_SURVIVED", False,
                "Absent from the upstream's own response, present "
                "through the edge: the GATEWAY added it, and the "
                "remove-list that names it did not take it off.")
    return ("CANNOT_SEE_UPSTREAM_NEVER_SENT_IT", None,
            "Absent in both. Its absence through the edge is not "
            "evidence of redaction -- nothing sent it, so nothing had "
            "to be removed.")


def read_pair(direct_endpoint, prefix, token, path):
    d_st, _, d_h = http(direct_endpoint.rstrip("/") + path, token)
    time.sleep(PACE)
    g_st, _, g_h = http(prefix + path, token)
    return (d_st, lower_keys(d_h)), (g_st, lower_keys(g_h))


def main():
    load_env()
    base, base_how = edge_base()[0], edge_base()[1]

    print("=" * 68)
    print("T-07: internal headers do not reach the client")
    print("E2 Task 2.6 | AC2 | CONOPS 2.1 step 5, 2.3.2, 2.3.3, 3.1")
    print("=" * 68)
    print()

    cfg = declared_config()
    print(f"edge base:   {base}  ({base_how})")
    print(f"remove-list: {len(cfg['remove'])} header(s), derived from "
          f"policy-classes.yaml")
    print(f"must keep:   {cfg['must_keep']}  "
          f"(§2.3.2 passthrough: {cfg['passthrough_by_route']})")
    for s in cfg["steps"]:
        print(f"             step {s['name']!r} enabled={s['enabled']}")
    if not cfg["remove"]:
        print("\nVERDICT: CANNOT_SEE_NO_REMOVE_LIST_DECLARED")
        return 1

    print("\nselecting a live credential:")
    live, tried = P33.pick_live_profile(P33.load_profiles())
    if not live:
        print("\nVERDICT: CANNOT_SEE_NO_LIVE_CREDENTIAL")
        print("  Recipient tokens expire 24h after activation on this "
              "platform (measured). Rotate with scripts/27 --rotate-token "
              "<name> --rotate-overlap-seconds 0, archive the stale "
              "credential, then scripts/28 --recipient <name> --activate.")
        return 1
    cred_name, direct_endpoint, token = live

    family = json.loads(FAMILY_FILE.read_text()).get("family") or []
    member = next((m for m in family
                   if (m.get("recipient") or "") in cred_name
                   or (m.get("slug") or "zzz") in cred_name), None)
    if member is None:
        print("\nVERDICT: CANNOT_SEE_CREDENTIAL_NOT_IN_FAMILY")
        return 1
    prefix = base + member["edge_path"]
    print(f"credential:  {cred_name}")
    print(f"edge path:   {member['edge_path']}")

    out = {"test": "T-07", "credential": cred_name,
           "credentials_tried": tried, "edge_base": base,
           "edge_path": member["edge_path"], "declared": cfg}

    # ---------------------------------------------------------------- 1
    print("\n--- phase 1: the configured remove-list, on /shares")
    print("    (each header read DIRECT and through the EDGE, same run)")
    (d_st, d_h), (g_st, g_h) = read_pair(direct_endpoint, prefix, token,
                                         "/shares")
    print(f"    direct {d_st}   gateway {g_st}")
    if d_st != 200 or g_st != 200:
        print("\nVERDICT: CANNOT_SEE_NO_CONTROL")
        print("  /shares did not return 200 on both sides, so no header "
              "pair is attributable. B-40.")
        out["verdict"] = "CANNOT_SEE_NO_CONTROL"
        EVIDENCE.parent.mkdir(exist_ok=True)
        EVIDENCE.write_text(json.dumps(out, indent=2) + "\n")
        return 1

    rows = []
    for name in cfg["remove"]:
        label, ok, why = classify(name, d_h, g_h)
        rows.append({"header": name, "verdict": label, "redacted": ok,
                     "why": why,
                     "present_direct": name.lower() in d_h,
                     "present_gateway": name.lower() in g_h})
        mark = {True: "redacted", False: "LEAKED",
                None: "not sent upstream"}[ok]
        print(f"    {name:<28} {label:<34} {mark}")
    out["remove_list_results"] = rows
    # Task 2.8: "Include the before capture in the evidence -- a
    # sanitization control with no record of what it removed is
    # unauditable." The direct read IS the before (the upstream's own
    # response, unsanitized) and the gateway read is the after, same
    # credential and same run.
    out["capture_shares"] = {
        "path": "/shares",
        "before_direct_header_names": sorted(d_h),
        "after_gateway_header_names": sorted(g_h),
        "removed_by_the_edge": sorted(set(d_h) - set(g_h)),
        "added_by_the_edge": sorted(set(g_h) - set(d_h)),
    }

    redacted = [r for r in rows if r["redacted"] is True]
    leaked = [r for r in rows if r["redacted"] is False]
    unseen = [r for r in rows if r["redacted"] is None]
    policy_runs = bool(redacted)

    print(f"\n    {len(redacted)} measured redaction(s), {len(leaked)} "
          f"leak(s), {len(unseen)} not sent by the upstream")
    print(f"    policy demonstrably running: {policy_runs}  "
          f"{'(H1 excluded)' if policy_runs else '(H1 LIVE -- see verdict)'}")
    out["policy_demonstrably_runs"] = policy_runs

    # ---------------------------------------------------------------- 2
    print("\n--- phase 2: the allow-list -- every surviving header must be "
          "named")
    declared_lower = {h.lower() for h in cfg["remove"]}
    keep_lower = {h.lower() for h in cfg["must_keep"]}
    if cfg["allowlist_file"]:
        # A real allow-list: anything reaching the client that is not
        # named is a failure, whether or not it looks internal. The
        # hint-based version below could only find leaks that resembled
        # leaks already thought of, which is the deny-list weakness
        # Task 2.8 objects to, one level up.
        print(f"    source: {cfg['allowlist_file']}  "
              f"({len(cfg['allowed'])} permitted)")
        unlisted = sorted(h for h in g_h if h not in set(cfg["allowed"]))
        for h in unlisted:
            hint = " (internal-looking)" if any(
                k in h for k in INTERNAL_HINTS) else ""
            print(f"    {h:<28} NOT_ON_THE_ALLOW_LIST{hint}")
        out["allow_list_enforced"] = True
    else:
        print("    NO ALLOW-LIST FILE -- falling back to name hints, which "
              "can only find leaks that resemble known leaks")
        unlisted = sorted(h for h in g_h
                          if any(k in h for k in INTERNAL_HINTS)
                          and h not in declared_lower
                          and h not in keep_lower)
        for h in unlisted:
            print(f"    {h:<28} UNLISTED_INTERNAL_HEADER")
        out["allow_list_enforced"] = False
    if not unlisted:
        print("    none")
    out["unlisted_internal_headers"] = unlisted

    # The deliberate exception must be PRESENT, not merely permitted.
    # Task 2.8 keeps one on purpose because AC5's trace needs a handle
    # the caller can see; a sanitizer that removes every id passes a
    # leak test and leaves AC5 with nothing to trace by.
    missing_required = []
    if cfg["must_be_present"]:
        print("\n    deliberate exception -- must REACH the client:")
        for h in cfg["must_be_present"]:
            there = h in g_h
            if not there:
                missing_required.append(h)
            print(f"    {h:<28} "
                  f"{'PRESENT' if there else 'ABSENT -- AC5 HAS NO HANDLE'}")
    out["required_present"] = {"headers": cfg["must_be_present"],
                               "missing": missing_required}

    # ---------------------------------------------------------------- 3
    print("\n--- phase 3: §2.3.2 passthrough -- the capability header must "
          "SURVIVE")
    triple, derr = P33.discover(direct_endpoint, token)
    keep_rows = []
    if not triple or not all(triple):
        print(f"    CANNOT_SEE: {derr}")
        out["passthrough"] = {"verdict": "CANNOT_SEE_NO_DISCOVERY",
                              "why": derr}
    else:
        share, sch, tbl = triple
        s7 = f"/shares/{share}/schemas/{sch}/tables/{tbl}/metadata"
        time.sleep(PACE)
        (d2_st, d2_h), (g2_st, g2_h) = read_pair(direct_endpoint, prefix,
                                                 token, s7)
        print(f"    S7 metadata: direct {d2_st}  gateway {g2_st}")
        for name in cfg["must_keep"]:
            n = name.lower()
            if n not in d2_h:
                v, ok = "CANNOT_SEE_UPSTREAM_NEVER_SENT_IT", None
                why = ("The upstream did not send this header on S7, so "
                       "whether the sanitizer would have preserved it is "
                       "not observable here.")
            elif n in g2_h:
                v, ok = "SURVIVED_AS_REQUIRED", True
                why = "Present directly and through the edge, as §2.3.2 requires."
            else:
                v, ok = "STRIPPED_IN_VIOLATION_OF_2_3_2", False
                why = ("The upstream sent it and the edge removed it. A "
                       "sanitizer that takes this header passes a naive "
                       "leak test and breaks the protocol.")
            keep_rows.append({"header": name, "verdict": v, "ok": ok,
                              "why": why})
            print(f"    {name:<28} {v}")
        out["passthrough"] = {"path": s7, "direct_status": d2_st,
                              "gateway_status": g2_st, "headers": keep_rows}
        out["capture_s7"] = {
            "path": s7,
            "before_direct_header_names": sorted(d2_h),
            "after_gateway_header_names": sorted(g2_h),
            "removed_by_the_edge": sorted(set(d2_h) - set(g2_h)),
            "added_by_the_edge": sorted(set(g2_h) - set(d2_h)),
        }

    # ---------------------------------------------------------------- 3b
    # B-55. Added 2026-10-30 after T-05 found this by accident.
    #
    # Every reading above is from a 200 -- a response the UPSTREAM
    # produced, which the response-phase chain then sanitized. A
    # response produced by a POLICY never reaches that chain: a
    # request-phase policy that interrupts answers immediately, and the
    # response phase does not run. That is PC-4's measured finding,
    # reached from the other direction.
    #
    # So the sanitizer's coverage is exactly the set of responses it was
    # tested on, and until 2026-10-30 that was successful reads only.
    # T-05 then recorded a 429 whose headers carried
    # x-gravitee-client-identifier -- the header this epic spent ten days
    # getting onto the remove-list -- because a throttle is an
    # interrupting response. Found by a test looking for something else,
    # which is the definition of a gap nobody was checking.
    print("\n--- phase 3b: do REFUSALS get sanitized too? (B-55)")
    print("    Every check above was on a 200, which the upstream "
          "produced. A policy's own refusal never reaches the response "
          "chain.")
    refusal_rows = []
    allowed_set = set(cfg["allowed"])
    for label, path, method in (
            ("unlisted path (route X, 403)", "/api/2.0/token/list", "GET"),
            ("wrong method on a listed path (405)", "/shares", "DELETE"),
    ):
        time.sleep(PACE)
        st, _, rh = http(prefix + path, token, method=method)
        rl = lower_keys(rh)
        # NAMED refusal_leaked, not `leaked`. Phase 1 binds `leaked` to a
        # list of row DICTS and the verdict chain below iterates it as
        # such; this loop would shadow it with a list of header-name
        # STRINGS. That shadowing sat here harmlessly for as long as the
        # refusal branch short-circuited the verdict chain before the
        # phase-1 branch could run -- and crashed the moment refusals
        # started passing. A latent fault is one an unrelated fix
        # discovers.
        refusal_leaked = sorted(h for h in rl if h not in allowed_set)
        internal = sorted(h for h in refusal_leaked
                          if any(k in h for k in INTERNAL_HINTS))
        refusal_rows.append({
            "probe": label, "path": path, "method": method, "status": st,
            "header_names": sorted(rl),
            "not_on_the_allow_list": refusal_leaked,
            "internal_looking": internal,
            "clean": not refusal_leaked,
        })
        print(f"    {label:<40} {str(st):<5} "
              f"{'clean' if not refusal_leaked else 'LEAKS ' + ', '.join(refusal_leaked)}")
    out["refusal_headers"] = {
        "probes": refusal_rows,
        "why_this_is_separate": (
            "A 200 is sanitized because the upstream produced it and the "
            "response chain ran. A policy's refusal interrupts in the "
            "request phase, so the response chain never runs and nothing "
            "removes what the gateway attached. Same structural limit as "
            "PC-4, which measured that a response-phase reason carrier "
            "does not run after an interrupting policy."),
        "found_by": (
            "T-05, 2026-10-30, which recorded a 429's headers while "
            "measuring something else entirely."),
    }

    # ---------------------------------------------------------------- 4
    gateway_origin = [r for r in rows
                      if r["verdict"] == "GATEWAY_ORIGIN_SURVIVED"]
    if gateway_origin and "--no-mutate" not in sys.argv:
        print("\n--- phase 4: H2 vs H3 -- does a lowercase spelling remove "
              "them?")
        names = [r["header"] for r in gateway_origin]
        print(f"    survivors: {names}")
        session, mbase = mgmt()
        api_id, body = find_api(session, mbase, member["edge_path"])
        if not api_id:
            print("    CANNOT_SEE: no live API at that context path")
            out["case_experiment"] = {"verdict": "CANNOT_SEE_NO_LIVE_API"}
        else:
            SNAPSHOT.parent.mkdir(exist_ok=True)
            SNAPSHOT.write_text(json.dumps(body, indent=2) + "\n")
            try:
                SNAPSHOT.chmod(0o600)
            except OSError:
                pass
            print(f"    snapshot:  {SNAPSHOT.relative_to(ROOT)} "
                  f"(restore source for a crash)")

            touched = []
            for flow in body.get("flows", []):
                for step in flow.get("response", []):
                    if step.get("policy") != "transform-headers":
                        continue
                    c = step.setdefault("configuration", {})
                    rm = list(c.get("removeHeaders") or [])
                    for n in names:
                        if n.lower() not in rm:
                            rm.append(n.lower())
                    c["removeHeaders"] = rm
                    touched.append(flow.get("name"))
            st, detail = put_api(session, mbase, api_id, body)
            dep = deploy(session, mbase, api_id)
            print(f"    armed {len(touched)} step(s): PUT {st}  deploy {dep}")
            time.sleep(3)

            time.sleep(PACE)
            _, (g3_st, g3_h) = read_pair(direct_endpoint, prefix, token,
                                         "/shares")
            still = [n for n in names if n.lower() in g3_h]
            print(f"    re-read: gateway {g3_st}; still present: "
                  f"{still or 'none'}")

            # Restore, always, from the snapshot we wrote.
            orig = json.loads(SNAPSHOT.read_text())
            r_st, _ = put_api(session, mbase, api_id, orig)
            r_dep = deploy(session, mbase, api_id)
            print(f"    restored: PUT {r_st}  deploy {r_dep}")

            if not still:
                cv = "CASE_SENSITIVE_MATCHING_H2"
                cwhy = ("The lowercase spelling removed them, so "
                        "`removeHeaders` matches header names "
                        "case-sensitively and the config's capitalised "
                        "entries never matched. This is a one-line fix in "
                        "policy-classes.yaml, not a platform limit.")
            elif g3_st != 200:
                cv = "CANNOT_SEE_ARMED_READ_FAILED"
                cwhy = (f"The re-read returned {g3_st}, so the armed "
                        f"measurement observed nothing.")
            else:
                cv = "ADDED_AFTER_THE_POLICY_CHAIN_H3"
                cwhy = ("Both spellings were in the remove-list and the "
                        "headers still reached the client, while other "
                        "headers in the same list WERE removed in the same "
                        "run. So the gateway stamps these after the "
                        "response policy chain and no policy can take "
                        "them off. That is a platform limit of PC-4's "
                        "kind, not a misconfiguration, and the remedy is "
                        "a gateway-level setting rather than a policy.")
            print(f"    -> {cv}")
            out["case_experiment"] = {
                "verdict": cv, "why": cwhy, "survivors": names,
                "steps_armed": touched, "put_status": st,
                "deploy_status": dep, "restore_put": r_st,
                "restore_deploy": r_dep,
                "armed_read_status": g3_st,
                "still_present_when_lowercased": still,
                "snapshot": str(SNAPSHOT.relative_to(ROOT)),
                "put_detail": scrub(detail)[:200],
            }
    elif gateway_origin:
        out["case_experiment"] = {"verdict": "SKIPPED_NO_MUTATE_FLAG"}

    # ---------------------------------------------------------------- v
    stripped_required = [r for r in keep_rows if r.get("ok") is False]
    # --- the accepted refusal residue (B-55 / A-5). See the long note
    # in the allow-list config for why this is a named limit rather than
    # a relaxed gate. An absent or empty block means NOTHING is accepted
    # and the old failing behaviour stands.
    try:
        _al = yaml.safe_load(ALLOWLIST.read_text()) or {}
    except Exception:  # noqa: BLE001
        _al = {}
    _residue_cfg = (_al.get("accepted_refusal_residue") or {})
    accepted_residue = sorted({str(h).lower()
                               for h in (_residue_cfg.get("headers") or [])})

    leaky_refusals = [r for r in (out.get("refusal_headers") or {})
                      .get("probes", []) if not r["clean"]]

    # Split what refusals leak into the part that is declared accepted
    # and the part that is not. Only the second fails the test.
    _leaked_on_refusals = sorted({h.lower() for r in leaky_refusals
                                  for h in r["not_on_the_allow_list"]})
    within_residue = [h for h in _leaked_on_refusals if h in accepted_residue]
    beyond_residue = [h for h in _leaked_on_refusals
                      if h not in accepted_residue]
    out["refusal_residue"] = {
        "declared_accepted": accepted_residue,
        "observed_on_refusals": _leaked_on_refusals,
        "within_the_declared_residue": within_residue,
        "beyond_the_declared_residue": beyond_residue,
        "source": str(ALLOWLIST.relative_to(ROOT)),
        "rule": ("The acceptance is an exact set, not a tolerance. "
                 "Anything in 'beyond' fails this test."),
    }
    if accepted_residue:
        print(f"\n    accepted refusal residue (B-55 / A-5): "
              f"{', '.join(accepted_residue)}")
        print(f"    observed on refusals: "
              f"{', '.join(_leaked_on_refusals) or 'none'}")
        if beyond_residue:
            print(f"    BEYOND the accepted residue: "
                  f"{', '.join(beyond_residue)}  <-- this fails the test")

    if missing_required:
        verdict = "CORRELATION_ID_ABSENT_AC5_HAS_NO_HANDLE"
        why = ("The leak half may be clean, but " +
               ", ".join(missing_required) + " does not reach the "
               "client, so AC5/§3.5 has no correlation id to trace by "
               "and scripts/06_trace_correlation.py has nothing to read. "
               "Task 2.8 keeps one deliberate exception for exactly this "
               "reason. A sanitizer that removes every identifier passes "
               "a leak test and breaks the capability the leak test was "
               "protecting.")
    elif stripped_required:
        verdict = "SANITIZER_STRIPS_A_REQUIRED_PASSTHROUGH_HEADER"
        why = ("§2.3.2 requires " +
               ", ".join(r["header"] for r in stripped_required) +
               " to pass through, and the edge removed it. This breaks a "
               "conforming client while a naive leak test stays green, "
               "which is why the remove-list must be an allow-list of "
               "removals and never 'strip everything unrecognised'.")
    elif not policy_runs:
        verdict = "CANNOT_SEE_SANITIZER_NEVER_OBSERVED_DOING_ANYTHING"
        why = ("Not one header on the remove-list was measured being "
               "removed, so whether the step runs at all is unsettled "
               "(H1). Every other reading in this run is suspect until "
               "that is resolved: a policy that removes nothing and a "
               "policy that is absent are the same observation.")
    elif leaky_refusals and not accepted_residue:
        names = sorted({h for r in leaky_refusals
                        for h in r["not_on_the_allow_list"]})
        verdict = "SANITIZED_ON_SUCCESS_BUT_NOT_ON_REFUSALS"
        why = (f"Successful reads are clean and the allow-list holds on "
               f"them, but a refusal the GATEWAY produced carries "
               f"{', '.join(names)}. A request-phase policy that "
               f"interrupts answers without the response chain running, "
               f"so nothing removes what the gateway attached -- PC-4's "
               f"limit, reached from the other side. Every 403, 405, "
               f"409, 413 and 429 this perimeter emits is therefore "
               f"unsanitized, and those are the responses a prodding "
               f"caller sees most. B-55. No accepted residue is declared "
               f"in the allow-list config, so this is reported as a "
               f"failure rather than as a named limit.")
    elif beyond_residue:
        verdict = "REFUSALS_LEAK_BEYOND_THE_DECLARED_RESIDUE"
        why = (f"A refusal the GATEWAY produced carries "
               f"{', '.join(beyond_residue)}, which is NOT in the "
               f"accepted residue declared in "
               f"{ALLOWLIST.name}. B-55 accounts for "
               f"{', '.join(accepted_residue) or 'nothing'} and nothing "
               f"else. Anything beyond that list is a new leak and this "
               f"test is the thing that was supposed to catch it.")
    elif leaked or unlisted:
        names = [r["header"] for r in leaked] + unlisted
        verdict = "INTERNAL_HEADERS_STILL_REACH_THE_CLIENT"
        why = (f"The sanitizer demonstrably runs -- "
               f"{len(redacted)} header(s) measured removed -- and these "
               f"still reach the client: {', '.join(names)}. "
               f"Phase 4 says whether that is fixable in config.")
    elif within_residue:
        verdict = "INTERNAL_HEADERS_REMOVED_WITH_A_NAMED_REFUSAL_RESIDUE"
        why = (f"{len(redacted)} header(s) measured removed, no declared "
               f"internal header reaches the client on a success, no "
               f"unlisted internal header appears, and §2.3.2's "
               f"capability header survives on S7.\n\n"
               f"Gateway-produced refusals still carry "
               f"{', '.join(sorted(within_residue))}, which is exactly "
               f"the residue declared accepted in {ALLOWLIST.name} "
               f"(B-55, register item A-5) and nothing beyond it. That "
               f"residue is not closable by any policy -- PC-4's limit "
               f"reached from the other side -- so it is carried as a "
               f"named deferral rather than reported as a defect, the "
               f"same way T-05 passes on its edge half while clause 2.5 "
               f"stays a named gap.\n\n"
               f"This verdict is NOT a weaker test. The residue is an "
               f"exact set: a refusal carrying anything else fails this "
               f"test, and refusals the UPSTREAM produces are still held "
               f"to the full allow-list.")
    else:
        verdict = "INTERNAL_HEADERS_REMOVED_AND_PASSTHROUGH_PRESERVED"
        why = (f"{len(redacted)} header(s) measured removed, none of the "
               f"declared internal headers reach the client, no unlisted "
               f"internal header appears, and §2.3.2's capability header "
               f"survives on S7. Both halves, not just the leak half. "
               f"Refusals carry nothing outside the allow-list either.")

    out["verdict"] = verdict
    out["why"] = why
    out["allow_list_limit"] = (
        "The allow-list is enforced by this test, not by the gateway: "
        "transform-headers can add and remove named headers and cannot "
        "express 'keep only these', and no installed policy can "
        "(resource-filtering filters paths -- measured, scripts/34). So a "
        "header a new upstream version starts sending reaches the client "
        "until the next run of this test. Closing that needs a component "
        "in front of the gateway that strips by allow-list, which is the "
        "corporate-side answer and out of scope here.")
    out["what_this_does_not_show"] = (
        "Two response KINDS are now covered -- a 200 the upstream "
        "produced and a refusal the gateway produced -- but only on this "
        "route family. One route's response headers (/shares, plus S7 "
        "for the passthrough check). The sanitizer is in the COMMON set so it "
        "applies to every flow, but 'applies' is a property of the "
        "generated definition, which scripts/22 checks statically -- not "
        "something this run measured per route.")

    rep = Report()
    rep.record("T-07", "internal headers are removed before the client",
               "every header on the declared remove-list that the upstream "
               "actually sends is absent through the edge, no unlisted "
               "internal header appears, and §2.3.2's capability header "
               "survives -- each read direct and through the gateway in "
               "the same run, the direct read being the same-path positive "
               "control B-40 requires",
               verdict,
               verdict in PASSING_VERDICTS,
               "evidence/t07-header-sanitization.json")

    EVIDENCE.parent.mkdir(exist_ok=True)
    EVIDENCE.write_text(json.dumps(out, indent=2) + "\n")
    try:
        EVIDENCE.chmod(0o600)
    except OSError:
        pass
    rep.write(REPORT)
    rep.summary()

    print()
    print("=" * 68)
    print(f"T-07 VERDICT: {verdict}")
    print("=" * 68)
    print(why)
    return 0 if verdict in PASSING_VERDICTS else 1


if __name__ == "__main__":
    sys.exit(main())
