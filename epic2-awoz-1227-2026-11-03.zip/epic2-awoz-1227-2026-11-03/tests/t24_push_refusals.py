#!/usr/bin/env python3
"""T-24: the edge half of push ingest -- the six refusals.

E2 Task 2.11 | AC2 | R12 | CONOPS 2.4.5, 2.4.6, 3.2
Route I1, class I, channel I-2 (proposed, OD-9)

WHAT THIS OWNS AND WHAT IT DOES NOT
-----------------------------------
Task 2.11: "E2 owns only the edge enforcement: oversize refused, wrong
content type refused, wrong path refused, overwrite refused, GET on an
upload route refused, and a direct Files API call refused." E4 owns the
successful upload (AC4, T-25). So a PUT that gets past every refusal and
is then refused by Databricks is a PASS here, not a failure -- no
service principal exists and no credential is injected
(producers.yaml PR-2), so the upstream refuses everything by design.

THE POSITIVE CONTROL IS THE POINT, NOT A FORMALITY
--------------------------------------------------
Two of these refusals can pass while being completely broken.

`policy-request-validation` with `isRequired: false` checks its pattern
ONLY when the parameter is present. That is what lets the overwrite
refusal be conditional without a step `condition` -- AI-10 records that
a step condition which does not evaluate true makes Gravitee OMIT the
policy silently, with PUT 200, deploy 202 and no warning. But it also
means a policy that was silently dropped and a rule correctly skipping
an absent parameter look IDENTICAL from outside: both let the request
through. So `overwrite=false` must be measured SUCCEEDING past the edge
in the same run as `overwrite=true` being refused. One without the other
proves nothing.

The same applies to the size cap in reverse: a body under the limit must
get past the edge, or "oversize refused" might just be "everything
refused".

ATTRIBUTION IS BY VOICE, NEVER BY STATUS
----------------------------------------
Databricks answers 403 for an unauthorised write and so does
resource-filtering for an unlisted path. A status alone identifies
nothing. This test discriminates on the BODY: Databricks' API returns
JSON carrying `error_code`; the gateway's policies return short plain
text. That rule was learned twice -- scripts/36 read 403 as "the edge
refused" from the status alone and had to be corrected, and T-01 scored
a 429 from its own spike-arrest as a policy refusal.

Two edge voices are already measured (scripts/36, 2026-10-28):
    403 "You're not allowed to access this resource"
    405 "Method not allowed while accessing this resource"
`policy-request-validation` and `request-content-limit` have never
answered in this repository, so their voices are UNKNOWN and are
recorded on first sight rather than predicted.

WHAT R-OVERSIZE HAS TO MEASURE, NOT ASSUME
------------------------------------------
`request-content-limit`'s schema declares `limit` as integer REQUIRED
with no title, no description and no default
(evidence/ingest-policy-schemas.json). The unit is undocumented. Class I
sets 1048576, which is 1 MiB IF the unit is bytes and 1 GiB if it is
kilobytes. 2.4.5 says "Databricks documents no size cap for the REST
call; the cap here is the gateway limit", so this policy is the only
size cap in the design and the unit is not a detail. This test brackets
the boundary: a body just over and just under, and the verdict says
which unit the gateway actually used.

R-DIRECT IS NARROWER THAN 2.4.5 ASKS, AND SAYS SO
-------------------------------------------------
2.4.5: "A direct call to the Files API with the producer's gateway
credential fails, and the workspace accepts calls from the gateway
addresses only."

Neither half is fully testable yet, and substituting something weaker
while keeping the name would be the problem this repository keeps
catching.

  * There is no "producer's gateway credential". The plan is KEY_LESS
    because OD-9 has not decided what a producer presents, so there is
    no credential to try directly.
  * The workspace does not restrict by source address here; that is a
    workspace network control nobody configured.

What IS assertable is narrower and still worth having: the Files API
does not accept an unauthenticated or bogus-token write from this host.
That is reported as its own verdict, with the two untested halves named.
"""

import json
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tests"))

from common import Report, load_env  # noqa: E402
from t01_gateway_read import edge_base, scrub  # noqa: E402

PRODUCERS = ROOT / "iac" / "config" / "producers.yaml"
ROUTE_TABLE = ROOT / "iac" / "config" / "route-table.yaml"
POLICY_CLASSES = ROOT / "iac" / "config" / "policy-classes.yaml"
EVIDENCE = ROOT / "evidence" / "t24-push-refusals.json"
REPORT = ROOT / "evidence" / "t24-report.json"

PACE = 0.3  # class I declares no rate-limit or spike-arrest

# Measured on this installation, scripts/36 2026-10-28.
KNOWN_EDGE_VOICES = {
    "You're not allowed to access this resource": "resource-filtering/path",
    "Method not allowed while accessing this resource":
        "resource-filtering/method",
    # Added 2026-10-29 after T-24's first green run, which is what
    # confirmed it is the EDGE's and not the upstream's: in the same run
    # a body of limit-1024 reached Databricks and returned its 401 JSON,
    # while limit+1024 produced this string and never left the gateway.
    # The test asks for that confirmation before a voice is promoted
    # here, rather than promoting whatever appeared.
    "The request is larger than the server is willing or able to "
    "process.": "request-content-limit",
}


def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def http(url, method="GET", body=None, content_type=None, bearer=None,
         timeout=60):
    req = urllib.request.Request(url, data=body, method=method)
    if content_type:
        req.add_header("Content-Type", content_type)
    if bearer:
        req.add_header("Authorization", f"Bearer {bearer}")

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *_a, **_k):
            return None

    opener = urllib.request.build_opener(NoRedirect)
    try:
        with opener.open(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:  # noqa: BLE001
        return None, repr(e)


def who_answered(status, body, own_messages=()):
    """EDGE or UPSTREAM, decided on the body.

    Corrected 2026-10-29 after the first run. The original rule was
    "Databricks returns JSON, gateway policies return plain text", and
    it was wrong in one direction: `policy-request-validation` answers
    with JSON too --

        {"message": "Request is not valid according to constraint
         rules", "constraints": ["Content-Type must be
         application/octet-stream"]}

    -- which carries no `error_code`, so three genuine edge refusals
    (415, 415, 409) were reported CANNOT_SEE while their statuses
    matched the route table exactly. Attribution failed on refusals
    that had worked.

    The strongest discriminator turned out to be one we own: that
    `constraints` array echoes the `message` string configured in
    policy-classes.yaml VERBATIM. So the messages are read out of the
    config and matched against the body. A body quoting a string this
    repository wrote is the edge -- there is no heuristic in that.
    """
    text = (body or "").strip().strip('"')
    if text in KNOWN_EDGE_VOICES:
        return "EDGE", KNOWN_EDGE_VOICES[text], text

    # Definitive: the body quotes a constraint message from our own
    # configuration.
    for msg in own_messages:
        if msg and msg in text:
            return "EDGE", f"policy-request-validation: {msg!r}", text[:300]

    try:
        doc = json.loads(body or "")
    except ValueError:
        doc = None

    if isinstance(doc, dict) and (doc.get("error_code")
                                  or doc.get("errorCode")):
        return "UPSTREAM", "databricks", text[:200]
    if status == 429:
        return "CANNOT_SEE", "throttled", text[:200]
    if status is None:
        return "CANNOT_SEE", "transport error", text[:200]
    # JSON WITHOUT error_code, or short plain text: a gateway policy.
    # Databricks' REST API always carries error_code on an error, so its
    # absence from a JSON error body rules the upstream out.
    if isinstance(doc, dict) and "constraints" in doc:
        return ("EDGE", "policy-request-validation (constraints body)",
                text[:300])
    if doc is None and len(text) < 400:
        return "EDGE", "edge voice NOT PREVIOUSLY RECORDED", text[:300]
    if isinstance(doc, dict) and len(text) < 600:
        return ("EDGE", "JSON without error_code -- not Databricks' shape",
                text[:300])
    return "CANNOT_SEE", "unattributable", text[:300]


def main():
    load_env()
    base, base_how = edge_base()[0], edge_base()[1]

    print("=" * 70)
    print("T-24: push ingest -- the six edge refusals")
    print("E2 Task 2.11 | AC2 | R12 | CONOPS 2.4.5, 3.2")
    print("=" * 70)
    print()

    for f in (PRODUCERS, ROUTE_TABLE, POLICY_CLASSES):
        if not f.exists():
            print(f"VERDICT: CANNOT_SEE_MISSING_CONFIG\n  {f}")
            return 1
    prod_doc = yaml.safe_load(PRODUCERS.read_text()) or {}
    producers = prod_doc.get("producers") or []
    if not producers:
        print("VERDICT: CANNOT_SEE_NO_PRODUCER_DECLARED")
        return 1
    prod = producers[0]
    rt = yaml.safe_load(ROUTE_TABLE.read_text())
    i1 = next((r for r in rt["routes"] if r.get("id") == "I1"), None)
    if i1 is None:
        print("VERDICT: CANNOT_SEE_NO_I1_ROUTE")
        return 1
    pc = yaml.safe_load(POLICY_CLASSES.read_text())
    cls_i = (pc.get("classes") or {}).get("I") or {}

    # Expected statuses DERIVED from the route table, not restated here.
    expect = {r["id"]: r.get("status_expected") for r in i1["refusals"]}
    # The size limit DERIVED from class I, not restated here.
    limit = None
    for step in cls_i.get("request") or []:
        if step.get("policy") == "request-content-limit":
            limit = (step.get("configuration") or {}).get("limit")
    if not limit:
        print("VERDICT: CANNOT_SEE_NO_SIZE_LIMIT_DECLARED")
        return 1

    # Every `message` class I configures on a validation rule. These are
    # the strings the gateway echoes back in its `constraints` array, so
    # they are the one attribution signal that cannot be mistaken for
    # the upstream's.
    own_messages = []
    for step in cls_i.get("request") or []:
        for rule in ((step.get("configuration") or {}).get("rules") or []):
            msg = (rule.get("constraint") or {}).get("message")
            if msg:
                own_messages.append(msg)

    prefix = base + prod["edge_path"]
    accepted_ct = "application/octet-stream"
    print(f"edge base:   {base}  ({base_how})")
    print(f"producer:    {prod['id']}   edge path {prod['edge_path']}")
    print(f"size limit:  {limit} (unit UNDOCUMENTED -- bracketed below)")
    print(f"expected:    {expect}")
    print(f"upstream:    refuses everything by design "
          f"(no service principal, producers.yaml PR-2)")

    out = {"test": "T-24", "at": now(), "edge_base": base,
           "own_constraint_messages": None,  # filled below
           "producer": prod["id"], "edge_path": prod["edge_path"],
           "declared_limit": limit, "expected_statuses": expect,
           "cases": [], "voices_recorded": {}}
    rows = out["cases"]
    out["own_constraint_messages"] = own_messages

    def run(cid, refusal, label, method, path, *, body=None, ct=None,
            expect_edge=True, note=None):
        time.sleep(PACE)
        st, raw = http(prefix + path, method=method, body=body,
                       content_type=ct)
        who, voice, text = who_answered(st, raw, own_messages)
        if who == "EDGE" and "NOT PREVIOUSLY RECORDED" in voice:
            out["voices_recorded"].setdefault(f"{st}", text)
        if expect_edge:
            ok = who == "EDGE"
            want = expect.get(refusal)
            status_ok = (str(st) == str(want)) if str(want).isdigit() else None
        else:
            ok = who in ("UPSTREAM", "CANNOT_SEE") or st == 200
            status_ok = None
        rows.append({"case": cid, "refusal": refusal, "label": label,
                     "method": method, "path": path, "status": st,
                     "responder": who, "voice": voice,
                     "body_head": scrub(raw)[:300] if raw else None,
                     "expect_edge_refusal": expect_edge,
                     "as_expected": ok,
                     "expected_status": expect.get(refusal) if expect_edge else None,
                     "status_matches_expected": status_ok,
                     "note": note})
        mark = "OK " if ok else "NOT AS EXPECTED"
        extra = ""
        if status_ok is True:
            extra = f"  status matches {want}"
        elif status_ok is False:
            extra = f"  STATUS {st} != expected {want}"
        print(f"  {cid:<4} {label:<44} {str(st):<5} {who:<10} {mark}{extra}")
        return st, raw, who

    small = b"x" * 64

    print("\n--- positive controls: these must get PAST the edge")
    run("P1", None, "valid PUT (octet-stream, small, no params)", "PUT",
        "/data/t24-probe.bin", body=small, ct=accepted_ct,
        expect_edge=False,
        note="Refused UPSTREAM is the expected outcome: no credential is "
             "injected. What matters is that the EDGE let it through.")
    run("P2", None, "PUT ?overwrite=false", "PUT",
        "/data/t24-probe.bin?overwrite=false", body=small, ct=accepted_ct,
        expect_edge=False,
        note="The control that makes R-OVERWRITE meaningful. isRequired "
             "false skips the rule when the parameter is absent, so a "
             "silently omitted policy and a correctly skipped rule are "
             "indistinguishable without this.")

    print("\n--- R-METHOD: 2.4.5 'GET, LIST and DELETE are not forwarded'")
    run("C1", "R-METHOD", "GET on the upload route", "GET",
        "/data/t24-probe.bin")
    run("C2", "R-METHOD", "DELETE on the upload route", "DELETE",
        "/data/t24-probe.bin")

    print("\n--- R-CONTENT-TYPE")
    run("C3", "R-CONTENT-TYPE", "PUT with Content-Type: text/plain", "PUT",
        "/data/t24-probe.bin", body=small, ct="text/plain")
    run("C4", "R-CONTENT-TYPE", "PUT with no Content-Type at all", "PUT",
        "/data/t24-probe.bin", body=small)

    print("\n--- R-OVERWRITE")
    run("C5", "R-OVERWRITE", "PUT ?overwrite=true", "PUT",
        "/data/t24-probe.bin?overwrite=true", body=small, ct=accepted_ct)

    print(f"\n--- R-OVERSIZE: bracketing the boundary around limit={limit}")
    run("C6", "R-OVERSIZE", f"PUT {limit - 1024} bytes (just UNDER)", "PUT",
        "/data/t24-under.bin", body=b"x" * max(1, limit - 1024),
        ct=accepted_ct, expect_edge=False,
        note="Must get past the edge, or 'oversize refused' is really "
             "'everything refused'.")
    over_st, _, over_who = run(
        "C7", "R-OVERSIZE", f"PUT {limit + 1024} bytes (just OVER)", "PUT",
        "/data/t24-over.bin", body=b"x" * (limit + 1024), ct=accepted_ct)

    print("\n--- R-PATH: traversal (mechanism is normalization, not a "
          "pattern)")
    run("C8", "R-PATH", "PUT with ../../ in the path", "PUT",
        "/data/../../escaped.bin", body=small, ct=accepted_ct,
        note="B-54. This was FORWARDED to Databricks on 2026-10-29 and "
             "returned 401 -- which proves only that no credential was "
             "sent, because Databricks checks credentials before "
             "resolving a path. normalizeRequestPath normalizes what the "
             "POLICY EVALUATES, not what the gateway FORWARDS. Now "
             "refused by an explicit path rule.")
    run("C9", "R-PATH", "PUT with %2e%2e%2f encoded traversal", "PUT",
        "/data/%2e%2e%2f%2e%2e%2fescaped.bin", body=small, ct=accepted_ct)
    run("C10", "R-PATH", "PUT with double-encoded traversal", "PUT",
        "/data/%252e%252e%252fescaped.bin", body=small, ct=accepted_ct)

    # ---- R-DIRECT: narrower than 2.4.5 asks, and labelled so ---------
    print("\n--- R-DIRECT: direct Files API call, bypassing the gateway")
    land = prod.get("landing") or {}
    host = None
    env = ROOT / ".env"
    for line in env.read_text().splitlines():
        if line.strip().startswith("DATABRICKS_HOST="):
            host = line.split("=", 1)[1].strip().replace(
                "https://", "").replace("http://", "").rstrip("/")
    direct = []
    if host:
        durl = (f"https://{host}/api/2.0/fs/files/Volumes/"
                f"{land.get('catalog')}/{land.get('schema')}/"
                f"{land.get('volume')}/t24-direct.bin")
        for lbl, tok in (("no credential", None),
                         ("a bogus bearer token", "not-a-real-token")):
            time.sleep(PACE)
            st, raw = http(durl, method="PUT", body=small,
                           content_type=accepted_ct, bearer=tok)
            who, voice, text = who_answered(st, raw, own_messages)
            refused = st not in (200, 201, 204)
            direct.append({"with": lbl, "status": st, "responder": who,
                           "refused": refused, "body_head": scrub(raw)[:200]})
            print(f"  D-{lbl:<42} {str(st):<5} "
                  f"{'refused' if refused else 'ACCEPTED'}")
    out["direct_call"] = {
        "attempts": direct,
        "verdict": ("FILES_API_REFUSES_UNAUTHENTICATED_WRITES"
                    if direct and all(a["refused"] for a in direct)
                    else "CANNOT_SEE" if not direct
                    else "FILES_API_ACCEPTED_A_WRITE_IT_SHOULD_NOT_HAVE"),
        "narrower_than_2_4_5_asks": (
            "2.4.5 asks for two things this cannot test yet. (1) 'A "
            "direct call with the PRODUCER'S GATEWAY CREDENTIAL fails' -- "
            "there is no such credential: the plan is KEY_LESS because "
            "OD-9 has not decided what a producer presents. (2) 'the "
            "workspace accepts calls from the gateway addresses only' -- "
            "no workspace network control is configured here. What is "
            "measured is narrower: this host cannot write to the volume "
            "path unauthenticated or with a bogus token. Reported under "
            "its own name rather than as R-DIRECT passing."),
    }

    # ---- size unit, measured ----------------------------------------
    if over_who == "EDGE":
        unit = "BYTES_CONFIRMED"
        unit_why = (f"A body of {limit + 1024} bytes was refused at the "
                    f"edge against limit={limit}, and {limit - 1024} "
                    f"bytes was not. The unit is bytes.")
    elif over_st in (200, 201, 204) or over_who == "UPSTREAM":
        unit = "UNIT_IS_NOT_BYTES"
        unit_why = (f"A body of {limit + 1024} bytes was NOT refused at "
                    f"the edge, so `limit` is not counting bytes -- "
                    f"kilobytes would put the real cap at ~{limit} KiB. "
                    f"2.4.5 makes this the only size cap in the design, "
                    f"so the configured number is currently about a "
                    f"thousand times larger than intended.")
    else:
        unit = "CANNOT_SEE"
        unit_why = "The oversize probe produced no attributable answer."
    out["size_limit_unit"] = {"verdict": unit, "why": unit_why,
                              "declared_limit": limit}
    print(f"\n  size limit unit: {unit}")
    print(f"    {unit_why}")

    # ---- verdict ----------------------------------------------------
    controls = [r for r in rows if not r["expect_edge_refusal"]]
    refusals = [r for r in rows if r["expect_edge_refusal"]]
    bad_controls = [r["case"] for r in controls if not r["as_expected"]]
    not_refused = [r["case"] for r in refusals if not r["as_expected"]]
    wrong_status = [f"{r['case']}({r['status']}!={r['expected_status']})"
                    for r in refusals
                    if r["status_matches_expected"] is False]

    if bad_controls:
        verdict = "EDGE_REFUSES_WHAT_IT_SHOULD_ACCEPT"
        why = (f"Positive controls {bad_controls} were refused at the "
               f"edge. Until a valid upload gets through, every refusal "
               f"below is consistent with 'the route refuses "
               f"everything', which is not the control being tested.")
    elif not_refused:
        verdict = "SOME_REFUSALS_DID_NOT_HAPPEN_AT_THE_EDGE"
        why = (f"{not_refused} were not refused by the edge. Whatever "
               f"stopped them -- if anything did -- was not class I.")
    elif wrong_status:
        verdict = "REFUSED_BUT_WITH_THE_WRONG_STATUS"
        why = (f"Every refusal happened at the edge, but {wrong_status} "
               f"carried a status the route table does not expect. Task "
               f"2.11's Verify line asks for a distinct and CORRECT "
               f"status per refusal; an earlier policy answering for a "
               f"later one produces exactly this.")
    else:
        verdict = "EDGE_REFUSALS_ENFORCED_WITH_CORRECT_STATUSES"
        why = ("Every probed refusal happened at the edge with the "
               "expected status, and both positive controls got past the "
               "edge in the same run -- including overwrite=false, "
               "without which the overwrite refusal would be "
               "indistinguishable from a silently omitted policy. The "
               "successful upload is E4's (AC4, T-25) and is not claimed "
               "here.")

    out["verdict"] = verdict
    out["why"] = why
    out["what_this_does_not_show"] = (
        "The successful upload (E4/AC4/T-25, needs the landing volume "
        "and a service principal). The path rewrite -- the upstream path "
        "here comes from CONCATENATION of the endpoint's base path with "
        "the request tail, which is the mechanism B-48 identified, NOT "
        "3.2's rewrite capability, so 3.2's row stays open and R12 stays "
        "live. Content scanning, which 2.4.5 says is a platform "
        "capability and OD-9 leaves unowned -- these refusals check the "
        "SHAPE of a request and say nothing about what is inside a file "
        "whose shape is permitted.")

    rep = Report()
    rep.record("T-24", "push ingest is refused at the edge in all six ways",
               "each refusal answered by the EDGE, attributed by the "
               "responder's own voice rather than by status, with the "
               "status the route table expects -- and a valid PUT plus an "
               "overwrite=false PUT getting past the edge in the same run "
               "as the positive controls B-40 requires",
               verdict,
               verdict == "EDGE_REFUSALS_ENFORCED_WITH_CORRECT_STATUSES",
               "evidence/t24-push-refusals.json")

    EVIDENCE.parent.mkdir(exist_ok=True)
    EVIDENCE.write_text(json.dumps(out, indent=2) + "\n")
    try:
        EVIDENCE.chmod(0o600)
    except OSError:
        pass
    rep.write(REPORT)
    rep.summary()

    if out["voices_recorded"]:
        print("\n  gateway voices recorded for the first time:")
        for st, txt in sorted(out["voices_recorded"].items()):
            print(f"    {st}  {txt!r}")
        print("  Add them to KNOWN_EDGE_VOICES once confirmed as the "
              "gateway's, not before.")

    print()
    print("=" * 70)
    print(f"T-24 VERDICT: {verdict}")
    print("=" * 70)
    print(why)
    return 0 if verdict == "EDGE_REFUSALS_ENFORCED_WITH_CORRECT_STATUSES" else 1


if __name__ == "__main__":
    sys.exit(main())
